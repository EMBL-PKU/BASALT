#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

from Bio import SeqIO
import sys, os, time, copy
from collections import Counter

def mod_bin(binset_folder, pwd):
    bins_checkm={}
    try:
        os.mkdir(str(binset_folder)+'_mod')
    except:
        print(str(binset_folder)+'_mod is exist. Re-create the folder')
        os.system('rm -rf '+str(binset_folder)+'_mod')
        os.mkdir(str(binset_folder)+'_mod')
    
    os.chdir(pwd+'/'+binset_folder)
    f=open('Mod_contig_id.txt','w')
    f1=open('Bin_name_mod.txt','w')
    f2=open('Bin_name_mod_bin_stats_ext.tsv','w')
    n, record_seq, bin_total_len, mod_bin_list, mod_bin_dict, bin_contig_num = 0, {}, {}, [], {}, {}
    for root, dirs, files in os.walk(pwd+'/'+binset_folder):
        for file in files:
            hz=str(file).split('.')[-1]
            # print(hz
            if 'fa' in hz:
                n+=1
                m=0
                record_seq['bin'+str(n)]={}
                bin_total_len['bin'+str(n)]=0
                mod_bin_list.append('bin'+str(n))
                checkm_name_list=str(file).split('.')
                checkm_name_list.remove(checkm_name_list[-1])
                checkm_name='.'.join(checkm_name_list)
                mod_bin_dict[checkm_name]='bin'+str(n)
                f1.write(str(file)+'\t'+'bin'+str(n)+'.fa'+'\n')
                for record in SeqIO.parse(file, 'fasta'):
                    m+=1
                    f.write('bin'+str(n)+'_'+str(m)+'\t'+str(record.id)+'\n')
                    record_seq['bin'+str(n)]['bin'+str(n)+'_'+str(m)]=str(record.seq)
                    bin_total_len['bin'+str(n)]+=len(record.seq)
                bin_contig_num['bin'+str(n)]=m

        if 'bin_stats_ext.tsv' in file:
            for line in open(file,'r'):
                checkm_name=str(line).strip().split('\t')[0]
                mod_bin_checkm_name=str(mod_bin_dict[checkm_name])
                bins_checkm[mod_bin_checkm_name]={}
                bins_checkm[mod_bin_checkm_name]['marker lineage']=str(line).strip().split('\'marker lineage\': \'')[1].strip().split('\'')[0]
                bins_checkm[mod_bin_checkm_name]['Completeness']=float(str(line).strip().split('\'Completeness\': ')[1].split(', ')[0])
                bins_checkm[mod_bin_checkm_name]['Genome size']=float(str(line).strip().split('\'Genome size\':')[1].strip().split(', ')[0])
                try:
                    #bins_checkm[mod_bin_checkm_name]['Mean scaffold length']=float(str(line).strip().split('Mean scaffold length\':')[1].split(',')[0].strip())
                    bins_checkm[mod_bin_checkm_name]['Contamination']=float(str(line).strip().split('Contamination\': ')[1].split('}')[0])
                except:
                    #bins_checkm[mod_bin_checkm_name]['Mean scaffold length']=float(str(line).strip().split('Mean scaffold length\':')[1].split('}')[0].strip())
                    bins_checkm[mod_bin_checkm_name]['Contamination']=float(str(line).strip().split('Contamination\': ')[1].split(',')[0].strip())
                bins_checkm[mod_bin_checkm_name]['Mean scaffold length']=float(bins_checkm[mod_bin_checkm_name]['Genome size'])/bin_contig_num[mod_bin_checkm_name]
                f2.write(mod_bin_checkm_name+'\t'+str(line).strip().split('\t')[1]+'\n')             
    f.close()
    f1.close()
    f2.close()

    os.system('mv Mod_contig_id.txt Bin_name_mod.txt Bin_name_mod_bin_stats_ext.tsv '+pwd+'/'+str(binset_folder)+'_mod')
    
    os.chdir(pwd+'/'+str(binset_folder)+'_mod')
    f1=open('Total_bins.fa','w')
    for bin_id in record_seq.keys():
        f=open(str(bin_id)+'.fa','w')
        for contigs in record_seq[bin_id].keys():
            f.write('>'+str(contigs)+'\n'+str(record_seq[bin_id][contigs])+'\n')
            f1.write('>'+str(contigs)+'\n'+str(record_seq[bin_id][contigs])+'\n')
        f.close()
    f1.close()
    os.system('mv Total_bins.fa '+pwd)
    os.chdir(pwd)
    return str(binset_folder)+'_mod', 'Total_bins.fa', mod_bin_list, bins_checkm, record_seq, bin_total_len

def parse_sam(sam_file, fq, read1, read2, pair, n):
    print('Reading reads id')
    f_not_mapped_reads1=open('Not_mapped_reads_R1.fq','a')
    f_not_mapped_reads2=open('Not_mapped_reads_R2.fq','a')
    m, m1, m2 = 0, 0, 0
    for line in open(sam_file,'r'):
        m1+=1
        flist=str(line).split('\t')
        if len(flist) >= 12:
            bin_id=flist[2].split('_')[0]
            read_id=flist[0]
            read_id_name=str(n)+'_'+read_id.split('_')[0]
            pair[bin_id][read_id_name]=0
        if m1 % 1000000 == 0:
            print('Read', m1,'lines')

    print('Collecting paired reads')
    for line in open(sam_file,'r'):
        m2+=1
        flist=str(line).split('\t')
        if len(flist) >= 12:
            bin_id=flist[2].split('_')[0]
            read_id=flist[0]
            read_id_name=str(n)+'_'+read_id.split('_')[0]
            pair[bin_id][read_id_name]+=1

            if pair[bin_id][read_id_name] == 2:
                fq[bin_id][read_id_name]=0
                del pair[bin_id][read_id_name]

        if m2 % 1000000 == 0:
            print('Read', m2,'lines')

    f_summary=open('Bin_reads_summary.txt','w')
    for item in fq.keys():
        f_summary.write(str(item)+' SEQ number:'+str(len(fq[item]))+'\n')
    f_summary.close()

    mapped_read, x={}, 0
    print('Parsing', sam_file)
    for line in open(sam_file,'r'):
        m+=1
        flist=str(line).split('\t')
        if len(flist) >= 12:
            bin_id=flist[2].split('_')[0]
            read_id=flist[0]
            reads=str(n)+'_'+read_id #
            read_num=reads.split('_')[-1] #
            read_id_name=str(n)+'_'+read_id.split('_')[0] #
            fq_seq=flist[9]+'\n'+'+'+'\n'+flist[10]+'\n'
            try:
                fq[bin_id][read_id_name]+=1
                f1=open(str(bin_id)+'_seq_R'+str(read_num)+'.fq','a')
                f1.write('@'+str(reads)[:-2]+' '+str(read_num)+'\n'+str(fq_seq))
                f1.close()
                mapped_read[read_id]=0
                if fq[bin_id][read_id_name] == 2:
                    del fq[bin_id][read_id_name]
            except:
                x+=1
    
        if m % 1000000 == 0:
            print('Parsed', m,'lines')
    # f_not_mapped_reads.close()

    n1, m, m1, m2, m3 = 0, [], 0, {}, {}
    for line in open(read1,'r'):
        n1+=1
        if '@' in str(line)[0]:
            read_name=str(str(line).strip())[1:-2]
            read_num=str(str(line).strip())[-1]
            try:
                mapped_read[read_name]+=1
                m1=0
            except:
                f_not_mapped_reads1.write('@'+str(n)+'_'+str(read_name)+' '+str(read_num)+'\n')
                m1=n1
                m=[]
                m.append(n1+1)
                m.append(n1+2)
                m.append(n1+3)
                m2[n1]=0
                m3[n1+1]=0
                m3[n1+2]=0
                m3[n1+3]=0
        if m1 != 0:
            if n1 in m:
                f_not_mapped_reads1.write(str(line))
        
        if n1 % 1000000 == 0:
            print('Parsed', n1,'lines')
    f_not_mapped_reads1.close()

    n1, n2 = 0, 0
    for line in open(read2,'r'):
        n1+=1
        try:
            m2[n1]+=1
            read_name=str(str(line).strip())[1:-2]
            read_num=str(str(line).strip())[-1]
            f_not_mapped_reads2.write('@'+str(n)+'_'+str(read_name)+' '+str(read_num)+'\n')
        except:
            n2+=1

        try:
            m3[n1]+=1
            f_not_mapped_reads2.write(str(line))
        except:
            n2+=1
        
        if n1 % 1000000 == 0:
            print('Parsed', n1,'lines')
    f_not_mapped_reads2.close()

def mapping_sr(total_fa, datasets_list, fq, pair, num_threads):
    os.system('bowtie2-build '+str(total_fa)+' '+str(total_fa))
    n = 0
    for item in datasets_list.keys():
        n+=1
        read1=str(datasets_list[item][0])
        read2=str(datasets_list[item][1])
        os.system('bowtie2 -p '+str(num_threads)+' -x '+str(total_fa)+' -1 '+str(read1)+' -2 '+str(read2)+' -S '+str(item)+'.sam -q --no-unal')
        parse_sam(str(item)+'.sam', fq, read1, read2, pair, n)

def group_bin(bin_id_raw_seq, bin_total_len, remove_bin, similarity):
    blast_output=open('Filtrated_total_blast.txt','w')
    paired_bins, xxx = {}, 0
    for line in open('total_blast.txt','r'):
        simi=str(line).strip().split('\t')[2]
        length=eval(str(line).strip().split('\t')[3])
        if float(simi) >= 95 and int(length) >= 150:
            contig1=str(line).strip().split('\t')[0]
            bin1=contig1.split('_')[0]
            contig2=str(line).strip().split('\t')[1]
            bin2=contig2.split('_')[0]
            ali_len=float(simi)*int(length)/100
            if bin1 not in remove_bin.keys() and bin2 not in remove_bin.keys():
                if bin1 != bin2:
                    bin1_num=int(bin1.split('bin')[1])
                    bin2_num=int(bin2.split('bin')[1])
                    blast_output.write(str(line))
                    if bin1_num < bin2_num:
                        try:
                            paired_bins[bin1+'\t'+bin2]+=ali_len
                        except:
                            paired_bins[bin1+'\t'+bin2]=ali_len
                    else:
                        try:
                            paired_bins[bin2+'\t'+bin1]+=ali_len
                        except:
                            paired_bins[bin2+'\t'+bin1]=ali_len             
    blast_output.close()

    f=open('Bin_group.txt','w')
    f2=open('Qualified_bin_group.txt','w')
    m=0
    for item in paired_bins.keys():
        bin1=str(item).split('\t')[0]
        bin2=str(item).split('\t')[1]
        bin1_perc=100*float(paired_bins[item])/int(bin_total_len[bin1])
        bin2_perc=100*float(paired_bins[item])/int(bin_total_len[bin2])
        f.write(str(item)+'\t'+str(paired_bins[item])+'\t'+str(bin1_perc)+'\t'+str(bin2_perc)+'\t'+str(bin_id_raw_seq[bin1])+'\t'+str(bin_id_raw_seq[bin2])+'\n')
        if bin1_perc >= similarity or bin2_perc >= similarity:
            f2.write(str(item)+'\t'+str(paired_bins[item])+'\t'+str(bin1_perc)+'\t'+str(bin2_perc)+'\t'+str(bin_id_raw_seq[bin1])+'\t'+str(bin_id_raw_seq[bin2])+'\n')
            m+=1
    f.close()
    f2.close()

    bin_group, remove_group, n={}, {}, 0
    for line in open('Qualified_bin_group.txt','r'):
        bin1=str(line).strip().split('\t')[0]
        bin2=str(line).strip().split('\t')[1]
        try:
            bin_group[bin1][bin2]=0
        except:
            bin_group[bin1]={}
            bin_group[bin1][bin1]=0
            bin_group[bin1][bin2]=0

        bin_group2={}
        bin_group2=copy.deepcopy(bin_group)
        if bin2 in bin_group2.keys():
            for binx in bin_group2[bin2].keys():
                bin_group[bin1][binx]=0
            remove_group[bin2]=0

        bin_group2={}
        bin_group2=copy.deepcopy(bin_group)
        for binx in bin_group2.keys():
            if bin2 in bin_group2[binx].keys():
                bin1_num=int(bin1.split('bin')[1])
                binx_num=int(binx.split('bin')[1])
                if bin1_num < binx_num:
                    bin_group[bin1][binx]=0
                    for biny in bin_group[binx].keys():
                        bin_group[bin1][biny]=0
                    # del bin_group[binx]
                    remove_group[binx]=0
                else:
                    bin_group[binx][bin1]=0

    bin_group2={}
    bin_group2=copy.deepcopy(bin_group)
    for binx in bin_group2.keys():
        if binx in remove_group.keys():
            del bin_group[binx]        

    bin_group_total_raw_read={}
    for binx in bin_group.keys():
        bin_group_total_raw_read[binx]=0
        for biny in bin_group[binx].keys():
            bin_group[binx][biny]=bin_id_raw_seq[biny]
            bin_group_total_raw_read[binx]+=bin_id_raw_seq[biny]

    f=open('Bin_group_summary.txt', 'w')
    f.write('Bin group'+'\t'+'Bins'+'\t'+'Total raw read (bp)'+'\n')
    n=0
    for item in bin_group.keys():
        n+=1
        f.write(str(n)+'\t'+str(str(bin_group[item]).replace('\': 0', '').replace('\'', '').replace('{', '').replace('}', ''))+'\t'+str(bin_group_total_raw_read[item])+'\n')
    f.close()
    # try:
    #     f=open('Bin_group_total_raw_read.txt', 'a')
    # except:
    #     f=open('Bin_group_total_raw_read.txt', 'w')
    #     f.write('Bin group repretative'+'\t'+'Total raw read (bp)'+'\n')
    # n=0
    # for item in bin_group_total_raw_read.keys():
    #     n+=1
    #     f.write(str(item)+'\t'+str(bin_group_total_raw_read[item])+'\n')
    # f.close()

    return bin_group, bin_group_total_raw_read

def split_assembly(new_super_group, bin_group, num_threads, n):
    print('Processing group '+str(n)+' : '+str(bin_group))
    f1=open('Group_'+str(n)+'_R1.fq','w')
    f2=open('Group_'+str(n)+'_R2.fq','w')
    xxx = 0
    for sub_bg in new_super_group[bin_group].keys():
        for bins in new_super_group[bin_group][sub_bg].keys():
            xxx+=1
            print('Processing group '+str(n)+'-'+str(xxx)+' '+str(bins))
            # x, xx, remove_line = 4, 0, {}
            # for line in open(str(bins)+'_seq_R1.fq','r'):
            #     x+=1
            #     if x%4 == 1:
            #         xx+=1
            #     elif x%4 == 2:
            #         try:
            #             records_seq[str(line).strip()]+=1
            #             remove_line[x]=1
            #             remove_line[x+1]=2
            #             remove_line[x+2]=3
            #             remove_line[x+3]=4
            #         except:
            #             records_seq[str(line).strip()]=0

            # x = 4
            # for line in open(str(bins)+'_seq_R1.fq','r'):
            #     x+=1
            #     try:
            #         remove_line[x]+=1
            #     except:
            #         f1.write(line)
        
            # x = 4
            # for line in open(str(bins)+'_seq_R2.fq','r'):
            #     x+=1
            #     try:
            #         remove_line[x]+=1
            #     except:
            #         f2.write(line)

            for line in open(str(bins)+'_seq_R1.fq','r'):
                f1.write(line)
        
            for line in open(str(bins)+'_seq_R2.fq','r'):
                f2.write(line)
    f1.close()
    f2.close()

def data_split_main(binset, datasets, initial_similarity, step, data_ratio, num_threads, ram, pwd):
    flog=open('Data_split_log.txt','w')
    A=mod_bin(binset, pwd)
    mod_bin_folder=A[0]
    total_fa=A[1]
    mod_bin_list=A[2]
    original_bins_checkm=A[3]
    record_seq=A[4]
    bin_total_len=A[5]
    fq, pair, bin_seq, bin_checkm={}, {}, {}, {}
    bin_checkm=original_bins_checkm.copy()
    for bin_id in mod_bin_list:
        fq[str(bin_id)]={}
        pair[str(bin_id)]={}
        bin_seq[str(bin_id)]=[]
        # f1=open(str(bin_id)+'_seq_R1.fq','w')
        # f2=open(str(bin_id)+'_seq_R2.fq','w')
        bin_seq[str(bin_id)].append(str(bin_id)+'_seq_R1.fq')
        bin_seq[str(bin_id)].append(str(bin_id)+'_seq_R2.fq')
        # f1.close()
        # f2.close()
    # f_not_mapped_reads1=open('Not_mapped_reads_R1.fq','w')
    # f_not_mapped_reads1.close()
    # f_not_mapped_reads2=open('Not_mapped_reads_R2.fq','w')
    # f_not_mapped_reads2.close()

    # mapping_sr(total_fa, datasets, fq, pair, num_threads)
    print('Calculating raw reads')
    n=0
    for bin_id in bin_seq.keys():
        n+=1
        if n == 1:
            n1=0
            for line in open(bin_seq[bin_id][0],'r'):
                n1+=1
                if n1 == 2:
                    single_read_len=len(line.strip())
                    break
        else:
            break

    bin_id_raw_seq={}
    for bin_id in bin_seq.keys():
        bin_id_raw_seq[bin_id]=0
        # print('Reading', str(bin_seq[bin_id][0]))
        n=0
        for line in open(bin_seq[bin_id][0],'r'):
            n+=1
        
        seq_num=int(n/4)
        bin_id_raw_seq[bin_id]=2*single_read_len*seq_num
    
    n = 0
    for line in open('Not_mapped_reads_R1.fq', 'r'):
        n+=1
    seq_num=int(n/4)
    unmapped = 2*single_read_len*seq_num
    
    read_bp=1000000000*ram/data_ratio
    read_mbp=1000*ram/data_ratio
    print('Data limited to '+str(read_mbp)+' Mbp')
    flog.write('Data limited to '+str(read_bp)+'\n')
    if unmapped > read_bp:
        print('Set RAM probably insufficient. Please try to increase the RAM and try later')
    else:
        similarity_list, x=[], initial_similarity
        while x < 100:
            similarity_list.append(x)
            x+=step

        print('Aligning sequences')
        # try:
        #     os.system('makeblastdb -in '+str(total_fa)+' -dbtype nucl -hash_index -parse_seqids -logfile temp_db.txt')
        #     os.system('blastn -query '+str(total_fa)+' -db '+str(total_fa)+' -evalue 1e-20 -outfmt 6 -num_threads '+str(num_threads)+' -out total_blast.txt')
        #     os.system('rm temp_db.txt *.nhi *.nhd *.nsq *.nsi *.nog *.nin *.nhr *.nsd')
        # except:
        #     print('Alignment error! Please check whether BLAST+ is installed in your system')

        ftest=open('Group_bin.txt','w')
        super_group_bin, super_group_value, grouped_bin, remove_bin, xxx, i = [], [], {}, {}, 0, 0
        while xxx == 0 and i < len(similarity_list):
            similarity=similarity_list[i]
            print(str(i+1)+' try: simialrity '+str(similarity)+'%')
            flog.write(str(i+1)+' try: simialrity '+str(similarity)+'%'+'\n')
            bin_group_total_raw_read = {}
            # bin_group_total_raw_read['Unmapped']=unmapped

            A=group_bin(bin_id_raw_seq, bin_total_len, remove_bin, similarity)
            bins_group=A[0]
            bin_group_total_raw_read.update(A[1])
            #print(str(bins_group))
            bin_group_total_raw_read_order=sorted(bin_group_total_raw_read.items(), key=lambda x:x[1], reverse=False)
            # print(bin_group_total_raw_read_order)

            f=open('Group_raw_read.txt','w')
            for group in bin_group_total_raw_read_order:
                f.write(str(group)+'\n')
            f.close()

            x, xx = 0, 0
            for group in bin_group_total_raw_read_order:
                x+=1
                group_key=str(group).split(',')[0].replace('\'','').replace('(','')
                group_value=int(str(group).split(',')[1].strip().replace('\'','').replace(')',''))
                value_t=group_value+int(unmapped)
                if value_t > read_bp:
                    print('Sub-data '+str(group_key)+' is too big to assembly. Trying to reduce the sub-data')
                    flog.write('Sub-data '+str(group_key)+' is too big to assembly. Trying to reduce the sub-data'+'\n')
                else:
                    xx+=1
                    super_group_bin.append(group_key)
                    super_group_value.append(group_value)
                    bin_list=str(str(bins_group[group_key]).replace(' ', '').replace('\'', '').replace('{', '').replace('}', '')).split(',')
                    for binss in bin_list:
                        print(bin_list)
                        print(binss)
                        try:
                            grouped_bin[str(group_key)][binss.replace('\'','').replace(' ','').split(':')[0]]=int(binss.replace('\'','').replace(' ','').split(':')[1].strip())
                        except:
                            grouped_bin[str(group_key)]={}
                            grouped_bin[str(group_key)][binss.replace('\'','').replace(' ','').split(':')[0]]=int(binss.replace('\'','').replace(' ','').split(':')[1].strip())
                    ftest.write(str(group_key)+'\t'+str(similarity)+'%'+'\t'+str(bin_list).replace('\'','').replace(' ','')+'\t'+str(group_value)+'\n')
                    for bins in bin_list:
                        remove_bin[bins.split(':')[0].strip()]=int(bins.split(':')[1].strip())

            if x == xx:
                xxx=1
            else:
                i+=1
        ftest.close()

        bin_in_group={}
        for line in open('Group_bin.txt', 'r'):
            bin_list=str(line).replace('\'','').split('[')[1].split(']')[0].split(',')
            for bins in bin_list:
                try:
                    bin_in_group[bins.split(':')[0].strip()]+=1
                except:
                    bin_in_group[bins.split(':')[0].strip()]=0

        ft=open('bin_in_group.txt','w')
        for item in bin_in_group.keys():
            ft.write(str(item)+'\t'+str(bin_in_group[item])+'\n')
        ft.close()

        super_group_solo_bin, super_group_solo_value =[], []
        ftest=open('Group_bin.txt','a')
        for bins in mod_bin_list:
            if bins not in bin_in_group.keys():
                super_group_solo_bin.append(str(bins))
                super_group_solo_value.append(bin_id_raw_seq[bins])
                ftest.write(str(bins)+'\t'+'solo'+'\t'+'['+str(bins)+':'+str(bin_id_raw_seq[bins])+']'+'\t'+str(bin_id_raw_seq[bins])+'\n')
        ftest.close()
        
        delta_bp=read_bp-int(unmapped)
        print('Fetch super-group for assembly')
        remove_group, super_group, super_group2_value, t = {}, {}, {}, 0
        if len(super_group_solo_bin) != 0:
            for i in range(0, len(super_group_bin)):
                t=super_group_value[i]
                for i2 in range(0, len(super_group_solo_bin)):
                    t+=super_group_solo_value[i2]
                    if t < delta_bp and super_group_solo_bin[i2] not in remove_group.keys():
                        bin_group = super_group_bin[i]
                        remove_group[bin_group]=1
                        remove_group[super_group_solo_bin[i2]]=2
                        try:
                            super_group[bin_group][super_group_solo_bin[i2]]=super_group_solo_value[i2]
                        except:
                            super_group[bin_group]={}
                            super_group[bin_group][super_group_solo_bin[i2]]=super_group_solo_value[i2]
                            super_group[bin_group].update(grouped_bin[bin_group])
                        super_group2_value[bin_group]=t

        super_group_solo_bin2=copy.deepcopy(super_group_solo_bin)
        for i in range(0, len(super_group_solo_bin2)):
            bin_group=super_group_solo_bin2[i]
            if bin_group not in remove_group.keys():
                super_group[bin_group]={}
                super_group[bin_group][bin_group]=super_group_solo_value[i]
                super_group2_value[bin_group]=super_group_solo_value[i]
                
        for i in range(0, len(super_group_bin)):
            bin_group = super_group_bin[i]
            if bin_group not in remove_group.keys():
                super_group[bin_group]={}
                super_group[bin_group].update(grouped_bin[bin_group])
                super_group2_value[bin_group]=super_group_value[i]

        # f1=open('Raw_group.txt','w')
        super_group_list=[]
        for bin_group in super_group.keys():
            # f1.write(str(bin_group)+'\t'+str(super_group[bin_group])+'\n')
            super_group_list.append(bin_group)
        # f1.close()

        new_group, new_group_value, remove_bin_group_t ={}, {}, {}
        for i in range(0, len(super_group_list)):
            bin_group1=super_group_list[i]
            if bin_group1 not in remove_bin_group_t.keys():
                new_group[bin_group1]={}
                new_group[bin_group1][bin_group1]=super_group2_value[bin_group1]
                new_group_value[bin_group1]=super_group2_value[bin_group1]
                for i2 in range(i+1, len(super_group_list)):
                    bin_group2=super_group_list[i2]
                    tt=new_group_value[bin_group1]+super_group2_value[bin_group2]
                    if tt < delta_bp and bin_group2 not in remove_bin_group_t.keys():
                        remove_bin_group_t[bin_group2]=0
                        new_group[bin_group1][bin_group2]=super_group2_value[bin_group2]
                        new_group_value[bin_group1]=tt
        
        # f2=open('Test2.txt','w')
        # for bin_group in new_group.keys():
        #     f2.write(str(bin_group)+'\t'+str(new_group[bin_group])+'\t'+str(new_group_value[bin_group])+'\n')
        # f2.close()

        new_super_group, bins_recorded ={}, {}
        for s_bin_g in new_group.keys():
            if s_bin_g not in remove_bin_group_t.keys():
                new_super_group[s_bin_g]={}
                for sub_g in new_group[s_bin_g].keys():
                    new_super_group[s_bin_g][sub_g]={}
                    new_super_group[s_bin_g][sub_g].update(super_group[sub_g])
                    for bins in super_group[sub_g].keys():
                        try:
                            bins_recorded[bins]+=1
                        except:
                            bins_recorded[bins]=0
        
        # f=open('Recorded_bins.txt','w')
        # for bins in bins_recorded.keys():
        #     f.write(str(bins)+'\t'+str(bins_recorded[bins])+'\n')
        # f.close()

        ft=open('Super_group_for_assembly.txt','w')
        for item in new_super_group.keys():
            ft.write(str(item)+'\t'+str(new_super_group[item])+'\t'+str(new_group_value[item])+'\n')
        ft.close()

        print('Data splitted to '+str(len(new_super_group))+' parts for further assembly')
        n=0
        for bin_group in new_super_group.keys():
            n+=1
            split_assembly(new_super_group, bin_group, num_threads, n)
        
if __name__ == '__main__': 
    assembly_list=['XP-T0-3_contigs.fasta','XP-T0-3_contigs.fasta','XP-T0-3_contigs.fasta']
    datasets={'1':['PE_r1_RH_S001_insert_270_mate1.fq','PE_r2_RH_S001_insert_270_mate2.fq'],'2':['PE_r1_RH_S002_insert_270_mate1.fq','PE_r2_RH_S002_insert_270_mate2.fq'],'3':['PE_r1_RH_S003_insert_270_mate1.fq','PE_r2_RH_S003_insert_270_mate2.fq'],'4':['PE_r1_RH_S004_insert_270_mate1.fq','PE_r2_RH_S004_insert_270_mate2.fq'],'5':['PE_r1_RH_S005_insert_270_mate1.fq','PE_r2_RH_S005_insert_270_mate2.fq']}
    num_threads=44
    ram=2200
    pwd=os.getcwd()
    binset='BestBinset'
    initial_similarity=2
    step=3
    data_ratio=15 ### Community with 1) medium or low compaxity; ratio: 5; 2) high compaxity: ratio: 10
    data_split_main(binset, datasets, initial_similarity, step, data_ratio, num_threads, ram, pwd)
