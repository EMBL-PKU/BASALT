#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

import pandas as pd
# import seaborn as sns
# import matplotlib.pyplot as plt
from Bio import SeqIO
import os, copy
from sklearn.decomposition import PCA
import numpy as np
from multiprocessing import Pool

def record_bin_coverage(best_binset_from_multi_assemblies, coverage_list, connections_list):
    pwd=os.getcwd()
    bin_contigs, bin_contigs_mock, total_bin_contigs, assembly_list, m={}, {}, {}, {}, 0
    print('Parsing bins')
    for root, dirs, files in os.walk(pwd+'/'+str(best_binset_from_multi_assemblies)):
        os.chdir(pwd+'/'+str(best_binset_from_multi_assemblies))
        for file in files:
            if '_genomes.' in file:
                hz=file.split('_genomes.')[1]
                qz=file.split('_genomes.')[0]
                assembly_name_list=qz.split('_')
                assembly_name_list.remove(assembly_name_list[-1])
                assembly_name_list.remove(assembly_name_list[-1])
                assembly_name='_'.join(assembly_name_list)
                assembly_list[assembly_name]=1
            else:
                hz=file.split('.')[-1]

            if 'fasta' in hz or 'fa' in hz:
                m+=1
                bin_contigs[file]={}
                bin_contigs_mock[file]={}
                for record in SeqIO.parse(file, 'fasta'):
                    total_bin_contigs[str(record.id)]=str(record.seq)
                    bin_contigs[file][str(record.id)]=str(record.seq)
                    bin_contigs_mock[file][str(record.id)]=0
    print('Parsed '+str(m)+' bins')

    os.chdir(pwd)
    coverage=open('Coverage_matrix_HBS_refined.txt', 'w')
    coverage.write('Name'+'\t'+'Length'+'\t'+'totalCoverage'+'\t'+'avgCoverage'+'\t'+'Coverage'+'\n')
    connection_file=open('condense_connections_HBS_refined.txt', 'w')
    connection_file.write('node1'+'\t'+'interaction'+'\t'+'node2'+'\t'+'connections'+'\n')
    for item in coverage_list:
        n=0
        for line in open(item,'r'):
            n+=1
            if n >= 2:
                coverage.write(line)

    for item in connections_list:
        n=0
        for line in open(item,'r'):
            n+=1
            if n >= 2:
                connection_file.write(line)

    coverage.close()
    connection_file.close()
    
    f=open('Refined_total_bins_contigs.fa', 'w')
    for item in total_bin_contigs.keys():
        f.write('>'+str(item)+'\n'+str(total_bin_contigs[item])+'\n')
    f.close()

    print('Recording the coverage of contigs from bins')
    n, contig_cov=0, {}
    for line in open('Coverage_matrix_HBS_refined.txt','r'):
        n+=1
        if n >= 2:
            ls=str(line).strip().split('\t')
            num=int((len(ls)-4)/3)
            ids=str(line).strip().split('\t')[0]
            contig_cov[ids]={}
            for i in range(1,num+1):
                contig_cov[ids][i]=float(str(line).strip().split('\t')[3*i+1])
        
    bin_contig_cov={}    
    for contig_id in contig_cov.keys():
        for bin_name in bin_contigs.keys():
            if bin_name not in bin_contig_cov.keys():
                bin_contig_cov[bin_name]={} 
            bin_contigs_mock[bin_name][contig_id]=1
            # if contig_id in bin_contigs[bin_name].keys():
            if len(bin_contigs_mock[bin_name]) == len(bin_contigs[bin_name]):
                bin_contig_cov[bin_name][contig_id]={} 
                for i in range(1,num+1):
                    bin_contig_cov[bin_name][contig_id][i]=contig_cov[contig_id][i]
            else:
                del bin_contigs_mock[bin_name][contig_id]
        
    print('Writing bin coverage matrix file')
    os.system('mkdir bin_coverage')
    os.chdir('bin_coverage')
    for bins in bin_contig_cov.keys():
        f=open(bins+'_coverage_matrix.txt', 'w')
        f.write('Bin'+'\t'+'Coverage'+'\n')
        for contigs in bin_contig_cov[bins].keys():
            f.write(str(contigs)+'\t'+str(bin_contig_cov[bins][contigs])+'\n')
        f.close()
    os.chdir(pwd)
    return bin_contig_cov, bin_contigs, 'Refined_total_bins_contigs.fa', 'condense_connections_HBS_refined.txt'

def outliner_remover(bin_id, contigs_ids, threshold, item_data, explained_variance_ratio, bin_outliner, outlier_type):
    print('Finding outliner from '+bin_id)
    four = pd.Series(item_data).describe()
    for item in threshold:
        f1=open('Outlier_in_threshold'+str(item)+'_'+str(bin_id)+'.txt', 'w')
        f2=open('Summary_threshold'+str(item)+'_'+str(bin_id)+'.txt', 'w')
        print(four)
        print('Q1= {0}, Q2= {1}, Q3={2}'.format(four['25%'],four['50%'],four['75%']))
        Q1 = four['25%']
        Q3 = four['75%']
        IQR = Q3 - Q1
        upper1 = Q3 + float(item) * IQR
        lower1 = Q1 - float(item) * IQR
        upper2 = 2*Q3 + 3*IQR
        lower2 = 2*Q1 - 3*IQR
        print(upper1, lower1)
        n1, outliner_record=0, {}
        for i in range(0, len(item_data)):
            if item_data[i] > float(upper1) or item_data[i] < float(lower1):
                n1+=1
                f1.write(str(contigs_ids[i])+'\t'+str(item_data[i])+'\n')
                if str(item) not in bin_outliner[str(bin_id)].keys():
                    bin_outliner[str(bin_id)][str(item)]=[]
                    bin_outliner[str(bin_id)][str(item)].append(str(contigs_ids[i]))
                else:
                    bin_outliner[str(bin_id)][str(item)].append(str(contigs_ids[i]))

        f1.close()
        f2.write(str(four)+'\n'+str('Q1= {0}, Q2= {1}, Q3={2}'.format(four['25%'],four['50%'],four['75%']))+'\n'+'Upper:'+str(upper1)+'\t'+'Lower:'+str(lower1)+'\n'+str(n1)+' outliers in '+str(bin_id)+' under the threshold of '+str(item)+'\n'+'Explained variance ratio:'+str(explained_variance_ratio)+'\n')
        f2.close()
        print(str(n1)+' outliers in '+str(bin_id)+' with threshold of '+item)
        print('-------------------------')
    return bin_outliner

def PCA_slector(data_array, num_contig):
    pca = PCA(n_components=1)
    pca.fit(data_array)
    explained_variance_ratio=pca.explained_variance_ratio_
    print(explained_variance_ratio)
    # num=len(explained_variance_ratio)
    newData=pca.fit_transform(data_array)
    newData2=newData.reshape((1,num_contig))
    # print('Shape', num, num_contig
    newData_list=newData2.tolist()
    n=0
    for item in newData_list:
        n+=1
        if n == 1:
            newData_list_item=item
    return newData_list_item, explained_variance_ratio

def cov_materix(bin_contig_cov, bin_contig, threshold, folder_binset):
    pwd=os.getcwd()
    print('Transfroming')
    os.system('mkdir bin_cov_outliner')
    bin_outliner={}
    for bin_id in bin_contig_cov.keys():
        bin_outliner[bin_id]={}
        coverage_data, contigs_ids, coverage_list, num_contig={}, [], [], 0
        for contig in bin_contig_cov[bin_id].keys():
            num_contig+=1
            contigs_ids.append(contig)
            num_coverage=len(bin_contig_cov[bin_id][contig])
            for i in range(1, num_coverage+1):
                if i not in coverage_data.keys():
                    coverage_data[i]=[]
                coverage_data[i].append(bin_contig_cov[bin_id][contig][i])
                coverage_list.append(bin_contig_cov[bin_id][contig][i])

        coverage_array=np.array(coverage_list).reshape((num_contig,num_coverage))

        os.chdir('bin_cov_outliner')
        A=PCA_slector(coverage_array, num_contig)
        newData=A[0]
        explained_variance_ratio=A[1]
        bin_outliner=outliner_remover(bin_id, contigs_ids, threshold, newData, explained_variance_ratio, bin_outliner, 'cov')
        os.chdir(pwd)
    
    os.system('mkdir '+str(folder_binset)+'_coverage_refined')
    os.chdir(str(folder_binset)+'_coverage_refined')
    outliner_sum=open('Summary_ct_outliers.txt','w')
    outliner_sum.write('Bin'+'\t'+'Threshold'+'\t'+'Outliners'+'\n')
    for item in bin_outliner.keys():
        for th in bin_outliner[item].keys():
            if len(bin_outliner[item][th]) != 0:
                outliner_sum.write(str(item)+'\t'+str(th)+'\t'+str(bin_outliner[item][th])+'\n')
    outliner_sum.close()

    bin_outliner2={}
    bin_outliner2=copy.deepcopy(bin_outliner)
    for item in bin_outliner2.keys():
        dereplicate={}
        for th in bin_outliner2[item].keys():
            if len(bin_outliner2[item][th]) not in dereplicate.keys():
                dereplicate[len(bin_outliner2[item][th])]=float(th)
            else:
                if float(th) > dereplicate[len(bin_outliner2[item][th])]:
                    del bin_outliner[item][th]

    for item in bin_contig.keys():
        if item in bin_outliner.keys():
            for th in bin_outliner[item].keys():
                f=open(item+'_ct_'+str(th)+'.fa','w')
                for contig in bin_contig[item].keys():
                    if contig not in bin_outliner[item][th]:
                        f.write('>'+str(contig)+'\n'+str(bin_contig[item][contig])+'\n')
                f.close()
    os.chdir(pwd)
    return str(folder_binset)+'_coverage_refined'

def splitting_kmer_file(item, assembly, bin_contigs_mock, pwd):
    print('Splitting kmer file, '+item)
    f=open(item+'_kmer.txt', 'w')
    n = 0
    # for line in open(pwd+'/'+assembly+'.kmer.txt', 'r'):
    for line in open(pwd+'/'+assembly+'.kmer.txt', 'r'):
        n+=1
        if n >= 2:
            # print(str(line).strip())
            contig=str(line).strip().split('\t')[0]
            num=len(bin_contigs_mock[item])
            bin_contigs_mock[item][contig]=1
            if len(bin_contigs_mock[item]) == num:
                f.write(str(line))
            else:
                del bin_contigs_mock[item][contig]
    f.close()

def TNFs_refiner(binset, assembly, coverage_refined_folder, threshold, pwd, num_threads):
    os.system('mkdir '+binset+'_TNFs_outliner')
    os.system('mkdir '+binset+'_TNFs')
    print('Calculating TNFs of '+assembly)
    os.system('calc.kmerfreq.pl -i '+str(assembly)+' -o '+str(assembly)+'.kmer.txt')
    
    os.chdir(pwd+'/'+coverage_refined_folder)
    bin_contigs, bin_contigs_mock, bin_outliner={}, {}, {}
    for root, dirs, files in os.walk(pwd+'/'+coverage_refined_folder):
        for file in files:
            if '_genomes.' in file:
                hz=file.split('_genomes.')[1]
                if '.fa' in hz:
                    bin_outliner[file]={}
                    bin_contigs[file]={}
                    bin_contigs_mock[file]={}
                    for record in SeqIO.parse(file, 'fasta'):
                        bin_contigs[file][record.id]=record.seq
                        bin_contigs_mock[file][record.id]=1
    
    os.chdir(pwd+'/'+binset+'_TNFs')
    Bins_TNFs, bin_contig_list={}, {}
    pool=Pool(processes=num_threads)
    for item in bin_contigs.keys():
        pool.apply_async(splitting_kmer_file, args=(item, assembly, bin_contigs_mock, pwd))
    pool.close()
    pool.join()

    for item in bin_contigs.keys():
        Bins_TNFs[item], bin_contig_list[item] = [], []
        for line in open(pwd+'/'+binset+'_TNFs/'+item+'_kmer.txt', 'r'):
            contig=str(line).strip().split('\t')[0]
            lis=str(line).strip().split('\t')
            bin_contig_list[item].append(contig)
            for i in range(1, len(lis)):
                Bins_TNFs[item].append(lis[i])
    # print(str(Bins_TNFs))

    for item in Bins_TNFs.keys():
        print('Processing TNFs of bin '+item)
        num_contig=len(bin_contigs[item])
        TNF_array=np.array(Bins_TNFs[item]).reshape((num_contig, 256))
        os.chdir(pwd+'/'+binset+'_TNFs_outliner')
        A=PCA_slector(TNF_array, num_contig)
        newData=A[0]
        explained_variance_ratio=A[1]
        bin_outliner=outliner_remover(item, bin_contig_list[item], threshold, newData, explained_variance_ratio, bin_outliner, 'TNF')
        os.chdir(pwd)
    
    os.system('mkdir '+str(binset)+'_TNFs_refined')
    os.chdir(str(binset)+'_TNFs_refined')
    outliner_sum=open('Summary_TNFs_outliners.txt','w')
    outliner_sum.write('Bin'+'\t'+'Threshold'+'\t'+'Outliners'+'\n')
    for item in bin_outliner.keys():
        for th in bin_outliner[item].keys():
            if len(bin_outliner[item][th]) != 0:
                outliner_sum.write(str(item)+'\t'+str(th)+'\t'+str(bin_outliner[item][th])+'\n')
    outliner_sum.close()

    bin_outliner2={}
    bin_outliner2=copy.deepcopy(bin_outliner)
    for item in bin_outliner2.keys():
        dereplicate={}
        for th in bin_outliner2[item].keys():
            if len(bin_outliner2[item][th]) not in dereplicate.keys():
                dereplicate[len(bin_outliner2[item][th])]=float(th)
            else:
                if float(th) > dereplicate[len(bin_outliner2[item][th])]:
                    del bin_outliner[item][th]

    for item in bin_contigs.keys():
        for th in bin_outliner[item].keys():
            f=open(item+'_TNFs_'+str(th)+'.fa','w')
            for contig in bin_contigs[item].keys():
                if contig not in bin_outliner[item][th]:
                    f.write('>'+str(contig)+'\n'+str(bin_contigs[item][contig])+'\n')
            f.close()
    os.chdir(pwd)

def parse_connections(binset, PE_connections_file):
    print('Parsing PE-connections file')
    pwd=os.getcwd()
    os.chdir(pwd+'/'+binset)
    bin_connections, bin_contig={}, {}
    for root, dirs, files in os.walk(pwd+'/'+binset):
        for file in files:
            bin_contig[file]=[]
            for record in SeqIO.parse(file, 'fasta'):
                bin_contig[file].append(record.id)

    os.chdir(pwd)
    for item in bin_contig.keys():
        n, connections=0, {}
        for line in open(PE_connections_file,'r'):
            n+=1
            if n >= 2:
                id1=str(line).strip().split('\t')[0]
                id2=str(line).strip().split('\t')[2]
                connections_no=int(str(line).strip().split('\t')[3])
                if id1 in bin_contig[item]:
                    if id2 not in bin_contig[item]:
                        if item not in bin_connections.keys():
                            bin_connections[item]=connections_no
                        else:
                            bin_connections[item]+=connections_no
                elif id2 in bin_contig[item]:
                    if item not in bin_connections.keys():
                        bin_connections[item]=connections_no
                    else:
                        bin_connections[item]+=connections_no
    
    os.chdir(pwd+'/'+binset)
    f=open('Refined_bin_connections.txt', 'w')
    for item in bin_connections.keys():
        f.write(item+'\t'+str(bin_connections[item])+'\n')
    f.close()
    os.chdir(pwd)
    return bin_connections

def bin_comparison(binset, refined_binset, bin_format, com_type, num_threads, pwd):
# def bin_comparison(binset, refined_binset, bin_format, bin_connections, com_type, num_threads, pwd):
    # pwd=os.getcwd()
    n=0
    for root, dirs, files in os.walk(pwd+'/'+str(refined_binset)):
        for file in files:
            hz=str(file).split('.')[-1]
            if 'fa' in hz:
                n+=1

    num_split_folder=1
    if n <= 500:
        os.system('checkm lineage_wf -t '+str(num_threads)+' -x fa '+str(refined_binset)+' '+str(refined_binset)+'_checkm')
    elif n%500 == 0:
        num_split_folder=int(n/500)
    else:
        num_split_folder=int(n/500)+1
        
    if num_split_folder != 1:
        folder_list=[]
        for i in range(1, num_split_folder+1):
            os.system('mkdir '+str(refined_binset)+'_'+str(i))
            folder_list.append(str(refined_binset)+'_'+str(i))

        bin_name_split=int(n/num_split_folder)+1

        n, i = 0, 1
        os.chdir(pwd+'/'+str(refined_binset))
        for root, dirs, files in os.walk(pwd+'/'+str(refined_binset)):
            for file in files:
                hz=str(file).split('.')[-1]
                if 'fa' in hz:
                    n+=1
                    if n < bin_name_split:
                        os.system('cp '+str(file)+' '+str(pwd)+'/'+str(refined_binset)+'_'+str(i))
                    elif n == bin_name_split:
                        os.system('cp '+str(file)+' '+str(pwd)+'/'+str(refined_binset)+'_'+str(i))
                        i+=1
                        n=0

        os.chdir(pwd)
        checkm_result=[]
        for item in folder_list:
            os.system('checkm lineage_wf -t '+str(num_threads)+' -x fa '+str(item)+' '+str(item)+'_checkm')
            for line in open(str(item)+'_checkm/storage/bin_stats_ext.tsv','r'):
                checkm_result.append(str(line))

        os.system('mkdir '+str(refined_binset)+'_checkm')
        os.system('mkdir '+str(refined_binset)+'_checkm/storage')
        os.chdir(str(refined_binset)+'_checkm/storage')
        f=open('bin_stats_ext.tsv','w')
        for item in checkm_result:
            f.write(item)
        f.close()
        os.chdir(pwd)

    os.chdir(refined_binset+'_checkm/storage/')
    refined_checkm={}
    print('Parsing BestBinset_refined checkm output')
    for line in open('bin_stats_ext.tsv','r'):
        binID=str(line).strip().split('{\'')[0].strip()
        genome_size=str(line).strip().split('Genome size\':')[1].split('}')[0].split(',')[0].strip()
        taxon=str(line).strip().split('lineage')[1].split('}')[0].split('\'')[2].strip()
        completeness=str(line).strip().split('Completeness')[1].split('}')[0].split(':')[1].split(',')[0].strip()
        contamination=str(line).strip().split('Contamination')[1].split('}')[0].split(':')[1].split(',')[0].strip()
        Mean_scaffold_length=str(line).strip().split('Mean scaffold length')[1].split('}')[0].split(':')[1].strip()

        refined_checkm[str(binID)]={}
        # if str(binID)+'.fa' in bin_connections.keys():
        #     refined_checkm[str(binID)]['Connections']=int(bin_connections[str(binID)+'.fa'])
        # else:
        #     refined_checkm[str(binID)]['Connections']=0
        refined_checkm[str(binID)]['marker lineage']=str(taxon)
        refined_checkm[str(binID)]['Completeness']=float(completeness)
        refined_checkm[str(binID)]['Genome size']=float(eval(genome_size))
        refined_checkm[str(binID)]['Contamination']=float(contamination)
        refined_checkm[str(binID)]['Mean scaffold length']=str(Mean_scaffold_length)

    os.chdir(pwd+'/'+str(binset))
    bin_checkm, bin_seq_rec = {}, {}
    for root, dirs, files in os.walk(pwd+'/'+str(binset)):
        for file in files:
            if '_bin_stats_ext.tsv' in file:
                print('Processing '+str(file))
                for line in open(file, 'r'):
                    binID=str(line).strip().split('\t')[0].strip()
                    completeness=float(str(line).strip().split('Completeness\':')[1].split('}')[0].split(',')[0].strip())
                    genome_size=str(line).strip().split('Genome size\':')[1].split('}')[0].split(',')[0].strip()
                    taxon=str(line).strip().split('lineage')[1].split('}')[0].split(',')[0].split('\'')[2].strip()
                    contamination=str(line).strip().split('Contamination')[1].split(':')[1].split('}')[0].split(',')[0].strip()
                    Mean_scaffold_length=str(line).strip().split('Mean scaffold length')[1].split(':')[1].split(',')[0].split('}')[0].strip()

                    bin_checkm[str(binID)]={}
                    # bin_checkm[str(binID)]['Connections']=int(connections)
                    bin_checkm[str(binID)]['marker lineage']=str(taxon)
                    bin_checkm[str(binID)]['Completeness']=float(completeness)
                    bin_checkm[str(binID)]['Genome size']=float(eval(genome_size))
                    bin_checkm[str(binID)]['Contamination']=float(contamination)
                    bin_checkm[str(binID)]['Mean scaffold length']=str(Mean_scaffold_length)
            else:
                bin_id_list=str(file).split('.')
                bin_id_list.remove(bin_id_list[-1])
                bin_id='.'.join(bin_id_list)
                if 'fa' in str(file).split('.')[-1]:
                    bin_seq_rec[bin_id]={}
                    for record in SeqIO.parse(file, 'fasta'):
                        bin_seq_rec[bin_id][record.id]=record.seq

    print('Comparing bins before and after refining process')
    os.chdir(pwd+'/'+str(refined_binset))
    bin_comparison, bin_comparison_list={}, {}
    for refined_bin in refined_checkm.keys():
        if com_type == 'coverage':
            ids=refined_bin.split('_ct_')[0]
        elif com_type == 'TNFs':
            ids=refined_bin.split('_TNFs_')[0]
        ids_list=ids.split('.')
        ids_list.remove(ids_list[-1])
        bin_id='.'.join(ids_list)
        # print(refined_bin
        # print(bin_id
        if bin_id in bin_checkm.keys():
            if bin_id not in bin_comparison.keys():
                bin_comparison[bin_id]=bin_id+'---'+refined_bin
                bin_comparison_list[bin_id]=[]
                bin_comparison_list[bin_id].append(bin_id)
                bin_comparison_list[bin_id].append(refined_bin)
            else:
                bin_comparison[bin_id]+='---'+refined_bin
                bin_comparison_list[bin_id].append(refined_bin)
    
    f=open('Refined_bin_comparison_after_outlier_removal.txt','w')
    f.write('Bin'+'\t'+'Related_bin'+'\t'+'checkm'+'\n')
    f2=open('Deep_refine_bins.txt', 'w')
    f3=open('Outlier_removal_different_para_bins.txt','w')
    bestbin, further_refined_bin={}, {}
    for item in bin_comparison_list.keys():
        bestbin[item]={}
        write_out=str(item)+'\t'+(bin_comparison[item])
        for i in range(0, len(bin_comparison_list[item])):
            if i == 0:
                bin_id=bin_comparison_list[item][i]
                write_out+='\t'+str(bin_checkm[bin_id])
                bestbin[item][bin_id]={}
                bestbin[item][bin_id]=bin_checkm[bin_id]
            else:
                refined_bin_id=bin_comparison_list[item][i]
                write_out+='---'+str(refined_checkm[refined_bin_id])
                # re_connections=int(refined_checkm[refined_bin_id]['Connections'])
                re_cpn=float(refined_checkm[refined_bin_id]['Completeness'])
                re_ctn=float(refined_checkm[refined_bin_id]['Contamination'])
                re_taxon=str(refined_checkm[refined_bin_id]['marker lineage'])
                re_genome_size=float(refined_checkm[refined_bin_id]['Genome size'])
                re_contig_len=str(refined_checkm[refined_bin_id]['Mean scaffold length'])
                re_delta=re_cpn-re_ctn
                re_2delta=re_cpn-2*re_ctn
                for bin_id2 in bestbin[item].keys():
                    ori_bin=bin_id2 
                    # ori_connections=int(bestbin[item][bin_id2]['Connections'])
                    ori_cpn=float(bestbin[item][bin_id2]['Completeness'])
                    ori_ctn=float(bestbin[item][bin_id2]['Contamination'])
                    ori_taxon=str(bestbin[item][bin_id2]['marker lineage'])
                    ori_genome_size=float(bestbin[item][bin_id2]['Genome size'])
                    ori_contig_len=str(bestbin[item][bin_id2]['Mean scaffold length'])
                    ori_delta=ori_cpn-ori_ctn
                    ori_2delta=ori_cpn-2*ori_ctn
                
                if re_2delta > ori_2delta:
                    del bestbin[item][ori_bin]
                    bestbin[item][refined_bin_id]=refined_checkm[refined_bin_id]
                    if re_cpn < ori_cpn and ori_cpn >= 40 and ori_ctn<= 15 and re_ctn <= 50:
                        further_refined_bin[refined_bin_id]=item
                        f2.write(str(item)+'\t'+str(refined_bin_id)+'\n')
                        f3.write(str(refined_bin_id)+'\t'+'Deep_refinemennt'+'\n')
                    else:
                        f3.write(str(refined_bin_id)+'\t'+'Normal_refinemennt'+'\n')
                elif re_delta > ori_delta: 
                    if ori_cpn >= 40 and ori_ctn<= 15 and re_ctn <= 50:
                        further_refined_bin[refined_bin_id]=item
                        f2.write(str(item)+'\t'+str(refined_bin_id)+'\n')
                        f3.write(str(refined_bin_id)+'\t'+'Deep_refinemennt'+'\n')
                elif re_2delta == ori_2delta:
                    ori_bin_num=ori_bin.split('_')[-1].split('.fa')[0]
                    if 'genomes' in ori_bin_num or 'OR-D' in ori_bin_num:
                        del bestbin[item][ori_bin]
                        bestbin[item][refined_bin_id]=refined_checkm[refined_bin_id] ### Remove original bin once the cpn and ctn same with both coverage refined and TNF refined bin
                        f3.write(str(refined_bin_id)+'\t'+'Remove_biggest_outlier_threshold'+'\n')
                    else:
                        num_ori=float(ori_bin_num)
                        num_re=float(refined_bin_id.split('_')[-1].split('.fa')[0])
                        if num_re > num_ori:
                            del bestbin[item][ori_bin]
                            bestbin[item][refined_bin_id]=refined_checkm[refined_bin_id]
                else:
                    continue
        f.write(str(write_out)+'\n')
    f.close()
    f2.close()
    f3.close()

    dr, del_ref_bin={}, {}
    for refined_bin_id in further_refined_bin.keys():
        org_bin=further_refined_bin[refined_bin_id]
        if org_bin in dr.keys():
            old_ref_num=float(dr[org_bin].split('_')[-1].split('.fa')[0])
            new_ref_num=float(refined_bin_id.split('_')[-1].split('.fa')[0])
            if new_ref_num > old_ref_num:
                del_ref_bin[dr[org_bin]]=''
                dr[org_bin]=refined_bin_id
            else:
                del_ref_bin[refined_bin_id]=''
        else:
            dr[org_bin]=refined_bin_id

    for refined_bin_id in del_ref_bin.keys():
        del further_refined_bin[refined_bin_id]

    os.chdir(pwd+'/'+str(refined_binset))
    selected_bin={}
    for item in bestbin.keys():
        for bins in bestbin[item].keys():
            selected_bin[bins]=str(item)
    print('Selected '+str(len(selected_bin))+' bins')
    print('Total '+str(len(bestbin))+' bins')

    n, further_refined_bin_contig = 0, {} 
    for root, dirs, files in os.walk(pwd+'/'+str(refined_binset)):
        for file in files:
            if '_genomes.' in file:
                ids_list=file.split('.')
                ids_list.remove(ids_list[-1])
                bin_id='.'.join(ids_list)
                if bin_id not in selected_bin.keys():
                    n+=1
                    os.system('rm '+file)
                else:
                    if bin_id in further_refined_bin.keys():
                        org_bin_id = further_refined_bin[bin_id]
                        further_refined_bin_contig[org_bin_id]={}
                        seq_id={}
                        for record in SeqIO.parse(file, 'fasta'):
                            seq_id[record.id]=''

                        for ids in bin_seq_rec[org_bin_id].keys():
                            if ids not in seq_id.keys():
                                further_refined_bin_contig[org_bin_id][ids]=bin_seq_rec[org_bin_id][ids]
    print('Removed '+str(n)+' refined bins')

    n=0
    os.chdir(pwd+'/'+str(binset))
    for root, dirs, files in os.walk(pwd+'/'+str(binset)):
        for file in files:     
            if '_genomes.' in file:
                ids_list=file.split('.')
                ids_list.remove(ids_list[-1])
                bin_id='.'.join(ids_list)
                if bin_id in bestbin.keys():
                    if bin_id in selected_bin.keys():
                        n+=1
                        os.system('cp '+file+' '+pwd+'/'+str(refined_binset))
                else:
                    n+=1
                    os.system('cp '+file+' '+pwd+'/'+str(refined_binset))
                    ids_list=file.split('.')
                    ids_list.remove(ids_list[-1])
                    bin_id='.'.join(ids_list)
                    selected_bin[bin_id]=bin_id
    print('Moved '+str(n)+' to refined bins folder')
    print('Selected '+str(len(selected_bin))+' bins')

    os.chdir(pwd+'/'+str(refined_binset))
    m, r=0, 0
    for root, dirs, files in os.walk(pwd+'/'+str(refined_binset)):
        for file in files:
            if '_genomes.' in file and '.fa' in file:
                m+=1
    r=m-n

    f=open('Selected_bin_after_outlier_removal_outlier_removed.txt', 'w')
    f.write('Summary: total '+str(m)+' bins in '+str(refined_binset)+' after outlier removal normal process, including '+str(n)+' bins from bestbinset, and '+str(r)+' bins obtained after '+str(com_type)+' from bestbinset'+'\n')
    f.write('Original bin'+'\t'+'Selected bin'+'\t'+'Factors'+'\n')
    for item in bestbin.keys():
        for bins in bestbin[item].keys():
            f.write(str(item)+'\t'+str(bins)+'\t'+str(bestbin[item][bins])+'\n')
    f.close()

    os.chdir(pwd)
    if len(further_refined_bin_contig) != 0:
        print('Processing '+str(com_type)+' deep refinement')
        try:
            os.system('mkdir '+str(com_type)+'_deep_refined_bins')
        except:
            print(str(com_type)+'_deep_refined_bins folder existed')

        os.chdir(pwd+'/'+str(com_type)+'_deep_refined_bins')
        f_contig_list=open('Contig_list.txt', 'w')
        os.chdir(pwd)

    for org_bin_id in further_refined_bin_contig.keys():
        print('Processing '+str(org_bin_id)+' '+str(com_type))
        os.system('mkdir '+org_bin_id+'_'+str(com_type)+'_deep_refinement')
        os.chdir(org_bin_id+'_'+str(com_type)+'_deep_refinement')
        f=open(org_bin_id+'.fa','w')
        for contigs_id in bin_seq_rec[org_bin_id].keys():
            f.write('>'+str(contigs_id)+'\n'+str(bin_seq_rec[org_bin_id][contigs_id])+'\n')
        f.close()

        contig_neutral, contig_positive, contig_negative, contig_positive_suspect, contig_negative_suspect, contig_num={}, {}, {}, {}, {}, {}
        n=0
        for contigs in further_refined_bin_contig[org_bin_id].keys():
            n+=1
            f=open(org_bin_id+'_deep_'+str(n)+'.fa','w')
            contig_num[n]=str(contigs)
            for contigs_id in bin_seq_rec[org_bin_id].keys():
                if contigs_id != contigs:
                    f.write('>'+str(contigs_id)+'\n'+str(bin_seq_rec[org_bin_id][contigs_id])+'\n')
            f.close()
        
        marker_lineage=bin_checkm[str(org_bin_id)]['marker lineage']
        if '__' in marker_lineage:
            marker_lineage_level=marker_lineage.split('__')[0].strip()
            marker_lineage_taxon=marker_lineage.split('__')[1].strip()
            if marker_lineage_level == 'k':
                marker_lineage_level_name='domain'
            elif marker_lineage_level == 'p':
                marker_lineage_level_name='phylum'
            elif marker_lineage_level == 'f':
                marker_lineage_level_name='family'
            elif marker_lineage_level == 'o':
                marker_lineage_level_name='order'
            elif marker_lineage_level == 'c':
                marker_lineage_level_name='class'
            elif marker_lineage_level == 's':
                marker_lineage_level_name='species'
            elif marker_lineage_level == 'g':
                marker_lineage_level_name='genus'
        elif 'root' in marker_lineage:
            marker_lineage_level_name='life'

        os.chdir(pwd)
        try:
            os.system('checkm taxonomy_wf -t 42 -x fa '+str(marker_lineage_level_name)+' '+str(marker_lineage_taxon)+' '+str(org_bin_id)+'_'+str(com_type)+'_deep_refinement '+str(org_bin_id)+'_'+str(com_type)+'_deep_refinement_checkm')
            for line in open(pwd+'/'+str(org_bin_id)+'_'+str(com_type)+'_deep_refinement_checkm/storage/bin_stats_ext.tsv', 'r'):
                print ('')
        except:
            os.system('rm -rf '+str(org_bin_id)+'_'+str(com_type)+'_deep_refinement_checkm')
            os.system('checkm lineage_wf -t 42 -x fa '+str(org_bin_id)+'_'+str(com_type)+'_deep_refinement '+str(org_bin_id)+'_'+str(com_type)+'_deep_refinement_checkm')

        for line in open(pwd+'/'+str(org_bin_id)+'_'+str(com_type)+'_deep_refinement_checkm/storage/bin_stats_ext.tsv', 'r'):
            bin_id=str(line).strip().split('\t')[0].strip()
            if bin_id == org_bin_id:
                org_bin_cpn=float(str(line).strip().split('Completeness\':')[1].split('}')[0].split(',')[0].strip())
                org_bin_ctn=float(str(line).strip().split('Contamination\':')[1].split('}')[0].split(',')[0].strip())
                ori_delta=org_bin_cpn-5*org_bin_ctn
        
        for line in open(pwd+'/'+str(org_bin_id)+'_'+str(com_type)+'_deep_refinement_checkm/storage/bin_stats_ext.tsv', 'r'):
            refined_bin_id=str(line).strip().split('\t')[0].strip()
            refined_bin_cpn=float(str(line).strip().split('Completeness\':')[1].split('}')[0].split(',')[0].strip())
            refined_bin_ctn=float(str(line).strip().split('Contamination\':')[1].split('}')[0].split(',')[0].strip())
            refined_delta=refined_bin_cpn-5*refined_bin_ctn

            if refined_bin_id != org_bin_id:
                if refined_bin_ctn < org_bin_ctn and refined_bin_cpn == org_bin_cpn:
                    contigs=contig_num[int(refined_bin_id.split('_deep_')[1].split('.fa')[0])]
                    contig_negative[str(contigs)]=0
                    f_contig_list.write(str(org_bin_id)+'\t'+str(contigs)+'\t'+'Negative'+'\n')
                elif refined_bin_cpn < org_bin_cpn and refined_bin_ctn == org_bin_ctn:
                    contigs=contig_num[int(refined_bin_id.split('_deep_')[1].split('.fa')[0])]
                    contig_positive[str(contigs)]=0
                    f_contig_list.write(str(org_bin_id)+'\t'+str(contigs)+'\t'+'Positive'+'\n')
                elif refined_bin_ctn == org_bin_ctn and refined_bin_cpn == org_bin_cpn:
                    contigs=contig_num[int(refined_bin_id.split('_deep_')[1].split('.fa')[0])]
                    contig_neutral[str(contigs)]=0
                    f_contig_list.write(str(org_bin_id)+'\t'+str(contigs)+'\t'+'Neutral'+'\n')                    
                elif refined_delta > ori_delta:
                    contigs=contig_num[int(refined_bin_id.split('_deep_')[1].split('.fa')[0])]
                    contig_positive_suspect[str(contigs)]=0
                    f_contig_list.write(str(org_bin_id)+'\t'+str(contigs)+'\t'+'Positive suspect'+'\n')  
                elif refined_delta < ori_delta:
                    contigs=contig_num[int(refined_bin_id.split('_deep_')[1].split('.fa')[0])]
                    contig_negative_suspect[str(contigs)]=0
                    f_contig_list.write(str(org_bin_id)+'\t'+str(contigs)+'\t'+'Negative suspect'+'\n')  

        if com_type == 'coverage':
            types='_ct_'
        elif com_type == 'TNFs':
            types='_TNFs_'
        
        if 'metabat' in org_bin_id:
            org_bin_id_name=org_bin_id+'.fa'
        else:
            org_bin_id_name=org_bin_id+'.fasta'

        ### remove negative contig, keep neutral and positive contigs
        os.chdir(pwd+'/'+str(com_type)+'_deep_refined_bins')
        bins_mo={}
        if len(contig_positive) != 0:
            f=open(org_bin_id_name+str(types)+'OR-D.fa','w') ### only recruited positive contigs
            for contigs_id in bin_seq_rec[org_bin_id].keys():
                if contigs_id not in contig_negative.keys() and contigs_id not in contig_neutral.keys() and contigs_id not in contig_positive_suspect.keys() and contigs_id not in contig_negative_suspect.keys():
                    f.write('>'+str(contigs_id)+'\n'+str(bin_seq_rec[org_bin_id][contigs_id])+'\n')
            f.close()

            if len(contig_positive_suspect) != 0:
                f2=open(org_bin_id_name+str(types)+'OR-D2.fa','w') ### Recruited positive contigs and postive suspect contigs
                for contigs_id in bin_seq_rec[org_bin_id].keys():
                    if contigs_id not in contig_negative.keys() and contigs_id not in contig_neutral.keys() and contigs_id not in contig_negative_suspect.keys():
                        f2.write('>'+str(contigs_id)+'\n'+str(bin_seq_rec[org_bin_id][contigs_id])+'\n')
                f2.close()
            
            if len(contig_negative_suspect) != 0:
                f3=open(org_bin_id_name+str(types)+'OR-D3.fa','w') ### Recruited positive contigs and postive suspect contigs and contig negative suspect contigs
                for contigs_id in bin_seq_rec[org_bin_id].keys():
                    if contigs_id not in contig_negative.keys() and contigs_id not in contig_neutral.keys():
                        f3.write('>'+str(contigs_id)+'\n'+str(bin_seq_rec[org_bin_id][contigs_id])+'\n')
                f3.close()
        
        elif len(contig_positive_suspect) != 0:
            f4=open(org_bin_id_name+str(types)+'OR-D4.fa','w') ### Recruited positive contigs and postive suspect contigs
            for contigs_id in bin_seq_rec[org_bin_id].keys():
                if contigs_id not in contig_negative.keys() and contigs_id not in contig_neutral.keys() and contigs_id not in contig_negative_suspect.keys():
                    f4.write('>'+str(contigs_id)+'\n'+str(bin_seq_rec[org_bin_id][contigs_id])+'\n')
            f4.close()

            if len(contig_negative_suspect) != 0:
                f5=open(org_bin_id_name+str(types)+'OR-D5.fa','w') ### Recruited positive contigs and postive suspect contigs and contig negative suspect contigs
                for contigs_id in bin_seq_rec[org_bin_id].keys():
                    if contigs_id not in contig_negative.keys() and contigs_id not in contig_neutral.keys():
                        f5.write('>'+str(contigs_id)+'\n'+str(bin_seq_rec[org_bin_id][contigs_id])+'\n')
                f5.close()
        
        elif len(contig_negative_suspect) != 0:
            f6=open(org_bin_id_name+str(types)+'OR-D6.fa','w') ### Recruited positive contigs and postive suspect contigs and contig negative suspect contigs
            for contigs_id in bin_seq_rec[org_bin_id].keys():
                if contigs_id not in contig_negative.keys() and contigs_id not in contig_neutral.keys():
                    f6.write('>'+str(contigs_id)+'\n'+str(bin_seq_rec[org_bin_id][contigs_id])+'\n')
            f6.close()

        os.chdir(pwd)
    os.chdir(pwd)
    if len(further_refined_bin_contig) != 0:
        f_contig_list.close() 

    xxx=0
    if len(further_refined_bin_contig) != 0:
        for root, dirs, files in os.walk(pwd+'/'+str(com_type)+'_deep_refined_bins'):
            for file in files:
                hz=str(file).split('.')[-1]
                if 'fa' in hz:
                    xxx+=1

    if xxx >= 1:
        os.system('checkm lineage_wf -t 42 -x fa '+str(com_type)+'_deep_refined_bins '+str(com_type)+'_deep_refined_bins_checkm')

        os.chdir(pwd+'/'+str(com_type)+'_deep_refined_bins')
        replace_bin, x = {}, 0
        for line in open(pwd+'/'+str(com_type)+'_deep_refined_bins_checkm/storage/bin_stats_ext.tsv', 'r'):
            refined_bin_id=str(line).strip().split('\t')[0].strip()
            refined_bin_cpn=float(str(line).strip().split('Completeness\':')[1].split('}')[0].split(',')[0].strip())
            refined_bin_ctn=float(str(line).strip().split('Contamination\':')[1].split('}')[0].split(',')[0].strip())

            org_bin_id_list=str(line).strip().split('\t')[0].strip().split(str(types)+'OR-D')[0].split('.')
            org_bin_id_list.remove(org_bin_id_list[-1])
            org_bin_id='.'.join(org_bin_id_list)
            for sel_bin in bestbin[org_bin_id].keys():
                ori_cpn=float(bestbin[org_bin_id][sel_bin]['Completeness'])
                ori_ctn=float(bestbin[org_bin_id][sel_bin]['Contamination'])
            org_delta=ori_cpn-2*ori_ctn
            refined_delta=refined_bin_cpn-2*refined_bin_ctn

            if refined_delta > org_delta:
                x+=1
                del bestbin[org_bin_id][sel_bin]
                replace_bin[sel_bin]=''
                #del selected_bin[sel_bin]
                #selected_bin[refined_bin_id]=''
                refined_checkm[refined_bin_id]={}
                refined_checkm[refined_bin_id]['Completeness']=refined_bin_cpn
                refined_checkm[refined_bin_id]['Contamination']=refined_bin_ctn
                refined_checkm[refined_bin_id]['Genome size']=str(line).strip().split('Genome size\':')[1].split('}')[0].split(',')[0].strip()
                refined_checkm[refined_bin_id]['marker lineage']=str(line).strip().split('lineage')[1].split('}')[0].split('\'')[2].strip()
                refined_checkm[refined_bin_id]['Mean scaffold length']=str(line).strip().split('Mean scaffold length')[1].split(':')[1].split('}')[0].split(',')[0].strip()
                bestbin[org_bin_id][refined_bin_id]=refined_checkm[refined_bin_id]
                try:
                    os.system('cp '+pwd+'/'+str(com_type)+'_deep_refined_bins/'+refined_bin_id+'.fa '+pwd+'/'+str(refined_binset))
                except:
                    os.system('cp '+pwd+'/'+str(com_type)+'_deep_refined_bins/'+refined_bin_id+'.fasta '+pwd+'/'+str(refined_binset))

        os.chdir(pwd+'/'+str(refined_binset))
        y=0
        fxx=open('test.txt','w')
        for root, dirs, files in os.walk(pwd+'/'+str(refined_binset)):
            for file in files:
                if '_genomes.' in file and '.fa' in file:
                    ids_list=file.split('.')
                    ids_list.remove(ids_list[-1])
                    bin_id='.'.join(ids_list)
                    if str(bin_id) in replace_bin.keys():
                        os.system('rm '+file)
                        fxx.write(str(bin_id)+'\t'+str(file)+'\n')
                        y+=1
        fxx.close()

        selected_bin2={}
        for root, dirs, files in os.walk(pwd+'/'+str(refined_binset)):
            for file in files:
                if '_genomes.' in file and '.fa' in file:
                    ids_list=file.split('.')
                    ids_list.remove(ids_list[-1])
                    bin_id='.'.join(ids_list)
                    selected_bin2[str(bin_id)]=''

        f=open('Selected_bin_after_outlier_removal_deep_refined.txt', 'w')
        f.write('Original bin'+'\t'+'Selected bin'+'\t'+'Factors'+'\n')
        #f.write(str(x)+' deep refined bins moved to refined binset folder. '+str(y)+' bins removed from refined binset folder'+'\n')
        for item in bestbin.keys():
            for bins in bestbin[item].keys():
                #print(str(bins))
                f.write(str(item)+'\t'+str(bins)+'\t'+str(bestbin[item][bins])+'\n')
                #for bins2 in selected_bin2.keys():
                #    print(str(bins2))
                #    if item == selected_bin[bins2]:
                #        del selected_bin[bins2]
                #        selected_bin[bins]=item
        f.close()

        f_replace=open(str(refined_binset)+'_replace_bin_test.txt', 'w')
        for bins in replace_bin.keys():
            f_replace.write(str(bins)+'\n')
        f_replace.close()

    os.chdir(pwd+'/'+str(refined_binset))
    checkm_total={}
    checkm_total.update(bin_checkm)
    checkm_total.update(refined_checkm)
        
    f_bin_checkm=open(refined_binset+'_bin_stats_ext.tsv', 'w')
    print(str(len(selected_bin2))+' bins selected')
    for item in selected_bin2.keys():
        if item in checkm_total.keys():
            f_bin_checkm.write(str(item)+'\t'+str(checkm_total[item])+'\n')
    f_bin_checkm.close()
    os.chdir(pwd)
    return str(refined_binset)

def contig_outlier_remover_main(best_binset_from_multi_assemblies, coverage_list, connections_list, num_threads):
    cov_threshold=['1.5','1.8', '2.1', '2.4', '2.7', '3']
    TNF_threshold=['1.5','1.8', '2.1', '2.4', '2.7', '3', '3.5', '4']
    pwd=os.getcwd()

    ### Coverage refine process
    A=record_bin_coverage(best_binset_from_multi_assemblies, coverage_list, connections_list)
    bin_contig_cov=A[0]
    bin_contig=A[1]
    assembly=A[2]
    PE_connections_file=A[3]
    refined_binset=cov_materix(bin_contig_cov, bin_contig, cov_threshold, best_binset_from_multi_assemblies)
    bin_comparison(best_binset_from_multi_assemblies, best_binset_from_multi_assemblies+'_coverage_refined', 'fa', 'coverage', num_threads, pwd)
    os.system('mv Selected_bin_after_outlier_removal.txt Refined_bin_comparison_after_outlier_removal.txt '+pwd+'/'+str(refined_binset))
    ### TNFs refine process
    refined_binset=TNFs_refiner(best_binset_from_multi_assemblies, assembly, best_binset_from_multi_assemblies+'_coverage_refined', TNF_threshold, pwd, num_threads)
    bin_comparison(best_binset_from_multi_assemblies+'_coverage_refined', best_binset_from_multi_assemblies+'_TNFs_refined', 'fa', 'TNFs', num_threads, pwd)
    os.system('mv Selected_bin_after_outlier_removal.txt Refined_bin_comparison_after_outlier_removal.txt '+pwd+'/'+str(refined_binset))
    os.system('cp '+pwd+'/'+str(best_binset_from_multi_assemblies)+'/Selected_bins_best_binset.txt '+pwd+'/'+str(refined_binset))

    ### Rename
    os.system('mv '+best_binset_from_multi_assemblies+'_TNFs_refined '+best_binset_from_multi_assemblies+'_outlier_refined')
    os.chdir(pwd+'/'+best_binset_from_multi_assemblies+'_outlier_refined')
    f_rename=open('Rename.txt','w')
    for root, dirs, files in os.walk(pwd+'/'+best_binset_from_multi_assemblies+'_outlier_refined'):
        for file in files:
            if '_ct_' in file and '.fa' in file:
                bin_ids=file.split('_ct_')[0]
                os.system('mv '+str(file)+' '+str(bin_ids))
                f_rename.write(str(file)+'\t'+str(bin_ids)+'\n')
            elif '_TNFs_' in file and '.fa' in file:
                bin_ids=file.split('_TNFs_')[0]
                os.system('mv '+str(file)+' '+str(bin_ids))
                f_rename.write(str(file)+'\t'+str(bin_ids)+'\n')
            elif '_bin_stats_ext.tsv' in file:
                bin_checkm_file=file
    f_rename.close()

    f=open('BestBinset_outlier_removal_bin_stats_ext.tsv','w')
    for line in open(bin_checkm_file, 'r'):
        bin_id_o=line.split('\t')[0]
        line_list=line.split('\t')
        line_list.remove(line_list[0])
        line_content='\t'.join(line_list)
        if '_ct_' in bin_id_o:
            if '.fa_ct_' in bin_id_o:
                bin_id=bin_id_o.split('.fa_ct_')[0]
            elif '.fasta_ct_' in bin_id_o:
                bin_id=bin_id_o.split('.fasta_ct_')[0]
            print(str(bin_id))
        elif '_TNFs_' in bin_id_o:
            if '.fa_TNFs_' in bin_id_o:
                bin_id=bin_id_o.split('.fa_TNFs_')[0]
            elif '.fasta_TNFs_' in bin_id_o:
                bin_id=bin_id_o.split('.fasta_TNFs_')[0]
        else:
            bin_id=bin_id_o
        f.write(str(bin_id)+'\t'+str(line_content).strip()+'\n')
    f.close()
    os.system('mv '+str(bin_checkm_file)+' BestBinset_TNFs_refined_bin_quality.txt')
    os.chdir(pwd)
    os.system('cp '+str(pwd)+'/'+str(best_binset_from_multi_assemblies)+'/Selected_bins_best_binset.txt '+pwd+'/'+best_binset_from_multi_assemblies+'_outlier_refined')
    print('Outlier removal done!')

if __name__ == '__main__': 
    best_binset_from_multi_assemblies='BestBinset'
    coverage_list=['Coverage_matrix_for_binning_1_8_medium_S001_SPAdes_scaffolds.fasta.txt','Coverage_matrix_for_binning_2_9_medium_S002_SPAdes_scaffolds.fasta.txt','Coverage_matrix_for_binning_3_10_medium_cat_SPAdes_scaffolds.fasta.txt']
    connections_list=['condense_connections_8_medium_S001_SPAdes_scaffolds.fasta.txt','condense_connections_9_medium_S002_SPAdes_scaffolds.fasta.txt','condense_connections_10_medium_cat_SPAdes_scaffolds.fasta.txt']
    num_threads=44
    contig_outlier_remover_main(best_binset_from_multi_assemblies, coverage_list, connections_list, num_threads)
