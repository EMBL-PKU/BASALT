#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

import time, sys, os
from Bio import SeqIO
####
from S1_Autobinners_11222020 import *
from S2_BinsAbundance_PE_connections_multiple_processes_pool_12062020 import *
from S3_Bins_comparator_within_group_07282020 import *
###
from Refinement_fit_data import *
from S4_Multiple_Assembly_Comparitor_multiple_processes_08052020 import *
from S5_Outlier_remover_mpt_12162020 import *
from S6_Contig_retriever_mpt_08082020 import *
from S7_OLC_new_12052020 import *
from S8_Reassembly_12132020 import *
# from S9_OLC_new_08212020_t500_995_95 import *

def basalt_main(assembly_list, datasets, num_threads, refinement_mode, auto_binning_mode, parameter, extra, assembler_NGS, long_read_assembly_list, long_read, ram, pwd):
    total_assembly_list=[]
    if len(long_read_assembly_list) != 0:
        total_assembly_list=assembly_list+long_read_assembly_list
    else:
        total_assembly_list=assembly_list

    ### Record the last accomplished step
    last_step=0
    if parameter == 'last':
        try:
            n=0
            for line in open('Basalt_checkpoint.txt', 'r'):
                n+=1

            n1=0
            for line in open('Basalt_checkpoint.txt', 'r'):
                n1+=1
                if n1 == n:
                    last_step=int(str(line)[0])
        except:
            f_cp_m=open('Basalt_checkpoint.txt', 'w')
            f_cp_m.close()
    else:
        f_cp_m=open('Basalt_checkpoint.txt', 'w')
        f_cp_m.close()

    ### Autobinner
    if last_step == 0:
        print('Running autobinner')
        A=autobinner_main(total_assembly_list, datasets, num_threads, auto_binning_mode, pwd)
        bins_folders=A[0]
        connections_total_dict=A[1]
        depth_total=A[2]
        assembly_MoDict=A[3]

        f1=open('Connections_total_dict.txt','w')
        for item in connections_total_dict.keys():
            f1.write(str(item)+'\t'+str(connections_total_dict[item])+'\n')
        f1.close()

        f1=open('Depth_total.txt','w')
        for item in depth_total.keys():
            f1.write(str(item)+'\t'+str(depth_total[item])+'\n')
        f1.close()

        f1=open('Assembly_MoDict.txt','w')
        for item in assembly_MoDict.keys():
            f1.write(str(item)+'\t'+str(assembly_MoDict[item])+'\n')
        f1.close()

        f1=open('Bins_folder.txt','w')
        for item in bins_folders.keys():
            f1.write(str(item)+'\t'+str(bins_folders[item])+'\n')
        f1.close()    

        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('1st autobinner done!')
        f_cp_m.close()
        #connections_total_dict={'9groups_assembly.fa':'condense_connections_9groups_assembly.fa.txt', 'AN1-32_assembly.fa':'condense_connections_AN1-32_assembly.fa.txt'}
        #depth_total={'9groups_assembly.fa':'1_assembly.depth.txt', 'AN1-32_assembly.fa':'2_assembly.depth.txt'}
        #assembly_MoDict={'9groups_assembly.fa':'1_9groups_assembly.fa', 'AN1-32_assembly.fa':'2_AN1-32_assembly.fa'}
        #bins_folders={'9groups_assembly.fa':['1_9groups_assembly.fa_0.3_genomes','1_9groups_assembly.fa_0.5_genomes','1_9groups_assembly.fa_0.7_genomes','1_9groups_assembly.fa_0.9_genomes','1_9groups_assembly.fa_1000_concoct_genomes','1_9groups_assembly.fa_400_concoct_genomes','1_9groups_assembly.fa_200_concoct_genomes','1_9groups_assembly.fa_200_metabat_genomes','1_9groups_assembly.fa_300_metabat_genomes','1_9groups_assembly.fa_400_metabat_genomes','1_9groups_assembly.fa_500_metabat_genomes'], 'AN1-32_assembly.fa':['2_AN1-32_assembly.fa_0.3_maxbin2_genomes','2_AN1-32_assembly.fa_0.9_maxbin2_genomes','2_AN1-32_assembly.fa_0.7_maxbin2_genomes','2_AN1-32_assembly.fa_0.5_maxbin2_genomes','2_AN1-32_assembly.fa_200_metabat_genomes','2_AN1-32_assembly.fa_300_metabat_genomes','2_AN1-32_assembly.fa_400_metabat_genomes','2_AN1-32_assembly.fa_500_metabat_genomes','2_AN1-32_assembly.fa_200_concoct_genomes','2_AN1-32_assembly.fa_400_concoct_genomes','2_AN1-32_assembly.fa_1000_concoct_genomes']}

    ### Bin selecting process
    if last_step < 2:
        if last_step == 1:
            connections_total_dict, depth_total, assembly_MoDict, bins_folders = {}, {}, {}, {}
            for line in open('Connections_total_dict.txt','r'):
                # connections_total_dict[str(line).strip().split('\t')[0].strip()]=str(line).strip().split('\t')[1].strip()
                connections_total_dict[str(line).strip().split('\t')[1].strip().split('_')[0]]=str(line).strip().split('\t')[1].strip()
            for line in open('Depth_total.txt','r'):
                depth_total[str(line).strip().split('\t')[1].strip().split('_')[0]]=str(line).strip().split('\t')[1].strip()
            for line in open('Assembly_MoDict.txt','r'):
                assembly_MoDict[str(line).strip().split('\t')[1].strip().split('_')[0]]=str(line).strip().split('\t')[1].strip()
            for line in open('Bins_folder.txt','r'):
                bins_folders[str(line).strip().split('[')[1].replace('\'','').split('_')[0]]=str(line).strip().split('\t')[1].strip().replace('[','').replace(']','').replace('\'','').replace(' ','').split(',')

        Ax=binsabundance_pe_connections(bins_folders, depth_total, connections_total_dict, assembly_MoDict, num_threads)

        print('Starting best bin selection: within each group')
        coverage_matrix_list, bestbinset_list, assembly_mo_list=[], [], []
        for item in bins_folders.keys():
            print('---------------------------')
            print('Processing group '+str(item))
            coverage_matrix_list.append(Ax[item])
            Bx=bins_comparator_multiple_groups(bins_folders[item], assembly_MoDict[item])
            print('Adding '+str(Bx)+' to the bestbinset list')
            bestbinset_list.append(Bx)
            print('Adding '+str(assembly_MoDict[item])+' to the assembly modified list')
            assembly_mo_list.append(assembly_MoDict[item])

        f1=open('Coverage_matrix_list.txt','w')
        for item in coverage_matrix_list:
            f1.write(str(item)+'\n')
        f1.close()

        f1=open('Bestbinset_list','w')
        for item in bestbinset_list:
            f1.write(str(item)+'\n')
        f1.close()

        f1=open('Assembly_mo_list.txt','w')
        for item in assembly_mo_list:
            f1.write(str(item)+'\n')
        f1.close()

        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('\n'+'2nd bin selection within group done!')
        f_cp_m.close()

        #coverage_matrix_list=['Coverage_matrix_for_binning_1_I4_assembly.fa.txt','Coverage_matrix_for_binning_2_I6_assembly.fa.txt','Coverage_matrix_for_binning_3_I12_assembly.fa.txt','Coverage_matrix_for_binning_4_I_assembly.fa.txt']
        #bestbinset_list=['1_I4_assembly.fa_BestBinsSet','2_I6_assembly.fa_BestBinsSet','3_I12_assembly.fa_BestBinsSet','4_I_assembly.fa_BestBinsSet']
        #assembly_mo_list=['1_I4_assembly.fa', '2_I6_assembly.fa', '3_I12_assembly.fa', '4_I_assembly.fa']

    if last_step < 3:
        print('Starting best bin selection: within multiple groups')
        if last_step == 2:
            coverage_matrix_list, bestbinset_list, assembly_mo_list=[], [], []
            for line in open('Coverage_matrix_list.txt','r'):
                coverage_matrix_list.append(str(line).strip())

            for line in open('Bestbinset_list','r'):
                bestbinset_list.append(str(line).strip())
            
            for line in open('Assembly_mo_list.txt','r'):
                assembly_mo_list.append(str(line).strip())

        multiple_assembly_comparitor_main(assembly_mo_list, bestbinset_list, coverage_matrix_list, num_threads)

        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('\n'+'3rd bin selection within multiple groups done!')
        f_cp_m.close()

    if last_step < 4:
        print('Starting outlier removal process')
        coverage_matrix_list, connections_list, assembly_mo_list = [], [], []
        for line in open('Coverage_matrix_list.txt','r'):
            coverage_matrix_list.append(str(line).strip())
        for line in open('Assembly_mo_list.txt','r'):
            assembly_mo_list.append(str(line).strip())
    
        for item in assembly_mo_list:
            connections_list.append('Coverage_matrix_for_binning_'+item+'.txt')
        contig_outlier_remover_main('BestBinset', coverage_matrix_list, connections_list, num_threads)
        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('\n'+'4th outlier removal done!')
        f_cp_m.close()

    if last_step < 5:
        print('Starting contig retrival process')
        Contig_recruiter_main('BestBinset_outlier_refined', num_threads, parameter, 35, 20)
        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('\n'+'5th contig retrieve done!')
        f_cp_m.close()
    
    if refinement_mode == 'reassembly':
        if last_step < 6:
            print('Starting 1st OLC process')
            target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved'
            bin_comparison_folder='BestBinset_comparison_files'
            step='assemblies_OLC'
            aligned_len_cutoff=500
            similarity_cutoff=99
            coverage_extension=95
            OLC_main(target_bin_folder, step, bin_comparison_folder, aligned_len_cutoff, similarity_cutoff, coverage_extension, num_threads)
            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'6th contig 1st OLC done!')
            f_cp_m.close()
        
        if last_step < 7:
            print('Starting reassembly')
            binset_folder='BestBinset_outlier_refined_filtrated_retrieved_OLC'
            datasets_list={}
            for ds in datasets.keys():
                datasets_list[ds]=[]
                datasets_list[ds].append('PE_r1_'+str(datasets[ds][0]))
                datasets_list[ds].append('PE_r2_'+str(datasets[ds][1]))
            re_assembly_main(binset_folder, datasets_list, long_read, ram, num_threads)
            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'7th reassembly done!')
            f_cp_m.close()

        if last_step < 8:
            print('Starting 2nd OLC process')
            target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved_OLC_re-assembly' ### Maybe an issue. Make sure the folder name is correct
            step='OLC_after_reassembly' ### 'assemblies_OLC' or 'OLC_after_reassembly' ; 'assemblies_OLC' means 1st OLC; 'OLC_after_reassembly' means OLC after reassembly
            bin_comparison_folder='' ### if 'assemblies_OLC', folder bin_comparison_folder is needed; else if 'assemblies_OLC', the folder is not needed, just let it blank
            aligned_len=500
            similarity=99.5
            coverage_extension=95
            OLC_main(target_bin_folder, step, bin_comparison_folder, aligned_len, similarity, coverage_extension, num_threads)
            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'8th 2nd OLC done!')
            f_cp_m.close()
    
    if extra == 'visual':
        print('Generation of visualization files')

    print('Done!')

if __name__ == '__main__': 
    assembly_list=['8_medium_S001_SPAdes_scaffolds.fasta','9_medium_S002_SPAdes_scaffolds.fasta','10_medium_cat_SPAdes_scaffolds.fasta']
    assembler_NGS=['spades','spades','spades']
    datasets={'1':['RM2_S001_insert_270_mate1.fq','RM2_S001_insert_270_mate2.fq'], '2':['RM2_S002_insert_270_mate1.fq','RM2_S002_insert_270_mate2.fq']}
    long_read_assembly_list=[]
    long_read={}
    num_threads=44
    ram=120
    pwd=os.getcwd()
    refinement_mode='reassembly' ### mode type: 1. quick_refinement; 2. reassembly
    auto_binning_mode='more-sensitive' ### 'deflaut', 'sensitive', 'more-sensitive'
    extra='visual' ### extra: 1. none; 2. visual
    parameter='last' ### parameter type: 1. last: start from the latest step finished from the last time; 2. new: start from beginning
    basalt_main(assembly_list, datasets, num_threads, refinement_mode, auto_binning_mode, parameter, extra, assembler_NGS, long_read_assembly_list, long_read, ram, pwd)
