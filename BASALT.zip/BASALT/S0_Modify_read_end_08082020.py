#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

from Bio import SeqIO
import sys, os, time
from collections import Counter

def fq2fa_conversion(filename): ### Converting fq to fa
    start=time.time()
    wrerr = sys.stderr.write
    print('---')
    print("Coverting "+str(filename)+" file to FA file")

    if '.fq' in str(filename):
        filename1=filename.replace('.fq','')
    elif '.fastq' in str(filename):
        filename1=filename.replace('.fastq','')

    file1Array = filename1.split('/')
    disName = file1Array[-1]
    pwd=os.getcwd()
    filename1 = os.path.join(pwd, disName)

    count = SeqIO.convert(filename, "fastq", filename1+".fasta", "fasta")
    print("Converted %i records" % count)
    end=time.time()
    wrerr("OK, Converting Finished in %3.2f secs\n" % (end-start))
    return disName+".fasta"

def ModifyEnd_fa(filename, n): ### Adding end to fasta file    
    print('---')
    print('Adding end for PE-tracking of '+str(filename))
    print('--- pwd: ', os.getcwd())

    fout=open('PE_r'+str(n)+'_'+filename, 'w')
    m=0
    for record in SeqIO.parse(filename, 'fasta'):
        m+=1
        ids=str(m)+'_'+str(n)+'/'+str(n)
        fout.write('>'+str(ids)+'\n')
        fout.write(str(record.seq)+'\n')
    fout.close()
    print('Accomplished of adding end to '+str(filename))
    print('-----------------------------')
    return 'PE_r'+str(n)+'_'+filename

def ModifyEnd(filename, n): ### Adding end to fasta file    
    print('---')
    print('Adding end for PE-tracking of '+str(filename))
    print('--- pwd: ', os.getcwd())

    fout=open('PE_r'+str(n)+'_'+filename, 'w')
    m, m2=0, 0 
    for line in open(filename, 'r'):
        m+=1
        if '@' in line and m%4==1:
            m2+=1
            if ' ' in line:
                ids='@Seq'+str(m2)+'_modifiedID_'+str(n)+'/'+str(n)
            else:
                ids='@Seq'+str(m2)+'_modifiedID_'+str(n)+'/'+str(n)
            fout.write(str(ids)+'\n')
        else:
            fout.write(str(line))
    fout.close()
    print('Accomplished of adding end to '+str(filename))
    print('-----------------------------')
    return 'PE_r'+str(n)+'_'+filename

def modification_main(datasets):
    mod_datasets_fq={}
    for item in datasets.keys():
        mod_datasets_fq[item]=[]
        mod_datasets_fq[item].append(ModifyEnd(datasets[item][0], 1))
        mod_datasets_fq[item].append(ModifyEnd(datasets[item][1], 2))
        
    print('Modification done!')
    return mod_datasets_fq

if __name__ == '__main__': 
    datasets={'1':['RH_S001_insert_270_mate1.fq','RH_S001_insert_270_mate2.fq'], '2':['RH_S002_insert_270_mate1.fq','RH_S002_insert_270_mate2.fq'],
    '3':['RH_S003_insert_270_mate1.fq','RH_S003_insert_270_mate2.fq'], '4':['RH_S004_insert_270_mate1.fq','RH_S004_insert_270_mate2.fq'], '5':['RH_S005_insert_270_mate1.fq','RH_S005_insert_270_mate2.fq']}
    modification_main(datasets)
