#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

import time, sys, os
from Bio import SeqIO
from BASALT_main import * 
# from Refinement_main import *

if __name__ == '__main__':
    retrieve_min_completeness, retrieve_max_contamination, num_threads, ram  = 35, 20, 2, 64 
    assembly_list, datasets = [], {}
    long_read_assembly_list, long_read, long_reads_as_num = [], [], -1
    assembler_NGS=[]
    extra='none' ### extra: 1. none; 2. visual
    parameter='last' ### parameter type: 1. last: start from the latest step finished from the last time; 2. new: start from beginning
    refinement_mode='reassembly' ### mode type: 1. quick_refinement; 2. reassembly
    refinement_1st_step_mode='Quick' ### mode type: 1. Quick; 2. Deep
    auto_binning_mode='quick' ### 'quick', 'sensitive', 'more-sensitive'
    refinement_only=0 ### '0' start from autobinning; '1': refinement_only

    for i in range(1, len(sys.argv)):
        if '-al' in str(sys.argv[i]):
            assembly_list_num=int(i)+1
        elif '-ds' in str(sys.argv[i]):
            datasets_dict_num=int(i)+1
        elif '--long-reads-as' in str(sys.argv[i]):
            long_reads_as_num=int(i)+1
        elif '--long-reads' in str(sys.argv[i]):
            long_reads_num=int(i)+1
        elif '-t' in str(sys.argv[i]):
            threads_num=int(i)+1
        elif '-r' in str(sys.argv[i]):
            ram_num=int(i)+1
        elif '--max-ctn' in str(sys.argv[i]):
            retrieve_max_contamination_num=int(i)+1
        elif '--min-cpn' in str(sys.argv[i]):
            retrieve_min_completeness_num=int(i)+1
        elif '--new' in str(sys.argv[i]):
            parameter='new'
        elif '--continue' in str(sys.argv[i]):
            parameter='last'
        elif '--reassembly' in str(sys.argv[i]):
            refinement_mode='reassembly'
        elif '--autobinning' in str(sys.argv[i]):
            autobinning_num=int(i)+1
        elif '--refinement_only' in str(sys.argv[i]):
            refinement_mode='quick_refinement'
        elif '--deep_refinement' in str(sys.argv[i]):
            refinement_1st_step_mode='Deep'
        else:
            continue

    pwd=os.getcwd()
    assembly_list=str(sys.argv[assembly_list_num]).split(',')
    if long_reads_as_num != -1:
        long_read_assembly_list=str(sys.argv[long_reads_as_num]).split(',')
    # print(str(assembly_list))
    # print(str(sys.argv[datasets_dict_num]))
    datasets_dict_list=str(sys.argv[datasets_dict_num]).split(';')
    n=0
    for item in datasets_dict_list:
        n+=1
        datasets[str(n)]=[]
        pr=str(item).split(',')
        datasets[str(n)].append(pr[0].strip())
        datasets[str(n)].append(pr[1].strip())

    try:
        num_threads=int(sys.argv[threads_num])
    except:
        n=0

    try:
        ram=int(sys.argv[ram_num])
    except:
        n=0

    try:
        retrieve_max_contamination=int(sys.argv[retrieve_max_contamination_num])
    except:
        n=0
    
    try:
        retrieve_min_completeness=int(sys.argv[retrieve_min_completeness_num])
    except:
        n=0

    try:
        auto_binning_mode=str(sys.argv[autobinning_num]) ### 'quick', 'sensitive', 'more-sensitive'
    except:
        n=0

    try:
        long_read=str(sys.argv[long_reads_num]).split(',')
    except:
        n=0

    print('Processing', str(datasets))
    print('Processing', str(assembly_list))
    print('Autobinning mode:', str(auto_binning_mode))
    print('Refinement mode:', str(refinement_mode))
    print('Refinement:', str(refinement_1st_step_mode), 'refinement')
    # basalt_main(assembly_list, datasets, num_threads, refinement_mode, auto_binning_mode, parameter, extra, assembler_NGS, long_read_assembly_list, long_read, retrieve_min_completeness, retrieve_max_contamination, ram, pwd)
    snakemake(assembly_list, datasets, num_threads, refinement_mode, refinement_1st_step_mode, auto_binning_mode, parameter, extra, long_read_assembly_list, long_read, ram, pwd)