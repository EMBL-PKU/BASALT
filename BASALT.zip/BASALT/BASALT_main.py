#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

import time, sys, os
from Bio import SeqIO
from S1_Autobinners_05262021 import *
from S2_BinsAbundance_PE_connections_multiple_processes_pool_04192021 import *
from S3_Bins_comparator_within_group_07282020 import *
from S4_Multiple_Assembly_Comparitor_multiple_processes_bwt_07272021 import *
from S5_Outlier_remover_mpt_01162021 import *
from S6_retrieve_contigs_from_PE_contigs import *
from S7_Contigs_retrieve_within_group_02222021 import *
from S8_OLC_new_01172021 import *
from S9_Reassembly_05222021 import *
# from S9_OLC_new_08212020_t500_995_95 import *

def snakemake(assembly_list, datasets, num_threads, refinement_mode, refinement_1st_mode, auto_binning_mode, parameter, extra, long_read_assembly_list, long_read, ram, pwd):
    total_assembly_list=[]
    if len(long_read_assembly_list) != 0:
        total_assembly_list=assembly_list+long_read_assembly_list
    else:
        total_assembly_list=assembly_list

    ### Record the last accomplished step
    last_step=0
    if parameter == 'last':
        try:
            n=0
            for line in open('Basalt_checkpoint.txt', 'r'):
                n+=1

            n1=0
            for line in open('Basalt_checkpoint.txt', 'r'):
                n1+=1
                if n1 == n:
                    last_step=int(str(line)[0])
        except:
            f_cp_m=open('Basalt_checkpoint.txt', 'w')
            f_cp_m.close()
    else:
        f_cp_m=open('Basalt_checkpoint.txt', 'w')
        f_cp_m.close()

    ### Autobinner
    if last_step == 0:
        print('--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--')
        print('Running autobinner')
        print('Processing files in '+str(pwd))
        A=autobinner_main(total_assembly_list, datasets, num_threads, auto_binning_mode, pwd)
        bins_folders_dic=A[0]
        connections_total_dict=A[1]
        depth_total=A[2]
        assembly_MoDict=A[3]
        # mod_datasets_fq=A[4]

        f1=open('Connections_total_dict.txt','w')
        for item in connections_total_dict.keys():
            f1.write(str(item)+'\t'+str(connections_total_dict[item])+'\n')
        f1.close()

        f1=open('Depth_total.txt','w')
        for item in depth_total.keys():
            f1.write(str(item)+'\t'+str(depth_total[item])+'\n')
        f1.close()

        f1=open('Assembly_MoDict.txt','w')
        for item in assembly_MoDict.keys():
            f1.write(str(item)+'\t'+str(assembly_MoDict[item])+'\n')
        f1.close()

        # bins_folders, n={}, 0
        f1=open('Bins_folder.txt','w')
        for item in bins_folders_dic.keys():
            # n+=1
            # bins_folders[str(n)]=[]
            f1.write(str(item)+'\t'+str(bins_folders_dic[item])+'\n')
            # genomes_list=str(bins_folders_dic[item]).strip().replace('[','').replace(']','').replace('\'','').replace(' ','').split(',')
            # for genomes_folder in genomes_list:
            #     genomes_folder_name_list=genomes_folder.split('_')
            #     genomes_folder_name_list.remove(genomes_folder_name_list[-1])
            #     genomes_folder_name='_'.join(genomes_folder_name_list)
            #     bins_folders[str(n)].append(genomes_folder_name)
        f1.close()    

        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('1st autobinner done!')
        f_cp_m.close()
        #connections_total_dict={'9groups_assembly.fa':'condense_connections_9groups_assembly.fa.txt', 'AN1-32_assembly.fa':'condense_connections_AN1-32_assembly.fa.txt'}
        #depth_total={'9groups_assembly.fa':'1_assembly.depth.txt', 'AN1-32_assembly.fa':'2_assembly.depth.txt'}
        #assembly_MoDict={'9groups_assembly.fa':'1_9groups_assembly.fa', 'AN1-32_assembly.fa':'2_AN1-32_assembly.fa'}
        #bins_folders={'9groups_assembly.fa':['1_9groups_assembly.fa_0.3_genomes','1_9groups_assembly.fa_0.5_genomes','1_9groups_assembly.fa_0.7_genomes','1_9groups_assembly.fa_0.9_genomes','1_9groups_assembly.fa_1000_concoct_genomes','1_9groups_assembly.fa_400_concoct_genomes','1_9groups_assembly.fa_200_concoct_genomes','1_9groups_assembly.fa_200_metabat_genomes','1_9groups_assembly.fa_300_metabat_genomes','1_9groups_assembly.fa_400_metabat_genomes','1_9groups_assembly.fa_500_metabat_genomes'], 'AN1-32_assembly.fa':['2_AN1-32_assembly.fa_0.3_maxbin2_genomes','2_AN1-32_assembly.fa_0.9_maxbin2_genomes','2_AN1-32_assembly.fa_0.7_maxbin2_genomes','2_AN1-32_assembly.fa_0.5_maxbin2_genomes','2_AN1-32_assembly.fa_200_metabat_genomes','2_AN1-32_assembly.fa_300_metabat_genomes','2_AN1-32_assembly.fa_400_metabat_genomes','2_AN1-32_assembly.fa_500_metabat_genomes','2_AN1-32_assembly.fa_200_concoct_genomes','2_AN1-32_assembly.fa_400_concoct_genomes','2_AN1-32_assembly.fa_1000_concoct_genomes']}

    ### Bin selecting process
    if last_step < 2:
        
        connections_total_dict, depth_total, assembly_MoDict, bins_folders = {}, {}, {}, {}
        n=0
        for line in open('Connections_total_dict.txt','r'):
            n+=1
            # connections_total_dict[str(line).strip().split('\t')[1].strip().split('_')[0]]=str(line).strip().split('\t')[1].strip()
            connections_total_dict[str(n)]=str(line).strip().split('\t')[1].strip()
        n=0
        for line in open('Depth_total.txt','r'):
            n+=1
            depth_total[str(n)]=str(line).strip().split('\t')[1].strip()
            # depth_total[str(line).strip().split('\t')[1].strip().split('_')[0]]=str(line).strip().split('\t')[1].strip()
        n=0
        for line in open('Assembly_MoDict.txt','r'):
            n+=1
            assembly_MoDict[str(n)]=str(line).strip().split('\t')[1].strip()
            # assembly_MoDict[str(line).strip().split('\t')[1].strip().split('_')[0]]=str(line).strip().split('\t')[1].strip()

        n=0
        for line in open('Bins_folder.txt','r'):
            n+=1
            # assembly_name=str(line).strip().split('[')[1].replace('\'','').split('_')[0]
            bins_folders[str(n)]=[]
            genomes_list=str(line).strip().split('\t')[1].strip().replace('[','').replace(']','').replace('\'','').replace(' ','').split(',')
            for genomes_folder in genomes_list:
                genomes_folder_name_list=genomes_folder.split('_')
                genomes_folder_name_list.remove(genomes_folder_name_list[-1])
                genomes_folder_name='_'.join(genomes_folder_name_list)
                bins_folders[str(n)].append(genomes_folder_name)
                
        Ax=binsabundance_pe_connections(bins_folders, depth_total, connections_total_dict, assembly_MoDict, num_threads)

        print('Starting best bin selection: within each group')
        coverage_matrix_list, bestbinset_list, assembly_mo_list=[], [], []
        for item in bins_folders.keys():
            print('---------------------------')
            print('Processing group '+str(item)+' '+str(bins_folders[item]))
            coverage_matrix_list.append(Ax[item])
            genome_folder_list=bins_folders[item]
            genomes_folder_name_list=[]
            for item2 in genome_folder_list:
                genomes_folder_name_list.append(item2+'_genomes')
            # Bx=bins_comparator_multiple_groups(genome_folder_list, assembly_MoDict[item])
            Bx=bins_comparator_multiple_groups(genomes_folder_name_list, assembly_MoDict[item])
            print('Adding '+str(Bx)+' to the bestbinset list')
            bestbinset_list.append(Bx)
            print('Adding '+str(assembly_MoDict[item])+' to the assembly modified list')
            assembly_mo_list.append(assembly_MoDict[item])

        f1=open('Coverage_matrix_list.txt','w')
        for item in coverage_matrix_list:
            f1.write(str(item)+'\n')
        f1.close()

        f1=open('Bestbinset_list','w')
        for item in bestbinset_list:
            f1.write(str(item)+'\n')
        f1.close()

        f1=open('Assembly_mo_list.txt','w')
        for item in assembly_mo_list:
            f1.write(str(item)+'\n')
        f1.close()

        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('\n'+'2nd bin selection within group done!')
        f_cp_m.close()

        #coverage_matrix_list=['Coverage_matrix_for_binning_1_I4_assembly.fa.txt','Coverage_matrix_for_binning_2_I6_assembly.fa.txt','Coverage_matrix_for_binning_3_I12_assembly.fa.txt','Coverage_matrix_for_binning_4_I_assembly.fa.txt']
        #bestbinset_list=['1_I4_assembly.fa_BestBinsSet','2_I6_assembly.fa_BestBinsSet','3_I12_assembly.fa_BestBinsSet','4_I_assembly.fa_BestBinsSet']
        #assembly_mo_list=['1_I4_assembly.fa', '2_I6_assembly.fa', '3_I12_assembly.fa', '4_I_assembly.fa']

    if last_step < 3:
        print('Starting best bin selection: within multiple groups')
        if last_step == 2:
            coverage_matrix_list, bestbinset_list, assembly_mo_list=[], [], []
            for line in open('Coverage_matrix_list.txt','r'):
                coverage_matrix_list.append(str(line).strip())

            for line in open('Bestbinset_list','r'):
                bestbinset_list.append(str(line).strip())
            
            for line in open('Assembly_mo_list.txt','r'):
                assembly_mo_list.append(str(line).strip())

        # multiple_assembly_comparitor_main(assembly_mo_list, bestbinset_list, coverage_matrix_list, num_threads)
        datasets_fq={}
        for item in datasets.keys():
            datasets_fq[item]=[]
            datasets_fq[item].append('PE_r1_'+str(datasets[item][0]))
            datasets_fq[item].append('PE_r2_'+str(datasets[item][1]))
        multiple_assembly_comparitor_main(assembly_mo_list, bestbinset_list, coverage_matrix_list, datasets_fq, num_threads)

        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('\n'+'3rd bin selection within multiple groups done!')
        f_cp_m.close()

    if last_step < 4:
        print('Starting outlier removal process')
        coverage_matrix_list, connections_list, assembly_mo_list = [], [], []
        for line in open('Coverage_matrix_list.txt','r'):
            coverage_matrix_list.append(str(line).strip())
        for line in open('Assembly_mo_list.txt','r'):
            assembly_mo_list.append(str(line).strip())
    
        for item in assembly_list:
            connections_list.append('condense_connections_'+item+'.txt')
        contig_outlier_remover_main('BestBinset', coverage_matrix_list, connections_list, num_threads)
        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('\n'+'4th outlier removal done!')
        f_cp_m.close()

    if last_step < 5:
        print('Starting contig retrival process')
        # Contig_recruiter_main('BestBinset_outlier_refined', num_threads, parameter, 35, 20)
        best_binset_from_multi_assemblies='BestBinset_outlier_refined'
        outlier_remover_folder='BestBinset_outlier_refined'
        cpn_cutoff=35 ### The minimun completeness to keep
        ctn_cutoff=20 ### The maximal contaminaition to keep

        coverage_matrix_list, connections_list, assembly_mo_list = [], [], []
        for line in open('Coverage_matrix_list.txt','r'):
            coverage_matrix_list.append(str(line).strip())
        for line in open('Assembly_mo_list.txt','r'):
            assembly_mo_list.append(str(line).strip())
        for line in open('Assembly_MoDict.txt','r'):
            item=str(line).strip().split('\t')[0].strip()
            connections_list.append('condense_connections_'+item+'.txt')

        Contig_recruiter_main(best_binset_from_multi_assemblies, outlier_remover_folder, num_threads, parameter, cpn_cutoff, ctn_cutoff, assembly_mo_list, connections_list, coverage_matrix_list, refinement_1st_mode, pwd)
        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('\n'+'5th contig retrieve done!')
        f_cp_m.close()

    if last_step < 6:
        print('Starting contig retrival within group')
        # Contig_recruiter_main('BestBinset_outlier_refined', num_threads, parameter, 35, 20)
        best_binset_after_contig_retrieve='BestBinset_outlier_refined_filtrated_retrieved'
        outlier_remover_folder='BestBinset_outlier_refined'
        cpn_cutoff=35 ### The minimun completeness to keep
        ctn_cutoff=5 ### The maximal contaminaition to keep

        coverage_matrix_list, connections_list, assembly_mo_list = [], [], []
        for line in open('Coverage_matrix_list.txt','r'):
            coverage_matrix_list.append(str(line).strip())
        for line in open('Assembly_mo_list.txt','r'):
            assembly_mo_list.append(str(line).strip())
        for line in open('Assembly_MoDict.txt','r'):
            item=str(line).strip().split('\t')[0].strip()
            connections_list.append('condense_connections_'+item+'.txt')

        Contig_retrieve_within_group_main(best_binset_after_contig_retrieve, outlier_remover_folder, num_threads, parameter, cpn_cutoff, ctn_cutoff, assembly_mo_list, connections_list, coverage_matrix_list)

        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('\n'+'6th contig retrieve within group done!')
        f_cp_m.close()
    
    if refinement_mode == 'reassembly':
        if last_step < 7:
            print('Starting OLC process')
            target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved_retrieved'
            bin_comparison_folder='BestBinset_comparison_files'
            step='assemblies_OLC'
            aligned_len_cutoff=500
            similarity_cutoff=99
            coverage_extension=95
            mod_bin_folder=[]
            OLC_main(target_bin_folder, step, bin_comparison_folder, aligned_len_cutoff, similarity_cutoff, coverage_extension, num_threads, mod_bin_folder)
            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'7th contig OLC done!')
            f_cp_m.close()
        
        if last_step < 8:
            print('Starting reassembly')
            binset_folder='BestBinset_outlier_refined_filtrated_retrieved_retrieved_OLC'
            datasets_list={}
            for ds in datasets.keys():
                datasets_list[ds]=[]
                datasets_list[ds].append('PE_r1_'+str(datasets[ds][0]))
                datasets_list[ds].append('PE_r2_'+str(datasets[ds][1]))

            if len(long_read) != 0:
                long_read_seq=open('long_reads_merge.fq','w')
                for lr in long_read:
                    for line in open(lr,'r'):
                        long_read_seq.write(str(line))
                long_read_seq.close()
            else:
                long_read_seq=''

            re_assembly_main(binset_folder, datasets_list, long_read_seq, ram, num_threads)
            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'8th reassembly done!')
            f_cp_m.close()

    #     if last_step < 9:
    #         print('Starting 2nd OLC process')
    #         target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved_OLC_re-assembly' ### Maybe an issue. Make sure the folder name is correct
    #         step='OLC_after_reassembly' ### 'assemblies_OLC' or 'OLC_after_reassembly' ; 'assemblies_OLC' means 1st OLC; 'OLC_after_reassembly' means OLC after reassembly
    #         bin_comparison_folder='' ### if 'assemblies_OLC', folder bin_comparison_folder is needed; else if 'assemblies_OLC', the folder is not needed, just let it blank
    #         aligned_len=500
    #         similarity=99.5
    #         coverage_extension=95
    #         OLC_main(target_bin_folder, step, bin_comparison_folder, aligned_len, similarity, coverage_extension, num_threads)
    #         f_cp_m=open('Basalt_checkpoint.txt', 'a')
    #         f_cp_m.write('\n'+'8th 2nd OLC done!')
    #         f_cp_m.close()
    
    # if extra == 'visual':
    #     print('Generation of visualization files')
    f_cp_m=open('Basalt_checkpoint.txt', 'a')
    f_cp_m.write('\n'+'BASALT done!')
    f_cp_m.close()
    print('Done!')

if __name__ == '__main__': 
    assembly_list=['8_medium_S001_SPAdes_scaffolds.fasta','10_medium_cat_SPAdes_scaffolds.fasta']
    datasets={'1':['RM2_S001_insert_270_mate1.fq','RM2_S001_insert_270_mate2.fq'], '2':['RM2_S002_insert_270_mate1.fq','RM2_S002_insert_270_mate2.fq']}
    long_read_assembly_list=[]
    long_read={}
    num_threads=44
    ram=120
    pwd=os.getcwd()
    refinement_mode='reassembly' ### mode type: 1. quick_refinement; 2. reassembly
    refinement_1st_mode='Quick' ### 1st refinement mode: 1. Quick; 2. Deep
    auto_binning_mode='more-sensitive' ### 'quick', 'sensitive', 'more-sensitive'
    extra='visual' ### extra: 1. none; 2. visual
    parameter='last' ### parameter type: 1. last: start from the latest step finished from the last time; 2. new: start from beginning
    snakemake(assembly_list, datasets, num_threads, refinement_mode, refinement_1st_mode, auto_binning_mode, parameter, extra, long_read_assembly_list, long_read, ram, pwd)
