#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

import time, sys, os, copy
from Bio import SeqIO
from Autobinners import *
from BinsAbundance_PE_connections import *
from Bins_comparator_within_group import *
from Multiple_Assemblies_Comparitor import *
from Outlier_remover import *
from Contig_retriever_PE import *
from Contig_retriever_within_group import *
from Bin_OLC_multi_assemblies import *
from Bins_reassembly import *
from Bin_OLC_reassembly import *

# def BASALT_main(assembly_list, datasets, num_threads, refinement_mode, refinement_1st_mode, auto_binning_mode, parameter, extra, long_read_assembly_list, long_read, ram, pwd):
def BASALT_main(assembly_list, datasets, num_threads, lr_list, ram, continue_mode, functional_module, autobinning_parameters, refinement_paramter, max_ctn, min_cpn, pwd):
    ### Record the last accomplished step
    pwd=os.getcwd()
    last_step=0
    if continue_mode == 'last':
        try:
            n=0
            for line in open('Basalt_checkpoint.txt', 'r'):
                n+=1

            n1=0
            for line in open('Basalt_checkpoint.txt', 'r'):
                n1+=1
                if n1 == n:
                    ls=str(line)[0]
                    try:
                        ls2=int(str(line)[1])
                        last_step=int(str(ls)+str(ls2))
                    except:
                        last_step=int(ls)
                    # last_step=int(str(line).replace('th','').replace('st','').replace('nd','').replace('rd','').split(' ')[0])
        except:
            f_cp_m=open('Basalt_checkpoint.txt', 'w')
            f_cp_m.close()
    else:
        f_cp_m=open('Basalt_checkpoint.txt', 'w')
        f_cp_m.close()

    print('BASALT started from step: '+str(last_step))
    try:
        f=open('BASALT_command.txt','a')
        f.write('BASALT restarted from step: '+str(last_step)+'\n')
        f.close()
    except:
        f=open('BASALT_command.txt','w')
        f.write('BASALT started from 1st step'+'\n')
        f.write('Assemblies: '+str(str(assembly_list).replace('[','').replace(']','').replace(' ','').replace('\'',''))+'\n')
        f.write('Datasets: ')
        datasets_list=datasets.split(',')
        x=0
        for ds in datasets_list:
            x+=1
            ds1=str(ds).split('[')[1].replace('\'','').replace(']','').replace(' ','')
            if x == 1:
                f.write(str(ds1))
            else:
                f.write('/'+str(ds1))
        f.write('\n')
        try:
            f.write('Long reads: '+str(str(lr_list).replace('[','').replace(']','').replace(' ','').replace('\'',''))+'\n')
        except:
            f.write('Long reads: []'+'\n')
        f.write('Num threads: '+str(num_threads)+'\n'+'Ram: '+str(ram)+'\n'+'Refinement mode: '+str(refinement_paramter)+'\n')
        f.write('Autobinning mode: '+str(autobining_parameters)+'\n'+'Functional mode: '+str(functional_module)+'\n'+'Continue mode: '+str(continue_mode)+'\n')
        f.write('Max contamination: '+str(max_ctn)+'\n'+'Min completeness: '+str(min_cpn)+'\n')
        f.close()

    x = 0
    datasets2=copy.deepcopy(datasets)
    for item in datasets.keys():
        hz_list=datasets[item][0].split('.')
        if len(hz_list) >= 2:
            if hz_list[-1] == 'fq' or hz_list[-1] == 'fastq':
                x=1
            elif hz_list[-1] == 'zip':
                x=2
            elif hz_list[-1] == 'gz':
                if hz_list[-2] == 'tar':
                    x=3
                else:
                    x=4
        else:
            print('Input format error! Please check the input file.')
            print('BASALT supports the input (1) sequence files in  .gz, .zip, and .tar.gz; (2) and assemlies in .fa, .fna, .fasta.')

    if x > 1:
        datasets={}
        for item in datasets2.keys():
            datasets[item]=[]
            if x == 2:
                f1_d=str(datasets2[item][0]).split('.zip')[0]
                f2_d=str(datasets2[item][1]).split('.zip')[0]
                if os.path.exists(pwd+'/PE_r1_'+str(f1_d)):
                    z=0
                else:
                    os.system('unzip '+str(datasets2[item][0]))

                if os.path.exists(pwd+'/PE_r2_'+str(f2_d)):
                    z=0
                else:
                    os.system('unzip '+str(datasets2[item][1]))

            elif x == 3:
                f1=str(datasets2[item][0])
                f2=str(datasets2[item][1])
                f1_d=str(f1).split('.tar.gz')[0]
                f2_d=str(f2).split('.tar.gz')[0]
                if os.path.exists(pwd+'/PE_r1_'+str(f1_d)):
                    z=0
                else:
                    os.system('tar -zxf '+str(f1))
                if os.path.exists(pwd+'/PE_r2_'+str(f2_d)):
                    z=0
                else:
                    os.system('tar -zxf '+str(f2))

            elif x == 4:
                f1=str(datasets2[item][0])
                f2=str(datasets2[item][1])
                f1_d=f1.split('.gz')[0]
                f2_d=f2.split('.gz')[0]
                if os.path.exists(pwd+'/PE_r1_'+str(f1_d)):
                    z=0
                else:
                    os.system('gunzip -c '+f1+' > '+f1_d)
                if os.path.exists(pwd+'/PE_r2_'+str(f2_d)):
                    z=0
                else:                    
                    os.system('gunzip -c '+f2+' > '+f2_d)

            if '.fq' not in f1_d and '.fastq' not in f1_d:
                f1_d=f1_d+'.fq'
            if '.fq' not in f2_d and '.fastq' not in f2_d:
                f2_d=f2_d+'.fq'
            datasets[item].append(f1_d)
            datasets[item].append(f2_d)

    x=0
    assembly_list2=copy.deepcopy(assembly_list)
    for item in assembly_list:
        hz_list=assembly_list[0].split('.')
        if len(hz_list) >= 2:
            if hz_list[-1] == 'fa' or hz_list[-1] == 'fasta' or hz_list[-1] == 'fna':
                x=1
            elif hz_list[-1] == 'zip':
                x=2
            elif hz_list[-1] == 'gz':
                if hz_list[-2] == 'tar':
                    x=3
                else:
                    x=4
        else:
            print('Input format error! Please check the input file.')
            print('BASALT supports the input (1) sequence files in  .gz, .zip, and .tar.gz; (2) and assemlies in .fa, .fna, .fasta.')
    
    if x > 1:
        assembly_list=[]
        for item in assembly_list2:
            if x == 2:
                f_d=str(item).split('.zip')[0]
                if os.path.exists(pwd+'/'+str(f_d)):
                    z=0
                else:   
                    os.system('unzip '+str(item))
            
            elif x == 3:
                f_d=str(item).split('.tar.gz')[0]
                if os.path.exists(pwd+'/'+str(f_d)):
                    z=0
                else:
                    os.system('tar -zxf '+str(item))

            elif x == 4:
                f_d=str(item).split('.gz')[0]
                if os.path.exists(pwd+'/'+str(f_d)):
                    z=0
                else:
                    os.system('gunzip -c '+str(item)+' > '+str(f_d))

            if '.fa' not in f_d and '.fna' not in f_d and '.fasta' not in f_d:
                f_d=f_d+'.fa'
            assembly_list.append(f_d)

    ### Autobinner
    if functional_module == 'autobinning' or functional_module == 'all':
        if last_step == 0:
            print('----------------------------------')
            print('Running autobinner')
            print('Processing files in '+str(pwd))
            A=autobinner_main(assembly_list, datasets, num_threads, autobinning_parameters, pwd)
            bins_folders_dic=A[0]
            connections_total_dict=A[1]
            depth_total=A[2]
            assembly_MoDict=A[3]
            # mod_datasets_fq=A[4]

            f1=open('Connections_total_dict.txt','w')
            for item in connections_total_dict.keys():
                f1.write(str(item)+'\t'+str(connections_total_dict[item])+'\n')
            f1.close()

            f1=open('Depth_total.txt','w')
            for item in depth_total.keys():
                f1.write(str(item)+'\t'+str(depth_total[item])+'\n')
            f1.close()

            f1=open('Assembly_MoDict.txt','w')
            for item in assembly_MoDict.keys():
                f1.write(str(item)+'\t'+str(assembly_MoDict[item])+'\n')
            f1.close()

            # bins_folders, n={}, 0
            f1=open('Bins_folder.txt','w')
            for item in bins_folders_dic.keys():
                # n+=1
                # bins_folders[str(n)]=[]
                f1.write(str(item)+'\t'+str(bins_folders_dic[item])+'\n')
                # genomes_list=str(bins_folders_dic[item]).strip().replace('[','').replace(']','').replace('\'','').replace(' ','').split(',')
                # for genomes_folder in genomes_list:
                #     genomes_folder_name_list=genomes_folder.split('_')
                #     genomes_folder_name_list.remove(genomes_folder_name_list[-1])
                #     genomes_folder_name='_'.join(genomes_folder_name_list)
                #     bins_folders[str(n)].append(genomes_folder_name)
            f1.close()    

            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('1st autobinner done!')
            f_cp_m.close()
            #connections_total_dict={'9groups_assembly.fa':'condense_connections_9groups_assembly.fa.txt', 'AN1-32_assembly.fa':'condense_connections_AN1-32_assembly.fa.txt'}
            #depth_total={'9groups_assembly.fa':'1_assembly.depth.txt', 'AN1-32_assembly.fa':'2_assembly.depth.txt'}
            #assembly_MoDict={'9groups_assembly.fa':'1_9groups_assembly.fa', 'AN1-32_assembly.fa':'2_AN1-32_assembly.fa'}
            #bins_folders={'9groups_assembly.fa':['1_9groups_assembly.fa_0.3_genomes','1_9groups_assembly.fa_0.5_genomes','1_9groups_assembly.fa_0.7_genomes','1_9groups_assembly.fa_0.9_genomes','1_9groups_assembly.fa_1000_concoct_genomes','1_9groups_assembly.fa_400_concoct_genomes','1_9groups_assembly.fa_200_concoct_genomes','1_9groups_assembly.fa_200_metabat_genomes','1_9groups_assembly.fa_300_metabat_genomes','1_9groups_assembly.fa_400_metabat_genomes','1_9groups_assembly.fa_500_metabat_genomes'], 'AN1-32_assembly.fa':['2_AN1-32_assembly.fa_0.3_maxbin2_genomes','2_AN1-32_assembly.fa_0.9_maxbin2_genomes','2_AN1-32_assembly.fa_0.7_maxbin2_genomes','2_AN1-32_assembly.fa_0.5_maxbin2_genomes','2_AN1-32_assembly.fa_200_metabat_genomes','2_AN1-32_assembly.fa_300_metabat_genomes','2_AN1-32_assembly.fa_400_metabat_genomes','2_AN1-32_assembly.fa_500_metabat_genomes','2_AN1-32_assembly.fa_200_concoct_genomes','2_AN1-32_assembly.fa_400_concoct_genomes','2_AN1-32_assembly.fa_1000_concoct_genomes']}

        ### Bin selecting process
        if last_step < 2:
            connections_total_dict, depth_total, assembly_MoDict, bins_folders = {}, {}, {}, {}
            n=0
            for line in open('Connections_total_dict.txt','r'):
                n+=1
                # connections_total_dict[str(line).strip().split('\t')[1].strip().split('_')[0]]=str(line).strip().split('\t')[1].strip()
                connections_total_dict[str(n)]=str(line).strip().split('\t')[1].strip()
            n=0
            for line in open('Depth_total.txt','r'):
                n+=1
                depth_total[str(n)]=str(line).strip().split('\t')[1].strip()
                # depth_total[str(line).strip().split('\t')[1].strip().split('_')[0]]=str(line).strip().split('\t')[1].strip()
            n=0
            for line in open('Assembly_MoDict.txt','r'):
                n+=1
                assembly_MoDict[str(n)]=str(line).strip().split('\t')[1].strip()
                # assembly_MoDict[str(line).strip().split('\t')[1].strip().split('_')[0]]=str(line).strip().split('\t')[1].strip()

            n=0
            for line in open('Bins_folder.txt','r'):
                n+=1
                # assembly_name=str(line).strip().split('[')[1].replace('\'','').split('_')[0]
                bins_folders[str(n)]=[]
                genomes_list=str(line).strip().split('\t')[1].strip().replace('[','').replace(']','').replace('\'','').replace(' ','').split(',')
                for genomes_folder in genomes_list:
                    genomes_folder_name_list=genomes_folder.split('_')
                    genomes_folder_name_list.remove(genomes_folder_name_list[-1])
                    genomes_folder_name='_'.join(genomes_folder_name_list)
                    bins_folders[str(n)].append(genomes_folder_name)
                    
            Ax=binsabundance_pe_connections(bins_folders, depth_total, connections_total_dict, assembly_MoDict, num_threads)

            print('Starting best bin selection: within each group')
            coverage_matrix_list, bestbinset_list, assembly_mo_list=[], [], []
            for item in bins_folders.keys():
                print('---------------------------')
                print('Processing group '+str(item)+' '+str(bins_folders[item]))
                coverage_matrix_list.append(Ax[item])
                genome_folder_list=bins_folders[item]
                genomes_folder_name_list=[]
                for item2 in genome_folder_list:
                    genomes_folder_name_list.append(item2+'_genomes')
                # Bx=bins_comparator_multiple_groups(genome_folder_list, assembly_MoDict[item])
                Bx=bins_comparator_multiple_groups(genomes_folder_name_list, assembly_MoDict[item])
                print('Adding '+str(Bx)+' to the bestbinset list')
                bestbinset_list.append(Bx)
                print('Adding '+str(assembly_MoDict[item])+' to the assembly modified list')
                assembly_mo_list.append(assembly_MoDict[item])

            f1=open('Coverage_matrix_list.txt','w')
            for item in coverage_matrix_list:
                f1.write(str(item)+'\n')
            f1.close()

            f1=open('Bestbinset_list.txt','w')
            for item in bestbinset_list:
                f1.write(str(item)+'\n')
            f1.close()

            f1=open('Assembly_mo_list.txt','w')
            for item in assembly_mo_list:
                f1.write(str(item)+'\n')
            f1.close()

            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'2nd bin selection within group done!')
            f_cp_m.close()

            #coverage_matrix_list=['Coverage_matrix_for_binning_1_I4_assembly.fa.txt','Coverage_matrix_for_binning_2_I6_assembly.fa.txt','Coverage_matrix_for_binning_3_I12_assembly.fa.txt','Coverage_matrix_for_binning_4_I_assembly.fa.txt']
            #bestbinset_list=['1_I4_assembly.fa_BestBinsSet','2_I6_assembly.fa_BestBinsSet','3_I12_assembly.fa_BestBinsSet','4_I_assembly.fa_BestBinsSet']
            #assembly_mo_list=['1_I4_assembly.fa', '2_I6_assembly.fa', '3_I12_assembly.fa', '4_I_assembly.fa']

        if last_step < 3:
            if len(assembly_list) != 1:
                print('Starting best bin selection: within multiple groups')
                if last_step == 2:
                    coverage_matrix_list, bestbinset_list, assembly_mo_list=[], [], []
                    for line in open('Coverage_matrix_list.txt','r'):
                        coverage_matrix_list.append(str(line).strip())

                    for line in open('Bestbinset_list.txt','r'):
                        bestbinset_list.append(str(line).strip())
                    
                    for line in open('Assembly_mo_list.txt','r'):
                        assembly_mo_list.append(str(line).strip())

                # multiple_assembly_comparitor_main(assembly_mo_list, bestbinset_list, coverage_matrix_list, num_threads)
                datasets_fq={}
                for item in datasets.keys():
                    datasets_fq[item]=[]
                    datasets_fq[item].append('PE_r1_'+str(datasets[item][0]))
                    datasets_fq[item].append('PE_r2_'+str(datasets[item][1]))
                multiple_assembly_comparitor_main(assembly_mo_list, bestbinset_list, coverage_matrix_list, datasets_fq, 'initial_drep', num_threads)

                f_cp_m=open('Basalt_checkpoint.txt', 'a')
                f_cp_m.write('\n'+'3rd bin selection within multiple groups done!')
                f_cp_m.close()
            else:
                f_cp_m=open('Basalt_checkpoint.txt', 'a')
                f_cp_m.write('\n'+'3rd bin selection did not perform, because there is only one assembly!')
                f_cp_m.close()

    if functional_module == 'refinement' or functional_module == 'all':
        if last_step < 4:
            print('Starting outlier removal process')
            coverage_matrix_list, connections_list, assembly_mo_list, bestbinset_list = [], [], [], []
            for line in open('Coverage_matrix_list.txt','r'):
                coverage_matrix_list.append(str(line).strip())
            for line in open('Assembly_mo_list.txt','r'):
                assembly_mo_list.append(str(line).strip())
            for line in open('Bestbinset_list.txt','r'):
                bestbinset_list.append(str(line).strip())
            
            for item in assembly_list:
                connections_list.append('condense_connections_'+item+'.txt')
            if len(bestbinset_list) == 1:
                print('Copying '+str(bestbinset_list[0])+' to BestBinset')
                os.system('cp -r '+str(bestbinset_list[0])+' BestBinset')
            contig_outlier_remover_main('BestBinset', coverage_matrix_list, connections_list, num_threads, ram)
            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'4th outlier removal done!')
            f_cp_m.close()

        if last_step < 5:
            print('Starting contig retrival process')
            best_binset_from_multi_assemblies='BestBinset_outlier_refined'
            outlier_remover_folder='BestBinset_outlier_refined'
            
            coverage_matrix_list, connections_list, assembly_mo_list = [], [], []
            for line in open('Coverage_matrix_list.txt','r'):
                coverage_matrix_list.append(str(line).strip())
            for line in open('Assembly_mo_list.txt','r'):
                assembly_mo_list.append(str(line).strip())
            for line in open('Assembly_MoDict.txt','r'):
                item=str(line).strip().split('\t')[0].strip()
                connections_list.append('condense_connections_'+item+'.txt')

            Contig_recruiter_main(best_binset_from_multi_assemblies, outlier_remover_folder, num_threads, continue_mode, min_cpn, max_ctn, assembly_mo_list, connections_list, coverage_matrix_list, refinement_paramter, pwd)
            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'5th contig retrieve done!')
            f_cp_m.close()
            os.system('cp -r BestBinset_outlier_refined_filtrated_retrieved BestBinset_outlier_refined_filtrated_retrieved_backup')

        if last_step < 6:
            ### Second de-replication: S4 function
            if len(assembly_list) != 1:
                #drep_list='BestBinset_outlier_refined_filtrated_retrieved'

                coverage_matrix_list, bestbinset_list = [], []
                for line in open('Bestbinset_list.txt','r'):
                    bestbinset_list.append(str(line).strip())
            
                for line in open('Coverage_matrix_list.txt','r'):
                    coverage_matrix_list.append(str(line).strip())

                datasets_fq={}
                for item in datasets.keys():
                    datasets_fq[item]=[]
                    datasets_fq[item].append('PE_r1_'+str(datasets[item][0]))
                    datasets_fq[item].append('PE_r2_'+str(datasets[item][1]))

                # multiple_assembly_comparitor_main(drep_list, bestbinset_list, coverage_matrix_list, datasets_fq, 'second_drep', num_threads)
                final_binset_comparitor('BestBinset_outlier_refined_filtrated_retrieved', coverage_matrix_list, datasets_fq, num_threads, pwd, 'second_drep')
            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'6th secondary de-repplication done!')
            f_cp_m.close()

        if last_step < 7:
            if len(lr_list) == 0:
                print('Starting contig retrival within group')
                # Contig_recruiter_main('BestBinset_outlier_refined', num_threads, parameter, 35, 20)
                best_binset_after_contig_retrieve='BestBinset_outlier_refined_filtrated_retrieved'
                outlier_remover_folder='BestBinset_outlier_refined'
                cpn_cutoff=35 ### The minimun completeness to keep
                ctn_cutoff=5 ### The maximal contaminaition to keep

                coverage_matrix_list, connections_list, assembly_mo_list = [], [], []
                for line in open('Coverage_matrix_list.txt','r'):
                    coverage_matrix_list.append(str(line).strip())
                for line in open('Assembly_mo_list.txt','r'):
                    assembly_mo_list.append(str(line).strip())
                for line in open('Assembly_MoDict.txt','r'):
                    item=str(line).strip().split('\t')[0].strip()
                    connections_list.append('condense_connections_'+item+'.txt')

                Contig_retrieve_within_group_main(best_binset_after_contig_retrieve, outlier_remover_folder, num_threads, continue_mode, cpn_cutoff, ctn_cutoff, assembly_mo_list, connections_list, coverage_matrix_list)

                f_cp_m=open('Basalt_checkpoint.txt', 'a')
                f_cp_m.write('\n'+'7th contig retrieve within group done!')
                f_cp_m.close()
            else:
                f_cp_m=open('Basalt_checkpoint.txt', 'a')
                f_cp_m.write('\n'+'7th did not perform retrieve with group because long-read presented!')
                f_cp_m.close()
    
    if functional_module == 'reassembly' or functional_module == 'all':
        if last_step < 8:
            print('Starting OLC process')
            if len(assembly_list) > 1:
                if len(lr_list) == 0:
                    try:
                        bin_n=0
                        os.chdir(pwd+'/BestBinset_outlier_refined_filtrated_retrieved_retrieved')
                        for root, dirs, files in os.walk(pwd+'/BestBinset_outlier_refined_filtrated_retrieved_retrieved'):
                            for file in files:
                                hz=file.split('.')[-1]
                                if 'fa' in hz or 'fna' in hz:
                                    bin_n+=1
                        os.chdir(pwd)
                        if bin_n != 0:
                            target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved_retrieved'
                        else:
                            target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved'
                    except:
                        print('There is not bin in BestBinset_outlier_refined_filtrated_retrieved_retrieved. Try BestBinset_outlier_refined_filtrated_retrieved')
                        target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved'
                else:
                    target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved'

                print('Processing with bins in '+str(target_bin_folder))
                bin_comparison_folder='BestBinset_comparison_files'
                step='assemblies_OLC'
                aligned_len_cutoff=500
                similarity_cutoff=99
                coverage_extension=95
                mod_bin_folder=[]
                OLC_main(target_bin_folder, step, bin_comparison_folder, aligned_len_cutoff, similarity_cutoff, coverage_extension, num_threads, mod_bin_folder)
                f_cp_m=open('Basalt_checkpoint.txt', 'a')
                f_cp_m.write('\n'+'8th contig OLC done!'+'\t'+target_bin_folder+'_OLC')
                f_cp_m.close()
            else:
                if len(lr_list) != 0:
                    target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved'
                else:
                    try:
                        bin_n=0
                        os.chdir(pwd+'/BestBinset_outlier_refined_filtrated_retrieved_retrieved')
                        for root, dirs, files in os.walk(pwd+'/BestBinset_outlier_refined_filtrated_retrieved_retrieved'):
                            for file in files:
                                hz=file.split('.')[-1]
                                if 'fa' in hz or 'fna' in hz:
                                    bin_n+=1
                        os.chdir(pwd)
                        if bin_n != 0:
                            target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved_retrieved'
                        else:
                            target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved'
                    except:
                        print('There is not bin in BestBinset_outlier_refined_filtrated_retrieved_retrieved. Try BestBinset_outlier_refined_filtrated_retrieved')
                        target_bin_folder='BestBinset_outlier_refined_filtrated_retrieved'
                f_cp_m=open('Basalt_checkpoint.txt', 'a')
                f_cp_m.write('\n'+'8th contig OLC did not perform!'+'\t'+target_bin_folder)
                f_cp_m.close()

        if last_step < 9:
            print('Starting reassembly')
            for line in open('Basalt_checkpoint.txt', 'r'):
                if '8th contig OLC' in line:
                    binset_folder=str(line).strip().split('\t')[1].strip()
                    print('Processing bins in '+str(binset_folder))

            datasets_list={}
            for ds in datasets.keys():
                datasets_list[ds]=[]
                datasets_list[ds].append('PE_r1_'+str(datasets[ds][0]))
                datasets_list[ds].append('PE_r2_'+str(datasets[ds][1]))

            if len(lr_list) != 0:
                x=0
                lr_list2=copy.deepcopy(lr_list)
                for item in lr_list:
                    hz_list=lr_list[0].split('.')
                    if len(hz_list) >= 2:
                        if hz_list[-1] == 'fq' or hz_list[-1] == 'fastq':
                            x=1
                        elif hz_list[-1] == 'zip':
                            x=2
                        elif hz_list[-1] == 'gz':
                            if hz_list[-2] == 'tar':
                                x=3
                            else:
                                x=4
                    else:
                        print('Input format error! Please check the input file.')
                        print('BASALT supports the input (1) sequence files in  .gz, .zip, and .tar.gz; (2) and assemlies in .fa, .fna, .fasta.')
                
                if x > 1:
                    lr_list=[]
                    for item in lr_list2:
                        if x == 2:
                            f_d=str(item).split('.zip')[0]
                            if os.path.exists(pwd+'/'+str(f_d)):
                                z=0
                            else:   
                                os.system('unzip '+str(item))
                        
                        elif x == 3:
                            f_d=str(item).split('.tar.gz')[0]
                            if os.path.exists(pwd+'/'+str(f_d)):
                                z=0
                            else:
                                os.system('tar -zxf '+str(item))

                        elif x == 4:
                            f_d=str(item).split('.gz')[0]
                            if os.path.exists(pwd+'/'+str(f_d)):
                                z=0
                            else:
                                os.system('gunzip -c '+str(item)+' > '+str(f_d))
                        
                        if '.fq' not in f_d and '.fastq' not in f_d:
                            f_d=f_d+'.fq'
                        lr_list.append(f_d)

            re_assembly_main(binset_folder, datasets_list, lr_list, ram, num_threads)
            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'9th reassembly done.'+'\t'+str(binset_folder)+'_re-assembly')
            f_cp_m.close()
        
        if last_step < 10:
            print('Starting reassemblies OLC')
            for line in open('Basalt_checkpoint.txt', 'r'):
                if '9th reassembly done' in line:
                    target_bin_folder=str(line).strip().split('\t')[1].strip()
                    print('Processing bins in '+str(target_bin_folder))

            bin_comparison_or_reassembly_binset_folder=target_bin_folder+'_binset'
            orig_binset=target_bin_folder.split('_re-assembly')[0]+'_mod'
            step='OLC_after_reassembly'
            aligned_len_cutoff=500
            similarity_cutoff=98
            coverage_extension=90

            reassembly_OLC_main(target_bin_folder, step, bin_comparison_or_reassembly_binset_folder, aligned_len_cutoff, similarity_cutoff, coverage_extension, num_threads, ram, orig_binset)
            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'10th reassemblies OLC done.'+'\t'+target_bin_folder+'_OLC')
            f_cp_m.close()
        
        if last_step < 11:
            ### Final de-replication: S4 function
            for line in open('Basalt_checkpoint.txt', 'r'):
                if '10th reassemblies OLC done' in line:
                    final_folder=str(line).strip().split('\t')[1].strip()

            if len(assembly_list) != 1:                
                coverage_matrix_list, bestbinset_list = [], []
                for line in open('Bestbinset_list.txt','r'):
                    bestbinset_list.append(str(line).strip())
            
                for line in open('Coverage_matrix_list.txt','r'):
                    coverage_matrix_list.append(str(line).strip())

                datasets_fq={}
                for item in datasets.keys():
                    datasets_fq[item]=[]
                    datasets_fq[item].append('PE_r1_'+str(datasets[item][0]))
                    datasets_fq[item].append('PE_r2_'+str(datasets[item][1]))

                # multiple_assembly_comparitor_main(drep_list, bestbinset_list, coverage_matrix_list, datasets_fq, 'final_drep', num_threads)
                final_binset_comparitor(final_folder, coverage_matrix_list, datasets_fq, num_threads, pwd, 'final_drep')
            f_cp_m=open('Basalt_checkpoint.txt', 'a')
            f_cp_m.write('\n'+'11th final de-replication done!')
            f_cp_m.close()

        ### Final binset
        os.system('mv '+str(final_folder)+' Final_bestbinset')

        f_cp_m=open('Basalt_checkpoint.txt', 'a')
        f_cp_m.write('\n'+'BASALT done!')
        f_cp_m.close()
    print('BASALT main program accomplished!')
    print('BASALT will continue to cleanup or compress all the temp files. Please wait for a little bit longer')

    ### Cleanup
    os.mkdir('Coverage_depth_connection_SimilarBin_files_backup')
    os.system('mv *.depth.txt Coverage_matrix_* Combat_* condense_connections_* Connections_* Similar_bins.txt Coverage_depth_connection_SimilarBin_files_backup')
    os.system('tar -czf Coverage_depth_connection_SimilarBin_files_backup.tar.gz Coverage_depth_connection_SimilarBin_files_backup')
    os.system('rm -rf Coverage_depth_connection_SimilarBin_files_backup')
    os.system('rm -rf *_kmer bin_coverage Bin_coverage_after_contamination_removal bin_comparison_folder bin_extract-eleminated-selected_contig Bins_blast_output')
    os.system('tar -czf Group_comparison_files.tar.gz *_comparison_files')
    # os.system('tar -zcvf Group_Bestbinset.tar.gz *_BestBinset')
    os.system('tar -czf Group_checkm.tar.gz *_checkm')
    os.system('tar -czf Group_genomes.tar.gz *_genomes')
    os.system('tar -zcvf Binsets_backup.tar.gz BestBinse*') ###
    os.system('rm -rf *_comparison_files *_checkm *_genomes *_BestBinset BestBinse* Deep_retrieved_bins coverage_deep_refined_bins S6_coverage_filtration_matrix S6_TNF_filtration_matrix split_blast_output TNFs_deep_refined_bins')
    os.system('rm *_checkpoint.txt')
    os.system('rm -rf Merged_seqs_*')
    os.system('rm -rf *.bt2 Outlier_in_threshold* Summary_threshold* Refined_total_bins_contigs.fa Total_bins.fa') 
    for i in range(1,20):
        os.system('rm -rf *_deep_retrieval_'+str(i))
    print('Done!')

if __name__ == '__main__': 
    assembly_list=['8_medium_S001_SPAdes_scaffolds.fasta','10_medium_cat_SPAdes_scaffolds.fasta']
    datasets={'1':['RM2_S001_insert_270_mate1.fq','RM2_S001_insert_270_mate2.fq'], '2':['RM2_S002_insert_270_mate1.fq','RM2_S002_insert_270_mate2.fq']}
    lr_list=[]
    num_threads=30
    ram=120
    pwd=os.getcwd()
    refinement_paramter='deep' ### 1st refinement mode: 1. quick; 2. deep
    autobining_parameters='more-sensitive' ### 'quick', 'sensitive', 'more-sensitive'
    functional_module='all' ### 1. all; 2. autobinning; 3. refinement; 4. reassembly
    continue_mode='last' ### parameter type: 1. continue(last): start from the latest step finished from the last time; 2. new: start from beginning
    max_ctn, min_cpn=20, 35 
    # BASALT_main(assembly_list, datasets, num_threads, lr_list, ram, continue_mode, functional_module, autobining_parameters, refinement_paramter, max_ctn, min_cpn, pwd)
    BASALT_main(assembly_list, datasets, num_threads, lr_list, ram, continue_mode, functional_module, autobining_parameters, refinement_paramter, max_ctn, min_cpn, pwd)
