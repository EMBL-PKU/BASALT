#!/usr/bin/env python
from Bio import SeqIO
import sys, os, threading, copy
from multiprocessing import Pool


def parse_lr_sam(sam_file, long_read):
    print('Reading long reads id')
    # f_not_mapped_reads=open('Not_mapped_reads.txt','w')
    bin_lr, bin_lr2, lr_bin, lr_bin2 = {}, {}, {}, {}
    m, m1, m2 = 0, 0, 0
    for line in open(sam_file,'r'):
        m1+=1
        flist=str(line).split('\t')
        if len(flist) >= 12:
            read_id=flist[0]
            bin_id=flist[2].split('_')[0]
            bin_lr[bin_id]={}
            lr_bin[read_id]={}

        if m1 % 1000000 == 0:
            print('Read', m1,'lines')

    print('Collecting long reads')
    for line in open(sam_file,'r'):
        m2+=1
        flist=str(line).split('\t')
        if len(flist) >= 12:
            bin_id=flist[2].split('_')[0]
            seqs=flist[9]
            if 'bin' in bin_id and len(seqs) >= 100:
                read_id=flist[0]
                bin_lr[bin_id][read_id]=''
                lr_bin[read_id][bin_id]=''

        if m2 % 1000000 == 0:
            print('Read', m2,'lines')

    bin_lr2=copy.deepcopy(bin_lr)
    lr_bin2=copy.deepcopy(lr_bin)

    for item in bin_lr2.keys():
        if len(bin_lr2[item]) == 0:
            del bin_lr[item]

    for item in lr_bin2.keys():
        if len(lr_bin2[item]) == 0:
            del lr_bin[item]

    f=open('Bin_long_read.txt','w')
    for bin_id in bin_lr.keys():
        f.write(str(bin_id)+'\t'+str(bin_lr[bin_id])+'\n')
        f1=open(str(bin_id)+'_lr.fq','w')
        f1.close()
    f.close()

    f=open('Long_read_bin.txt','w')
    for lr in lr_bin.keys():
        f.write(str(lr)+'\t'+str(lr_bin[lr])+'\n')
    f.close()

    n, record_bin_line, record_bin_line2 = 0, {}, {}
    for line in open(long_read,'r'):
        n+=1
        record_bin_line[n]=[]

    n = 0
    for line in open(long_read,'r'):
        n+=1
        m=n-1
        if m % 4 == 0:
            seq_id=str(line).strip().split(' ')[0].split('@')[1]
            if seq_id in lr_bin.keys():
                for bin_id in lr_bin[seq_id].keys():
                    record_bin_line[n].append(bin_id)
                    record_bin_line[n+1].append(bin_id)
                    record_bin_line[n+2].append(bin_id)
                    record_bin_line[n+3].append(bin_id)

    record_bin_line2=copy.deepcopy(record_bin_line)
    for line in record_bin_line2.keys():
        if len(record_bin_line2[line]) == 0:
            del record_bin_line[line]

    n=0
    for line in open(long_read,'r'):
        n+=1
        if n in record_bin_line.keys():
            for bin_id in record_bin_line[n]:
                f1=open(str(bin_id)+'_lr.fq','a')
                f1.write(line)
                f1.close()

    # record_bin_line={}
    # for bin_id in bin_lr.keys():
    #     n = 0
    #     record_bin_line[bin_id]=[]
    #     for line in open(long_read,'r'):
    #         n+=1
    #         m=n-1
    #         if m % 4 == 0:
    #             # print(str(line))
    #             seq_id=str(line).strip().split(' ')[0].split('@')[1]
    #             if seq_id in bin_lr[bin_id].keys():
    #                 record_bin_line[bin_id].append(n)
    #                 record_bin_line[bin_id].append(n+1)
    #                 record_bin_line[bin_id].append(n+2)
    #                 record_bin_line[bin_id].append(n+3)

    #     if len(record_bin_line[bin_id]) != 0:
    #         f=open(str(bin_id)+'_lr.fq','w')
    #         n=0
    #         for line in open(long_read,'r'):
    #             n+=1
    #             if n in record_bin_line[bin_id]:
    #                 f.write(str(line))
    #         f.close()


    # for item in bin_lr.keys():
    #     if 'bin' not in item:
    #         del bin_lr[item]
        # else:
        #     f=open(str(item)+'_lr.fq','w')
        #     f.close()
    # print(str(len(bin_lr)),'bin(s) has long-read sequences')
    # print(str(bin_lr))

    # print('Collecting long reads')
    # for line in open(sam_file,'r'):
    #     m2+=1
    #     flist=str(line).split('\t')
    #     if len(flist) >= 12:
    #         bin_id=flist[2].split('_')[0]
    #         read_id=flist[0]
    #         fq_seq=flist[9]+'\n'+'+'+'\n'+flist[10]+'\n'
    #         # bin_lr[bin_id][read_id]=fq_seq
    #         try:
    #             f=open(str(bin_id)+'_lr.fq','a')
    #             f.write('@'+str(read_id)+'\n'+str(fq_seq))
    #             f.close()
    #         except:
    #             f_not_mapped_reads.write(str(read_id_name)+'\n')

    #     if m2 % 1000000 == 0:
    #         print('Read', m2,'lines')

    # print('Writing out long reads')
    # for line in open(sam_file,'r'):
    #     m2+=1
    #     flist=str(line).split('\t')
    #     if len(flist) >= 12:
    #         bin_id=flist[2].split('_')[0]
    #         read_id=flist[0]
    #         fq_seq=flist[9]+'\n'+'+'+'\n'+flist[10]+'\n'
    #         bin_lr[bin_id][read_id]=fq_seq

    #     if m2 % 1000000 == 0:
    #         print('Read', m2,'lines')

    # f_summary=open('Bin_reads_summary.txt','w')
    # for item in fq.keys():
    #     f_summary.write(str(item)+' SEQ number:'+str(len(fq[item]))+'\n')
    # f_summary.close()

    # print('Parsing', sam_file)
    # for line in open(sam_file,'r'):
    #     m+=1
    #     flist=str(line).split('\t')
    #     if len(flist) >= 12:
    #         bin_id=flist[2].split('_')[0]
    #         read_id=flist[0]
    #         reads=str(n)+'_'+read_id #
    #         read_num=reads.split('_')[-1] #
    #         read_id_name=str(n)+'_'+read_id.split('_')[0] #
    #         fq_seq=flist[9]+'\n'+'+'+'\n'+flist[10]+'\n'
    #         try:
    #             fq[bin_id][read_id_name]+=1
    #             f1=open(str(bin_id)+'_seq_R'+str(read_num)+'.fq','a')
    #             f1.write('@'+str(reads)[:-2]+' '+str(read_num)+'\n'+str(fq_seq))
    #             f1.close()
    #             if fq[bin_id][read_id_name] == 2:
    #                 del fq[bin_id][read_id_name]
    #         except:
    #             print('')
    #             # f_not_mapped_reads.write(str(read_id_name)+'\n')
    
    #     if m % 1000000 == 0:
    #         print('Parsed', m,'lines')
    # f_not_mapped_reads.close()

def lr_seq_filtration(lr_reads):
    n, passed_line =0, []
    for line in open(lr_reads,'r'):
        n+=1
        if n % 2 == 0 and n % 4 != 0:
            if len(line.strip()) >= 1000:
                n1=n-1
                n2=n+1
                n3=n+2
                passed_line.append(n1)
                passed_line.append(n)
                passed_line.append(n2)
                passed_line.append(n3)
    
    f=open('Filtrated_'+lr_reads,'w')
    n =0
    for line in open(lr_reads,'r'):
        n+=1
        if n in passed_line:
            f.write(str(line))
    f.close()

def last_8_line_lr_sam(sam):
    n=0
    for line in open(sam,'r'):
        n+=1

    m=n-12
    print(str(n), 'lines')
    f=open('Last_4_lines.txt','w')
    n1=0
    for line in open(sam,'r'):
        n1+=1
        if n1 <=1:
            f.write(str(line)+'\n')
        elif n1 >= m and n1 <= n:
            f.write(str(line)+'\n')
            print(str(len(str(line).strip().split('\t'))))
    f.close()

if __name__ == '__main__': 
    # last_8_line_lr_sam('xaa_lr_test.sam')
    long_read='adh_ont_p1.fq'
    # lr_seq=lr_seq_filtration('adh_ont_p1.fq')
    # parse_lr_sam('Last_4_lines.txt', long_read)
    parse_lr_sam('xaa_lr_test.sam', long_read)