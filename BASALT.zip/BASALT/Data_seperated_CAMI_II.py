#!/usr/bin/env python
f1=open('R1.fq','w')
f2=open('R2.fq','w')

n=8
for line in open('','r'):
    n+=1
    if n%8 == 5 or n%8 == 6 or n%8 == 7 or n%8 == 0:
        f2.write(line)
    else n%4 == 1 or n%4 == 2 or n%4 == 3 or n%4 == 0:
        f1.write(line)
f1.close()
f2.close()