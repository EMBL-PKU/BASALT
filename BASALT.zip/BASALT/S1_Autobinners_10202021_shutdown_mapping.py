#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

from Bio import SeqIO
import sys, os, time
from collections import Counter
from multiprocessing import Pool

def fq2fa_conversion(filename): ### Converting fq to fa
    start=time.time()
    wrerr = sys.stderr.write
    print('---')
    print("Coverting "+str(filename)+" file to FA file")

    if '.fq' in str(filename):
        filename1=filename.replace('.fq','')
    elif '.fastq' in str(filename):
        filename1=filename.replace('.fastq','')

    file1Array = filename1.split('/')
    disName = file1Array[-1]
    pwd=os.getcwd()
    filename1 = os.path.join(pwd, disName)

    count = SeqIO.convert(filename, "fastq", filename1+".fasta", "fasta")
    print("Converted %i records" % count)
    end=time.time()
    wrerr("OK, Converting Finished in %3.2f secs\n" % (end-start))
    return disName+".fasta"

def ModifyEnd_fa(filename, n): ### Adding end to fasta file    
    print('---')
    print('Adding end for PE-tracking of '+str(filename))
    print('--- pwd: ', os.getcwd())

    fout=open('PE_r'+str(n)+'_'+filename, 'w')
    m=0
    for record in SeqIO.parse(filename, 'fasta'):
        m+=1
        ids=str(m)+'_'+str(n)+'/'+str(n)
        fout.write('>'+str(ids)+'\n')
        fout.write(str(record.seq)+'\n')
    fout.close()
    print('Accomplished of adding end to '+str(filename))
    print('-----------------------------')
    return 'PE_r'+str(n)+'_'+filename

def ModifyEnd(filename, n): ### Adding end to fasta file    
    print('---')
    print('Adding end for PE-tracking of '+str(filename))
    print('--- pwd: ', os.getcwd())

    fout=open('PE_r'+str(n)+'_'+filename, 'w')
    m, m2=0, 0 
    for line in open(filename, 'r'):
        m+=1
        if '@' in line and m%4==1:
            m2+=1
            if ' ' in line:
                ids='@Seq'+str(m2)+'_modifiedID_'+str(n)+'/'+str(n)
            else:
                ids='@Seq'+str(m2)+'_modifiedID_'+str(n)+'/'+str(n)
            fout.write(str(ids)+'\n')
        else:
            fout.write(str(line))
    fout.close()
    print('Accomplished of adding end to '+str(filename))
    print('-----------------------------')
    return 'PE_r'+str(n)+'_'+filename

def PE_tracker(sam_file, output_name):
    contig_pe, contig_pe_mock, n={}, {}, 0
    for line in open(sam_file,'r'):
        n+=1
        if '\t' in line:
            sam_list=str(line).strip().split('\t')
            if len(sam_file) >= 7:
                contig=str(line).strip().split('\t')[2]
                if '_1/1' in line:
                    reads=str(line).strip().split('\t')[0].split('_1/1')[0]
                elif '_2/2' in line:
                    reads=str(line).strip().split('\t')[0].split('_2/2')[0]
                else:
                    reads=str(line).strip().split('\t')[0]
                num=len(contig_pe_mock)
                contig_pe_mock[reads]={}
                if len(contig_pe_mock) > num:
                    contig_pe[reads]={}
                    contig_pe[reads][contig]=1
                else:
                    contig_pe[reads][contig]=1
        
        if n % 1000000 == 0 :
            print('Parsed '+str(n)+' lines')
    
    print('Parsed contigs connections')
    contig_connection_list, connections, connections_mock=[], {}, 'test'
    for item in contig_pe.keys():
        if len(contig_pe[item]) == 2:
            contig_connection_list.append(str(contig_pe[item]))
    contig_connection_list.sort()

    for item in contig_connection_list:
        if item != connections_mock:
            connections_mock=item
            connecting_contigs=str(item).replace('{','').replace('}','').replace('\'','').replace(': 1','')
            connections[connecting_contigs]=1
        else:
            connections[connecting_contigs]+=1
    
    f=open(output_name,'w')
    f.write('node1'+'\t'+'inter'+'\t'+'node2'+'\t'+'connections'+'\n')
    for item in connections:
        f.write(str(item).split(',')[0]+'\t'+'0'+'\t'+str(item).split(',')[1]+'\t'+str(connections[item])+'\n')
    f.close()

def cal_connections(connections):
    PEC={}
    for item in connections:
        f=open(item, 'r')
        n=0
        for line in f:
            n+=1
            if n >= 2:
                id1=str(line).strip().split('\t')[0]
                id2=str(line).strip().split('\t')[2]
                inter=str(line).strip().split('\t')[1]
                cnt=int(str(line).strip().split('\t')[3])
                PE_ids=str(id1)+'\t'+str(inter)+'\t'+str(id2)
                if str(PE_ids) not in PEC.keys():
                    PEC[str(PE_ids)]=cnt
                else:
                    PEC[str(PE_ids)]+=cnt
    return PEC

def mapping(assembly, group, datasets, num_threads, pwd):
    n=0
    f_filtrated=open(str(group)+'_'+assembly, 'w')
    logfile=open('Mapping_log_'+str(group)+'_'+assembly+'.txt', 'w')

    print('Filtration of the contigs/scaffolds. The process keeps Contig/scaffold with larger than 1000 bp.')
    for record in SeqIO.parse(assembly,'fasta'):
        if len(record.seq) >= 1000:
            n+=1
            f_filtrated.write('>'+str(group)+'-'+str(n)+'\n'+str(record.seq)+'\n')
    f_filtrated.close()
    print('Done!')
    print('-------------')

    print('Building Bowtie2 index')
    #os.system('bowtie2-build '+str(group)+'_'+assembly+' '+str(group)+'_'+assembly)
    print('Done!')
    print('-------------')

    print('Mapping datasets to contigs/scaffolds')
    #f_coverage_matrix=open('Coverage_list_'+str(group)+'_'+assembly+'.txt', 'w')
    connections=[]
    for i in range(1, len(datasets)+1):
        logfile.write(str('Command: bowtie2 -p '+str(num_threads)+' -x '+str(group)+'_'+assembly+' -1 '+str(datasets[str(i)][0])+' -2 '+str(datasets[str(i)][1])+' -S '+str(group)+'_DNA-'+str(i)+'.sam -q --no-unal')+'\n')
        #os.system('bowtie2 -p '+str(num_threads)+' -x '+str(group)+'_'+assembly+' -1 '+str(datasets[str(i)][0])+' -2 '+str(datasets[str(i)][1])+' -S '+str(group)+'_DNA-'+str(i)+'.sam -q --no-unal')
        logfile.write(str('Command: samtools view -b -S '+str(group)+'_DNA-'+str(i)+'.sam -o '+str(group)+'_DNA-'+str(i)+'.bam')+'\n')
        #os.system('samtools view -@ '+str(num_threads)+' -b -S '+str(group)+'_DNA-'+str(i)+'.sam -o '+str(group)+'_DNA-'+str(i)+'.bam')
        #os.system('Cytoscapeviz.pl -i '+str(group)+'_DNA-'+str(i)+'.sam -f 2 -a 150 -e 500 -m 3000 -c')
        #os.system('mv condensed.cytoscape.connections.tab condensed.cytoscape.connections_'+str(group)+'_DNA-'+str(i)+'.tab')
        connections.append('condensed.cytoscape.connections_'+str(group)+'_DNA-'+str(i)+'.tab')
        #os.system('rm '+str(group)+'_DNA-'+str(i)+'.sam')
        ### py2
        logfile.write(str('Command: samtools sort -@ '+str(num_threads)+' '+str(group)+'_DNA-'+str(i)+'.bam '+str(group)+'_DNA-'+str(i)+'_sorted')+'\n')
        #os.system('samtools sort -@ '+str(num_threads)+' '+str(group)+'_DNA-'+str(i)+'.bam '+str(group)+'_DNA-'+str(i)+'_sorted') 

        #try:
        #    with open(str(group)+'_DNA-'+str(i)+'_sorted.bam', 'r') as fh:
        #        pass
        #except FileNotFoundError:
        #    print('Samtools sorting '+str(group)+'_DNA-'+str(i)+'.bam failed. Redoing')
            ### py3
        #    logfile.write(str('Command: samtools sort -@ '+str(num_threads)+' -o '+str(group)+'_DNA-'+str(i)+'_sorted.bam '+str(group)+'_DNA-'+str(i)+'.bam')+'\n')
        #    os.system('samtools sort -@ '+str(num_threads)+' -o '+str(group)+'_DNA-'+str(i)+'_sorted.bam '+str(group)+'_DNA-'+str(i)+'.bam' )
       
        #f_coverage_matrix.write('Coverage_list_DNA-'+str(i)+'.txt'+'\n')

        #if i == 1:
        #    bam_sorted=str(group)+'_DNA-1_sorted.bam'
        #else:
        #    bam_sorted+=' '+str(group)+'_DNA-'+str(i)+'_sorted.bam'
    
    #f_coverage_matrix.close()
    print('Mapping Done!')
    print('-------------')

    print('Scorting SAM file(s)')
    #print('CMD: jgi_summarize_bam_contig_depths --outputDepth '+str(group)+'_assembly.depth.txt '+ str(bam_sorted))
    #logfile.write(str('Command: jgi_summarize_bam_contig_depths --outputDepth '+str(group)+'_assembly.depth.txt '+str(bam_sorted))+'\n')
    #try:
    #    os.system(str(pwd)+'/jgi_summarize_bam_contig_depths --outputDepth '+str(group)+'_assembly.depth.txt '+str(bam_sorted))
    #    nxxyy=0
    #    for line in open(str(group)+'_assembly.depth.txt','r'):
    #        nxxyy+=1
    #        if nxxyy == 2:
    #            break
    #except:
    #    os.system('jgi_summarize_bam_contig_depths --outputDepth '+str(group)+'_assembly.depth.txt '+str(bam_sorted))
    ###os.system('/home/emma/software/metabat/jgi_summarize_bam_contig_depths --outputDepth '+str(group)+'_assembly.depth.txt '+str(bam_sorted))
    #os.system('rm '+str(bam_sorted))
    logfile.close()

    #for i in range(1, len(datasets)+1):
    #    f=open('Coverage_list_DNA-'+str(i)+'.txt', 'w')
    #    n=0
    #    for line in open(str(group)+'_assembly.depth.txt', 'r'):
    #        n+=1
    #        if n > 1:
    #            ids=str(line).strip().split('\t')[0]
    #            coverage=str(line).strip().split('\t')[2*int(i)+1]
    #            f.write(str(ids)+'\t'+str(coverage)+'\n')
    #        else:
    #            continue
    #    f.close()
    print('Done with generation of depth file!')
    print('-------------')
    return str(group)+'_'+assembly, str(group)+'_assembly.depth.txt', connections, 'Coverage_list_'+str(group)+'_'+assembly+'.txt'

def bin_filtration(folder_name, pwd):
    os.chdir(pwd+'/'+str(folder_name))
    for root,dirs,files in os.walk(pwd+'/'+str(folder_name)):
        for file in files:
            hz=str(file).split('.')[-1]
            if 'fa' in hz or 'fna' in hz:
                try:
                    seq_len=0
                    for record in SeqIO.parse(file,'fasta'):
                        seq_len+=int(len(record.seq))
                except:
                    seq_len=0
                
                if seq_len >= 30000000:
                    os.system('rm '+str(file))
    os.chdir(pwd)

def metabat(assembly_file, pwd, depth_file, threshold, num_threads):
    metabat_genome=str(assembly_file)+'_'+str(threshold)+'_metabat_genomes'
    metabat_checkm=str(assembly_file)+'_'+str(threshold)+'_metabat_checkm'
    os.system('cp '+str(assembly_file)+' '+str(depth_file)+' '+pwd+'/'+str(metabat_genome))
    os.chdir(pwd+'/'+str(metabat_genome))
    print('Starting metabat autobinner in '+str(threshold))
    print('metabat2 -i '+str(assembly_file)+' -a '+str(depth_file)+' -o '+str(metabat_genome)+' --unbinned --maxEdges '+str(threshold))
    print('----------')
    os.system('metabat2 -t '+str(num_threads)+' -i '+str(assembly_file)+' -a '+str(depth_file)+' -o '+str(metabat_genome)+' --unbinned --maxEdges '+str(threshold))
    ###os.system('metabat2 -t '+str(num_threads)+' -i '+str(assembly_file)+' -a '+str(depth_file)+' -o '+str(metabat_genome)+' --unbinned --maxEdges '+str(threshold))
    os.system('mv '+str(metabat_genome)+'.unbinned.fa '+str(metabat_genome)+'.unbinned.txt')
    os.system('rm '+str(assembly_file))
    
    os.chdir(pwd)
    bin_filtration(metabat_genome, pwd)
    print('checking metabat bins with checkM')
    print('----------')
    os.system('checkm lineage_wf -t '+str(num_threads)+' -x fa '+str(metabat_genome)+' '+str(metabat_checkm))
    print(assembly_file+' at '+str(threshold)+' Metabat autobinning done!')
    print('----------')

    os.chdir(pwd+'/'+str(metabat_checkm)+'/storage')
    p_bin_num=0
    for line in open('bin_stats_ext.tsv','r'):
        p_bin_num+=1
    os.chdir(pwd)

    bin_num=30*(int(p_bin_num/30)+1)
    return bin_num

def maxbin2(assembly_file, pwd, depth_file, threshold, Coverage_list_file, num_threads):
    maxbin2_genome=str(assembly_file)+'_'+str(threshold)+'_maxbin2_genomes'
    maxbin2_checkm=str(assembly_file)+'_'+str(threshold)+'_maxbin2_checkm'
    print('Starting maxbin2 autobinner in'+str(threshold))
    print('run_MaxBin.pl -abund_list '+Coverage_list_file+' -thread '+str(num_threads)+' -contig '+str(assembly_file)+' -out '+str(maxbin2_genome)+' -prob_threshold '+str(threshold))
    os.system('cp '+str(assembly_file)+' Coverage_list* '+str(pwd)+'/'+str(maxbin2_genome))
    os.chdir(pwd+ '/'+str(maxbin2_genome))
    os.system('run_MaxBin.pl -abund_list '+Coverage_list_file+' -thread '+str(num_threads)+' -contig '+str(assembly_file)+' -out '+str(maxbin2_genome)+' -prob_threshold '+str(threshold))
    ###os.system('perl '+str(pwd)+'/home/emma/MaxBin-2.2.7/run_MaxBin.pl -abund_list '+Coverage_list_file+' -thread '+str(num_threads)+' -contig '+str(assembly_file)+' -out '+str(maxbin2_genome)+' -prob_threshold '+str(threshold))

def concoct_mod_file(assembly_file, depth_file):
    concoct_assembly=open('Concoct_'+assembly_file,'w')
    record_ids={}
    for record in SeqIO.parse(assembly_file, 'fasta'):
        record_ids['X'+str(record.id)]=str(record.id)
        concoct_assembly.write('>X'+str(record.id)+'\n'+str(record.seq)+'\n')
    concoct_assembly.close()

    concoct_depth_file=open('Concoct_'+depth_file,'w')
    concoct_depth={}
    n=0
    for line in open(depth_file, 'r'):
        n+=1
        if n == 1:
            lis=str(line).strip().split('\t')
            n1=0
            for i in range(0, len(lis)):
                if i == 0:
                    title_line='contig'
                elif i%2==1 and i != 1:
                    n1+=1
                    title_line+='\t'+'DNA'+str(n1)
                else:
                    continue
            concoct_depth_file.write(str(title_line)+'\n')
        else:
            ids=str(line).strip().split('\t')[0]
            lis=str(line).strip().split('\t')
            n1=0
            for i in range(0, len(lis)):
                if i == 0:
                    coverage_line='X'+str(lis[0])
                elif i%2==1 and i != 1:
                    n1=+1
                    coverage_line+='\t'+str(lis[i])
                else:
                    continue
                n+=1
            concoct_depth_file.write(str(coverage_line)+'\n')
    concoct_depth_file.close()
    return str('Concoct_'+assembly_file), str('Concoct_'+depth_file)
    
def concoct(assembly_file, pwd, depth_file, threshold, num_threads):
    org_assembly=str(assembly_file).split('Concoct_')[1]
    concoct_genome=str(org_assembly)+'_'+str(threshold)+'_concoct_genomes'
    concoct_checkm=str(org_assembly)+'_'+str(threshold)+'_concoct_checkm'
    print('Starting concoct autobinner in '+str(threshold))
    print('concoct -c '+str(threshold)+' --coverage_file '+str(depth_file)+' --composition_file '+str(assembly_file)+' -b '+str(concoct_genome))
    os.system('concoct -c '+str(threshold)+' --coverage_file '+str(depth_file)+' --composition_file '+str(assembly_file)+' -b '+str(concoct_genome)+' --threads '+str(num_threads))
    print('----------')
    ids_seq={}
    for record in SeqIO.parse(assembly_file, 'fasta'):
        ids_seq[str(record.id).split('X')[1]]=str(record.seq)

    os.chdir(pwd+'/'+str(concoct_genome))
    ids, n={}, 0
    for line in open('clustering_gt1000.csv', 'r'):
        n+=1
        if n >= 2:
            contigs_ids=str(line).strip().split(',')[0].split('X')[1]
            bin_ids=str(line).strip().split(',')[1]
            if str(bin_ids) not in ids.keys():
                ids[str(bin_ids)]=[str(contigs_ids)]
            else:
                ids[str(bin_ids)].append(str(contigs_ids))
    
    for bins in ids.keys():
        bin_name=str(concoct_genome)+'.'+str(bins)+'.fasta'
        f=open(bin_name, 'w')
        seq_len=0
        for contigs in ids[bins]:
            f.write('>'+str(contigs)+'\n'+str(ids_seq[contigs])+'\n')
            seq_len+=len(ids_seq[contigs])
        f.close()

        if seq_len >= 30000000:
            os.system('rm '+str(bin_name))

    os.chdir(pwd)
    print('checking concoct bins with checkM')
    os.system('checkm lineage_wf -t '+str(num_threads)+' -x fasta '+str(concoct_genome)+' '+str(concoct_checkm))
    print(org_assembly+' in '+str(threshold)+' Concoct autobinning done!')
    print('----------')

def autobinners(softwares, assembly_file, depth_file, Coverage_list_file, binning_mode, num_threads):
    pwd=os.getcwd()
    os.chdir(pwd)

    genome_folders=[]
    if str(softwares) == 'all':
        if binning_mode == 'quick':
            maxbin2_threshold=[0.3]
            metabat_threshold=[200, 300, 400, 500]
        elif binning_mode == 'sensitive':
            maxbin2_threshold=[0.3, 0.9]
            metabat_threshold=[200, 500]
        elif binning_mode == 'more-sensitive':      
            maxbin2_threshold=[0.3, 0.5, 0.7, 0.9]
            metabat_threshold=[200, 300, 400, 500]
            
        concoct_threshold=[]
        concoct_threshold_dict={}
        # concoct_threshold=[400, 200]
        c_m=concoct_mod_file(assembly_file, depth_file)
        concoct_assembly=c_m[0]
        concoct_depth=c_m[1]
        # maxbin2_threshold=[0.9]
        # metabat_threshold=[200]

        mbn_num=len(maxbin2_threshold)
        num_threads_per_project=int(num_threads/mbn_num)
        pool=Pool(processes=num_threads_per_project)
        for item in maxbin2_threshold:
            maxbin2_folder_name=str(assembly_file)+'_'+str(item)+'_maxbin2_genomes'
            genome_folders.append(maxbin2_folder_name)
            os.system('mkdir '+str(maxbin2_folder_name))
            os.system('cp '+str(depth_file)+' '+str(pwd)+'/'+str(maxbin2_folder_name))
            pool.apply_async(maxbin2, args=(assembly_file, pwd, depth_file, item, Coverage_list_file, num_threads_per_project))
        pool.close()
        pool.join()

        for item in maxbin2_threshold:
            maxbin2_genome=str(assembly_file)+'_'+str(item)+'_maxbin2_genomes'
            maxbin2_checkm=str(assembly_file)+'_'+str(item)+'_maxbin2_checkm'
            os.chdir(pwd+'/'+str(maxbin2_genome))
            os.system('rm '+str(assembly_file))
            os.chdir(pwd)
            bin_filtration(maxbin2_genome, pwd)
            print('checking maxbin2 bins with checkM')
            print('----------')
            os.system('checkm lineage_wf -t '+str(num_threads)+' -x fasta '+str(maxbin2_genome)+' '+str(maxbin2_checkm))
            print(assembly_file+' in '+str(item)+' Maxbin2 checkM done!')

        # for item in maxbin2_threshold:
        #     maxbin2_folder_name=str(assembly_file)+'_'+str(item)+'_maxbin2_genomes'
        #     genome_folders.append(maxbin2_folder_name)
        #     os.system('mkdir '+str(maxbin2_folder_name))
        #     os.system('cp '+str(depth_file)+' '+str(pwd)+'/'+str(maxbin2_folder_name))
        #     maxbin2(assembly_file, pwd, depth_file, item, Coverage_list_file, num_threads)

        for item in metabat_threshold:
            metabat_folder_name=str(assembly_file)+'_'+str(item)+'_metabat_genomes'
            genome_folders.append(metabat_folder_name)
            os.system('mkdir '+str(metabat_folder_name))
            os.system('cp '+str(depth_file)+' '+str(pwd)+'/'+str(metabat_folder_name))
            bin_num=metabat(assembly_file, pwd, depth_file, item, num_threads)
            concoct_threshold_dict[bin_num]=''
        
        for bin_num in concoct_threshold_dict.keys():
            concoct_threshold.append(bin_num)
            concoct_threshold.append(bin_num+100)

        cct_num=len(concoct_threshold)
        num_threads_per_project=int(num_threads/cct_num)
        pool=Pool(processes=num_threads_per_project)        
        for item in concoct_threshold:
            concoct_folder_name=str(assembly_file)+'_'+str(item)+'_concoct_genomes'
            genome_folders.append(concoct_folder_name)
            os.system('mkdir '+str(concoct_folder_name))
            os.system('cp '+str(depth_file)+' '+str(pwd)+'/'+str(concoct_folder_name))
            # concoct(concoct_assembly, pwd, concoct_depth, item, num_threads)
            pool.apply_async(concoct, args=(concoct_assembly, pwd, concoct_depth, item, num_threads))
        pool.close()
        pool.join()

        ids_seq={}
        for record in SeqIO.parse(concoct_assembly, 'fasta'):
            ids_seq[str(record.id).split('X')[1]]=str(record.seq)

        for threshold in concoct_threshold:
            org_assembly=str(assembly_file)
            concoct_genome=str(org_assembly)+'_'+str(threshold)+'_concoct_genomes'
            concoct_checkm=str(org_assembly)+'_'+str(threshold)+'_concoct_checkm'

            os.chdir(pwd+'/'+str(concoct_genome))
            ids, n={}, 0
            for line in open('clustering_gt1000.csv', 'r'):
                n+=1
                if n >= 2:
                    contigs_ids=str(line).strip().split(',')[0].split('X')[1]
                    bin_ids=str(line).strip().split(',')[1]
                    if str(bin_ids) not in ids.keys():
                        ids[str(bin_ids)]=[str(contigs_ids)]
                    else:
                        ids[str(bin_ids)].append(str(contigs_ids))
            
            for bins in ids.keys():
                bin_name=str(concoct_genome)+'.'+str(bins)+'.fasta'
                f=open(bin_name, 'w')
                seq_len=0
                for contigs in ids[bins]:
                    f.write('>'+str(contigs)+'\n'+str(ids_seq[contigs])+'\n')
                    seq_len+=len(ids_seq[contigs])
                f.close()

                if seq_len >= 30000000:
                    os.system('rm '+str(bin_name))

            os.chdir(pwd)
            print('checking concoct bins with checkM')
            os.system('checkm lineage_wf -t '+str(num_threads)+' -x fasta '+str(concoct_genome)+' '+str(concoct_checkm))
            print(org_assembly+' in '+str(threshold)+' Concoct autobinning done!')
            print('----------')

    elif str(softwares) == 'metabat':
        metabat_threshold=[200, 300, 400, 500]
        for item in metabat_threshold:
            metabat_folder_name=str(assembly_file)+'_'+str(item)+'_metabat_genomes'
            genome_folders.append(metabat_folder_name)
            os.system('mkdir '+str(metabat_folder_name))
            os.system('cp '+str(depth_file)+' '+str(pwd)+'/'+str(metabat_folder_name))
            metabat(assembly_file, pwd, depth_file, item, num_threads)

    elif str(softwares) == 'maxbin2':
        maxbin2_threshold=[0.3, 0.5, 0.7, 0.9]
        for item in maxbin2_threshold:
            maxbin2_folder_name=str(assembly_file)+'_'+str(item)+'_maxbin2_genomes'
            genome_folders.append(maxbin2_folder_name)
            os.system('mkdir '+str(maxbin2_folder_name))
            os.system('cp '+str(depth_file)+' '+str(pwd)+'/'+str(maxbin2_folder_name))
            maxbin2(assembly_file, pwd, depth_file, item, Coverage_list_file, num_threads)

    elif str(softwares) == 'concoct':
        concoct_threshold=[400, 200]
        c_m=concoct_mod_file(assembly_file, depth_file)
        concoct_assembly=c_m[0]
        concoct_depth=c_m[1]
        for item in concoct_threshold:
            concoct_folder_name=str(assembly_file)+'_'+str(item)+'_concoct_genomes'
            genome_folders.append(concoct_folder_name)
            os.system('mkdir '+str(concoct_folder_name))
            os.system('cp '+str(depth_file)+' '+str(pwd)+'/'+str(concoct_folder_name))
            concoct(concoct_assembly, pwd, concoct_depth, item, num_threads)

    else:
        print('Error! Make sure you wrote the right name of binning software')
    return genome_folders

def autobinner_main(assembly_list, datasets, num_threads, binning_mode, pwd):
    bins_folders, datasets_fq, connections_total_dict, depth_total, assembly_MoDict={}, {}, {}, {}, {}

    for item in datasets.keys():
        datasets_fq[item]=[]
        #datasets_fq[item].append(ModifyEnd(datasets[item][0], 1))
        #datasets_fq[item].append(ModifyEnd(datasets[item][1], 2))
        datasets_fq[item].append('PE_r1_'+str(datasets[item][0]))
        datasets_fq[item].append('PE_r2_'+str(datasets[item][1]))
        # datasets_fq[item].append(str(datasets[item][0]))
        # datasets_fq[item].append(str(datasets[item][1]))

    for item in range(0, len(assembly_list)):
        PEC={}
        mapping_output=mapping(str(assembly_list[item]), int(item)+1, datasets_fq, num_threads, pwd)
        mo_assembly=mapping_output[0]
        mo_assembly_depth=mapping_output[1]
        connections=mapping_output[2]
        Coverage_list_file=mapping_output[3]
        bins_folders[str(assembly_list[item])]=autobinners('all', mo_assembly, mo_assembly_depth, Coverage_list_file, binning_mode, num_threads)
        os.system('rm Coverage_list_*')

        PEC=cal_connections(connections)

        connections_total=open('condense_connections_'+str(assembly_list[item])+'.txt', 'w')
        connections_total.write('node1'+'\t'+'interaction'+'\t'+'node2'+'\t'+'connections'+'\n')
        for item2 in PEC.keys():
            connections_total.write(str(item2)+'\t'+str(PEC[item2])+'\n')
        connections_total.close()

        connections_total_dict[str(assembly_list[item])]='condense_connections_'+str(assembly_list[item])+'.txt'
        depth_total[str(assembly_list[item])]=mo_assembly_depth
        assembly_MoDict[str(assembly_list[item])]=mo_assembly
    os.system('rm *.bam')
    print('Auto-binning done!')
    return bins_folders, connections_total_dict, depth_total, assembly_MoDict, datasets_fq

if __name__ == '__main__': 
    #assembly_list=['P-12-12_final.contigs.fa']
    assembly_list=['XP-T0-3_contigs.fasta','XP-T0-3_contigs.fasta','XP-T0-3_contigs.fasta']
    num_threads=44
    pwd=os.getcwd()

    datasets={'1':['P-12-11_BDME192060024-1a_1.clean.fq','P-12-11_BDME192060024-1a_2.clean.fq'], '2':['P-12-12_BDME192060025-1a_1.clean.fq','P-12-12_BDME192060025-1a_2.clean.fq'], '3':['XP-T0-3_BDME200008948-1a_1.clean.fq','XP-T0-3_BDME200008948-1a_2.clean.fq']}
    binning_mode='more-sensitive' ### 'quick', 'sensitive', 'more-sensitive'
    autobinner_main(assembly_list, datasets, num_threads, binning_mode, pwd)
