#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

from Bio import SeqIO
from Bio.Seq import Seq
try:
    from Bio.Alphabet import generic_dna
    generic_dna_t=1
except ImportError:
    generic_dna_t=0
import os, copy
from sklearn.decomposition import PCA
import numpy as np
import pandas as pd
from multiprocessing import Pool

def finding_same_seq(ORF1, ORF2):
    same_seq, ORF1_len, ORF1_num = {}, {}, 0
    for record in SeqIO.parse(ORF1,'fasta'):
        same_seq[str(record.seq)]=[record.id]
        ORF1_len[record.id]=len(str(record.seq)
        ORF1_num+=1

    f=open(ORF2+'_uniq.fa','w')
    ORF2_num, same_ORF_num, ORF2_len = 0, 0, {}
    for record in SeqIO.parse(ORF2,'fasta'):
        ORF2_num+=1
        ORF2_len[record.id]=len(str(record.seq)
        try:
            same_seq[str(record.seq)].append(record.id)
            same_ORF_num+=1
        except:
            f.write('>'+str(record.id)+'\n'+str(record.seq)+'\n')
    f.close()

    perc1=100*same_ORF_num/ORF1_num
    perc2=100*same_ORF_num/ORF2_num

    f=open('Same_contigs_perc.txt','a')
    f.write('Same'+'\t'+str(same_ORF_num)+'\t'+str(ORF1)+'\t'+str(ORF1_num)+'\t'+str(perc1)+'\t'+str(ORF2)+'\t'+str(ORF2_num)+'\t'+str(perc2)+'\n')
    f.close()
    return ORF2+'_uniq.fa', ORF1_num, ORF2_num, ORF1_len, ORF2_len

def blast(ORF1, ORF2_uniq_seq, ORF1_num, ORF2_num, ORF1_len, ORF2_len, blast_output, similarity_cutoff, simialr_coverage_cutoff, num_threads, pwd):
    os.system('makeblastdb -in '+str(ORF2_uniq_seq)+' -dbtype nucl -hash_index -parse_seqids -logfile '+str(ORF2_uniq_seq)+'_db.txt')
    os.system('blastn -query '+str(ORF1)+' -db '+str(ORF2_uniq_seq)+' -evalue 1e-20 -num_threads '+str(num_threads)+' -outfmt 6 -out '+str(blast_output))

    similar_seq_num, similar_orf_pool = 0, []
    for line in open(str(blast_output),'r'):
        query=str(line).strip().split('\t')[0]
        subject=str(line).strip().split('\t')[1]
        similarity=float(str(line).strip().split('\t')[2])
        aligned_length=int(str(line).strip().split('\t')[3])
        query_start=int(str(line).strip().split('\t')[6])
        query_end=int(str(line).strip().split('\t')[7])
        subject_start=int(str(line).strip().split('\t')[8])
        subject_end=int(str(line).strip().split('\t')[9])
        query_aligned=abs(query_end-query_start)
        subject_aligned=abs(subject_end-subject_start)
        cov1=100*query_aligned/ORF1_len[query]
        cov2=100*subject_aligned/ORF2_len[query]
        if similarity >= similarity_cutoff:
            if cov1 >= simialr_coverage_cutoff or cov2 >= simialr_coverage_cutoff:
                try:
                    similar_orf_pool[query+'\t'+subject]+=1
                except:
                    similar_seq_num+=1

    perc1=100*similar_seq_num/ORF1_num
    perc2=100*similar_seq_num/ORF2_num
    f=open('Same_contigs_perc.txt','a')
    f.write('Similar('+str(similarity_cutoff)+'-'+str(simialr_coverage_cutoff)+')'+'\t'+str(similar_seq_num)+'\t'+str(ORF1)+'\t'+str(ORF1_num)+'\t'+str(perc1)+'\t'+str(ORF2)+'\t'+str(ORF2_num)+'\t'+str(perc2)+'\n')
    f.close()

def assembly_assessment(ORF1, ORF2, similarity_cutoff, simialr_coverage_cutoff, num_threads, pwd, i):
    ORF2_uniq_seq, ORF1_num, ORF2_num, ORF1_len, ORF2_len = finding_same_seq(ORF1, ORF2)
    blast_output=str(ORF1)+'_vs_'+str(ORF2)+'.txt'
    blast(ORF1, ORF2_uniq_seq, ORF1_num, ORF2_num, ORF1_len, ORF2_len, blast_output, similarity_cutoff, simialr_coverage_cutoff, num_threads, pwd)

def ORF_predict(contig_file):
    try:
        print('Predicting ORFs of '+str(contig_file))
        os.system('prodigal -i '+str(contig_file)+' -d '+str(contig_file)+'.orfs.fna -m -p meta -q')
        # os.system('mv '+str(contig_file)+'.orfs.fna '+pwd+'/'+standard_bin_orfs_folder)
    except:
        print('ORFs prediction error! Please make sure prodigal is installed in your system')

def assembly_assessment_main(assembly_list, similarity_cutoff, simialr_coverage_cutoff, num_threads):
    pwd=os.getcwd()
    f=open('Same_ORFs_perc.txt','w')
    f.write('Type'+'\t'+'Seq len'+'\t'+'Assembly1'+'\t'+'Assembly1 len'+'\t'+'Assembly1 same perc(%)'+'\t'+'Assembly2'+'\t'+'Assembly2 len'+'\t'+'Assembly2 same perc(%)'+'\n')
    f.close()

    ORFs=[]
    pool=Pool(processes=num_threads)
    for item in assembly_list:
        ORFs.append(str(item)+'.orfs.fna')
        pool.apply_async(ORF_predict, args=(item))
    pool.close()
    pool.join()

    if len(ORFs) > 1:
        ORFs2=ORFs[:]

        i=0
        while len(ORFs2) != 1:
            i+=1
            new_contigs=assembly_assessment(ORFs2[0], ORFs2[-1], similarity_cutoff, simialr_coverage_cutoff, num_threads, pwd, i)
            # assembly_list2.remove(assembly_list2[0])
            # assembly_list2.remove(assembly_list2[-1])
            # assembly_list3=[new_contigs]
            # for item in assembly_list2:
            #     assembly_list3.append(item)

            # assembly_list2=[]
            # for item in assembly_list3:
            #     assembly_list2.append(item)

        os.system('mv '+str(assembly_list2[0])+' Merged_assembly.fa')
            # assembly_merging(assembly_list[0], assembly_list[-1], ass_contig_total, similarity_cutoff, aligned_len_cutoff, num_threads, pwd)
        print('----------------------------------------------------------------------------')
        print('Assembly merging done!')
    else:
        print('The script did not perform correctly. There is only one assembly provided.')

if __name__ == '__main__': 
    assembly_list=['1_Opera_unpolished_cat_contigs.fasta','2_CAMI_high_opera_unpolished_S001_contigs.fasta','3_CAMI_high_opera_unpolished_S002_opera_contigs.fasta',
'4_CAMI_high_opera_unpolished_S003_opera_contigs.fasta','5_Opera_unpolished_S004_opera_contigs.fasta','6_Opera_unpolished_S005_opera_contigs.fasta']
    #assembly_list=['1_Opera_unpolished_cat_contigs.fasta','2_CAMI_high_opera_unpolished_S001_contigs.fasta']
    # Coverage_list=['Coverage_matrix_for_binning_1_adh_dn1_contigs.fasta.txt','Coverage_matrix_for_binning_8_adh1_opera-ms_contigs.fasta.txt','Coverage_matrix_for_binning_9_adh_datasplit_contigs.fasta.txt']
    similarity_cutoff=90
    simialr_coverage_cutoff=90
    num_threads=30
    assembly_merging_main(assembly_list, similarity_cutoff, simialr_coverage_cutoff, num_threads)
    # assembly_merging_main(assembly_list, Coverage_list)
