#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

from Bio import SeqIO
import sys, os, time
from collections import Counter

def mapping(assembly, group):
    n=0
    f_filtrated=open(str(group)+'_'+assembly, 'w')

    print('Filtration of the contigs/scaffolds. The process keeps Contig/scaffold with larger than 1000 bp.')
    for record in SeqIO.parse(assembly,'fasta'):
        if len(record.seq) >= 1000:
            n+=1
            f_filtrated.write('>'+str(group)+'-'+str(n)+'\n'+str(record.seq)+'\n')
    f_filtrated.close()
    print('Done!')

if __name__ == '__main__': 
    assembly='adh_dn34_contigs.fasta'
    group=7
    mapping(assembly, group)
