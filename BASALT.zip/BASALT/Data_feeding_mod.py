#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

from Bio import SeqIO
import sys, os, time
from collections import Counter

def binset_mod(extra_binset):
    pwd=os.getcwd()
    os.chdir(pwd+'/'+extra_binset)
    fmod=open('Mod_bin.txt','w')
    x=0
    for root, dirs, files in os.walk(pwd+'/'+extra_binset):
        for file in files:
            hz=str(file).split('.')[-1]
            if 'fa' in hz or 'fasta' in hz or 'fna' in hz:
                try:
                    x+=1
                    bin_id='1_genomes.'+str(x)+'.fa'
                    fmod.write(str(file)+'\t'+str(bin_id)+'\n')
                except:
                    print(str(file),'is not a fasta file containing sequences')
                    # os.system('rm '+str(assembly_num)+'_'+str(file_name)+'_genomes.'+str(x)+'.fa')
    fmod.close()

if __name__ == '__main__': 
    extra_binset='BestBinset_outlier_refined_filtrated_retrieved_retrieved_OLC_re-assembly_OLC'
    binset_mod(extra_binset)
