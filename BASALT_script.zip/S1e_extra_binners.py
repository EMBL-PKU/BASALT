#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

from lib2to3.fixes import fix_buffer
from Bio import SeqIO
import sys, os, time
from collections import Counter
from multiprocessing import Pool

def metabinner(assembly_file, depth_file, num_threads, ram, pwd):
    condaenv=os.popen('conda info --envs').read()
    a=condaenv.split('\n')
    # print(str(a))
    for item in a:
        a=str(item).split('/')
        # name=a[0].strip()
        if 'BASALT' in item:
            path='/'.join(a[1:len(a)])
            path='/'+path+'/bin/'

    os.system('cat '+str(depth_file)+' | cut -f -1,4- > '+str(assembly_file)+'_coverage_profile.tsv')
    # os.system('python gen_kmer.py '+pwd+'/'+str(assembly_file)+' 1000 4')
    os.system(str(path)+'scripts/gen_kmer.py '+pwd+'/'+str(assembly_file)+' 1000 4')
    assembly_name_list=assembly_file.split('.')
    assembly_name_list.remove(assembly_name_list[-1])
    assembly_name='.'.join(assembly_name_list)

    kmer_file=str(assembly_name)+'_kmer_4_f1000.csv'
    n, contig_id = 0, {}
    for line in open(kmer_file,'r'):
       n+=1
       if n >= 2:
           contig_id[str(line).split(',')[0]]=0
           
    fcovout=open(str(assembly_file)+'_coverage_profile2.tsv','w')
    n=0
    for line in open(str(assembly_file)+'_coverage_profile.tsv','r'):
        n+=1
        if n == 1:
            fcovout.write(line)
        else:
            c_id=str(line).split('\t')[0]
            if c_id in contig_id.keys():
                fcovout.write(line)
    fcovout.close()
    os.system('mv '+str(assembly_file)+'_coverage_profile2.tsv '+str(assembly_file)+'_coverage_profile.tsv')
    os.system(path+'/run_metabinner.sh -a '+pwd+'/'+str(assembly_file)+' -o '+pwd+'/'+str(assembly_file)+'_metabinner -d '+pwd+'/'+str(assembly_file)+'_coverage_profile.tsv -k '+pwd+'/'+str(assembly_name)+'_kmer_4_f1000.csv -t '+str(num_threads)+' -p '+path)
    metabinner_bin_contig, mbn={}, {}
    for line in open(pwd+'/'+str(assembly_file)+'_metabinner/metabinner_res/metabinner_result.tsv','r'):
        bin_id=str(line).strip().split('\t')[1]
        contig=str(line).strip().split('\t')[0]
        metabinner_bin_contig[contig]=bin_id
        mbn['Mbn_bin'+str(bin_id)+'.fa']=1

    for record in SeqIO.parse(assembly_file,'fasta'):
        try:
            fmbn=open('Mbn_bin'+str(metabinner_bin_contig[record.id])+'.fa','a')
            fmbn.write('>'+str(record.id)+'\n'+str(record.seq)+'\n')
            fmbn.close()
        except:
            if str(record.id) in metabinner_bin_contig.keys():
                fmbn=open('Mbn_bin'+str(metabinner_bin_contig[record.id])+'.fa','w')
                fmbn.write('>'+str(record.id)+'\n'+str(record.seq)+'\n')
                fmbn.close()          
    
    os.system('mkdir '+str(assembly_file)+'_metabinner_genomes')
    for item in mbn.keys():
        # print(item)
        os.system('mv '+str(item)+' '+pwd+'/'+str(assembly_file)+'_metabinner_genomes')
    os.system('checkm lineage_wf -t '+str(num_threads)+' -x fa '+str(assembly_file)+'_metabinner_genomes '+str(assembly_file)+'_metabinner_checkm')
    return

def vamb(assembly_file, depth_file, num_threads, ram, pwd):
    print(assembly_file)
    print(depth_file)
    print(num_threads)
    print(ram)
    print(pwd)

def extra_binner(binner, assembly_file, depth_file, num_threads, ram, pwd):
    extra_bin_folder=[]
    if binner == 'm':
        metabinner(assembly_file, depth_file, num_threads, ram, pwd)
        extra_bin_folder.append(str(assembly_file)+'_metabinner_genomes')
    elif binner == 'v':
        vamb(assembly_file, depth_file, num_threads, ram, pwd)
    return extra_bin_folder

if __name__ == '__main__': 
    num_threads=20
    ram=250
    pwd=os.getcwd()
    assembly_file='1_assembly_sample1.fa'
    depth_file='1_assembly.depth.txt'
    binner='m' ### 'm': metabinner; 'v': vamb
    extra_binner(binner, assembly_file, depth_file, num_threads, ram, pwd)