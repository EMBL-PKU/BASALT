#!/usr/bin/env python
import os
os.mkdir('Coverage_depth_connection_SimilarBin_files_backup')
os.system('mv *.depth.txt Coverage_matrix_* Combat_* condense_connections_* Connections_* Similar_bins.txt Coverage_depth_connection_SimilarBin_files_backup')
os.system('tar -zcvf Coverage_depth_connection_SimilarBin_files_backup.tar.gz Coverage_depth_connection_SimilarBin_files_backup')
os.system('rm -rf Coverage_depth_connection_SimilarBin_files_backup')
os.system('rm -rf *_kmer bin_coverage Bin_coverage_after_contamination_removal bin_comparison_folder bin_extract-eleminated-selected_contig Bins_blast_output')
os.system('tar -zcvf Group_comparison_files.tar.gz *_comparison_files')
os.system('tar -zcvf Group_Bestbinset.tar.gz *_BestBinsSet')
os.system('tar -zcvf Group_checkm.tar.gz *_checkm')
os.system('tar -zcvf Group_genomes.tar.gz *_genomes')
os.system('tar -zcvf Binsets_backup.tar.gz BestBinse*') ###
os.system('rm -rf *_comparison_files *_checkm *_genomes *_BestBinset BestBinse* Deep_retrieved_bins coverage_deep_refined_bins S6_coverage_filtration_matrix S6_TNF_filtration_matrix split_blast_output TNFs_deep_refined_bins')
os.system('rm *_checkpoint.txt')
os.system('rm -rf Merged_seqs_*')
os.system('rm -rf *.bt2 Outlier_in_threshold* Summary_threshold* Refined_total_bins_contigs.fa Total_bins.fa') 
for i in range(1,20):
    os.system('rm -rf *_deep_retrieval_'+str(i))
os.system('rm -rf *_sr_bins_seq *_MP_1 *_MP_2 *_gf_lr_polished *_gf_lr *_gf_lr_mod *_gf_lr_checkm *_long_read')
print('Done!')
