def split_reads(reads, read_rename1, read_rename2):
    print('Splitting '+str(reads))
    f=open(read_rename1,'w')
    f2=open(read_rename2,'w')
    # even={0:0, 2:2, 4:4, 6:6, 8:8}
    n, m = 0, 0
    for line in open(reads,'r'):
        n+=1
        if n%4 == 1:
            m+=1
            # ids=str(line).strip().replace(' ','_')
            # ids=str(line).strip().replace(' ','_').replace('@','>')
            ids='@Seq'+str(m)
        elif n%4 == 2:
            lines=line.strip()
            ll=len(lines)
            if ll%75 != 0:
                sn=int(ll/75)+1
            else:
                sn=int(ll/75)

            seq_l=[]
            if sn % 2 == 0:
                sn=sn
            else:
                sn=sn-1
            for i in range(1,sn+1):
                s, e=75*(i-1), 75*i
                seq_l.append(str(lines)[s:e])
                # f.write(str(ids)+'_'+str(i)+'\n'+str(str(lines)[s:e])+'\n')
        elif n%4 == 0:
            for i in range(1,sn+1):
                s, e=75*(i-1), 75*i
                lines=line.strip()
                paired_num=int((i+1)/2)
                if i%2 == 0:
                    f2.write(str(ids)+'-'+str(paired_num)+'_modifiedID 2_frag'+str(i)+'\n'+str(seq_l[i-1])+'\n'+'+'+'\n'+str(str(lines)[s:e])+'\n')
                else:
                    f.write(str(ids)+'-'+str(paired_num)+'_modifiedID 1_frag'+str(i)+'\n'+str(seq_l[i-1])+'\n'+'+'+'\n'+str(str(lines)[s:e])+'\n')

    f.close()
    f2.close()
    print('Split '+str(reads)+' done!')


lr=['SRR15275210.fastq','SRR15275211.fastq','SRR15275212.fastq','SRR15275213.fastq','SRR17687125.fastq']

long_read_split_fa=[]
for reads in lr:
    if '.fq' in reads:
        read_rename1=reads.replace('.fq','_split_R1.fq')
        read_rename2=reads.replace('.fq','_split_R2.fq')
        # read_rename=reads.replace('.fq','_split.fa')
    elif '.fastq' in reads:
        read_rename1=reads.replace('.fastq','_split_R1.fq')
        read_rename2=reads.replace('.fastq','_split_R2.fq')
        # read_rename=reads.replace('.fastq','_split.fa')

    long_read_split_fa.append(read_rename1)
    long_read_split_fa.append(read_rename2)
    split_reads(reads,read_rename1,read_rename2)