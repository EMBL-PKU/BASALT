#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#coding=utf-8

import time, sys, os
from Bio import SeqIO
from Data_feeding import *
from S1_Autobinners_2qc_11152023 import *
from S1e_extra_binners import *
from S2_BinsAbundance_PE_connections_multiple_processes_pool_checkm import *
from S3_Bins_comparator_within_group_checkm import *
from S4_Multiple_Assembly_Comparitor_multiple_processes_bwt_checkm import *
from S5_Outlier_remover_DL_checkm import *
from S6_retrieve_contigs_from_PE_contigs_checkm import *
from S7_Contigs_retrieve_within_group_checkm import *
from S7lr_finding_sr_contigs_basing_lr_and_polishing_checkm import *
from S8_OLC_new_checkm import *
from S9_Reassembly_checkm import *
from S9p_Hybrid_Reassembly_checkm import *
from S10_OLC_new_checkm import *
from glob import glob

# def BASALT_main(assembly_list, datasets, num_threads, lr_list, ram, continue_mode, functional_module, autobinning_parameters, refinement_paramter, hybri_reassembly, max_ctn, min_cpn, pwd):
def BASALT_data_feeding_main(assembly_list, datasets, num_threads, lr_list, hifi_list, hic_list, eb_list, ram, continue_mode, functional_module, autobining_parameters, refinement_paramter, max_ctn, min_cpn, pwd, QC_software):
    ### Record the last accomplished step

    print('Done!')

if __name__ == '__main__': 
    extra_binset=['BestBinset_outlier_refined_filtrated_retrieved_MAGs_polished_re-assembly_OLC_12092023']
    assembly_list=['']
    datasets={'1':['SRR12358675_sub_1.fastq','SRR12358675_sub_2.fastq'], '2':['SRR12358676_sub_1.fastq','SRR12358676_sub_2.fastq']}
    num_threads=60
    start_index=4
    software='rd' ### 'mtb': metabat2; 'mxb': maxbin2: 'c': concoct; 'v': vamb; 'mwp': metawrap; 'dt': dastool; 'rd': random, when rd, script will use the binset to generate a assembly rather use the provided assembly
    refinement_bins_comparator_multiple_groups(extra_binset, assembly_list, datasets, software, start_index, num_threads)




    assembly_list=['8_medium_S001_SPAdes_scaffolds.fasta','10_medium_cat_SPAdes_scaffolds.fasta']
    datasets={'1':['RM2_S001_insert_270_mate1.fq','RM2_S001_insert_270_mate2.fq'], '2':['RM2_S002_insert_270_mate1.fq','RM2_S002_insert_270_mate2.fq']}
    lr_list=[]
    hic_list=[]
    hifi_list=[]
    eb_list=[] ### if you want to use extra binner, you may use eb_list=['m', 'v']; 'm': metabinner, 'v': vamb
    num_threads=30
    ram=120
    pwd=os.getcwd()
    refinement_paramter='deep' ### 1st refinement mode: 1. quick; 2. deep
    autobining_parameters='more-sensitive' ### 'quick', 'sensitive', 'more-sensitive'
    functional_module='all' ### 1. all; 2. autobinning; 3. refinement; 4. reassembly
    continue_mode='last' ### parameter type: 1. continue(last): start from the latest step finished from the last time; 2. new: start from beginning
    # hybri_reassembly='n' ### Use Unicycler to re-assembly. e.g. --hybrid y / --hybrid n; defalt no
    max_ctn, min_cpn=20, 35 
    QC_software='checkm2'
    BASALT_data_feeding_main(assembly_list, datasets, num_threads, lr_list, hifi_list, hic_list, eb_list, ram, continue_mode, functional_module, autobining_parameters, refinement_paramter, max_ctn, min_cpn, pwd, QC_software)
    # BASALT_main(assembly_list, datasets, num_threads, lr_list, ram, continue_mode, functional_module, autobining_parameters, refinement_paramter, hybri_reassembly, max_ctn, min_cpn, pwd)
