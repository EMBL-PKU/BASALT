#!/usr/bin/env python
from Bio import SeqIO
import sys, os, threading, copy, math
from multiprocessing import Pool
# from glob import glob

f=open('Bin86_SPAdes_re-assembly_contigs.fa','w')
for record in SeqIO.parse('contigs.fasta', 'fasta'):
    if len(record.seq) >= 1000:
        f.write('>'+str(record.id)+'\n'+str(record.seq)+'\n')
f.close()