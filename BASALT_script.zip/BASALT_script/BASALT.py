#!/usr/bin/python
# -*- coding: UTF-8 -*-
#coding=utf-8

import time, sys, os
from Bio import SeqIO
from BASALT_main import * 
import argparse

parser = argparse.ArgumentParser(description='BASALT')
parser.add_argument('-a', '--assemblies', type=str, dest='assemblies',
                    help='List of assemblies, e.g.: as1.fa,as2.fa')
parser.add_argument('-s', '--shortreads', type=str, dest='sr_datasets',
                    help='List of paired-end reads, e.g.: r1_1.fq,r1_2.fq/r2_1.fq,r2_2.fq (paried_ends reads need \'/\' to seperate)')
parser.add_argument('-l', '--longreads', type=str, dest='long_datasets',
                    help='List of long reads, e.g.: lr1.fq,lr2.fq')
parser.add_argument('-c','--HIC', type=str, dest='Hi_C_dataset',
                    help='List of Hi-C dataset(s), e.g.: hc1.fq,hc2.fq')
parser.add_argument('-t','--threads', type=int, dest='threads', default=4,
                    help='Number of threads, e.g.: 64')
parser.add_argument('-m','--ram', type=int, dest='ram', default=32,
                    help='Number of ram, minimum ram suggested: 32G')
parser.add_argument('-e','--extra_binner', type=str, dest='extra_binner',
                    help='Extra binner for binning: m: metabinner, v: vamb; for instance: -e m, means BASALT will use metabinner for binning besides metabat2, maxbin2, and concoct')
parser.add_argument('--min-cpn', type=int, dest='Min_completeness', default=35,
                    help='Min completeness of kept bins (default: 35)')
parser.add_argument('--max-ctn', type=int, dest='Max_contamination', default=20,
                    help='Max contamination of kept bins (default: 20)')
parser.add_argument('--mode', type=str, dest='running_mode', default='continue',
                    help='Start a new project (new) or continue to run (continue). e.g. --mode continue / --mode new')
parser.add_argument('--module', type=str, dest='functional_module', default='all',
                    help='Three modules: 1. autobinning; 2. refinement; 3. reassembly. Default will run all modules. But you could set the only perform modle. e.g. --module reassembly')
parser.add_argument('--autopara', type=str, dest='autobining_parameters', default='more-sensitive',
                    help='Three parameters to chose: 1. more-sensitive; 2. sensitive; 3. quick. Default: more-sensitive. e.g. --autopara sensitive')
parser.add_argument('--refinepara', type=str, dest='refinement_paramter', default='deep',
                    help='Two refinement parameters to chose: 1. deep; 2. quick. Default: deep. e.g. --refpara quick')
# parser.add_argument('--hybrid', type=str, dest='hybrid_reassembly', default='no',
#                     help='Use hybrid re-assembly. e.g. --hybrid y / --hybrid n; defalt no')
# parser.add_argument('--compression', type=str, dest='compression', default=0,
#                     help='Two refinement parameters to chose: 1. deep; 2. quick. Default: deep. e.g. --refpara quick')


args = parser.parse_args()
assemblies=args.assemblies
sr_datasets=args.sr_datasets
long_reads_list=args.long_datasets
Hi_C_reads_list=args.Hi_C_dataset
num_threads=args.threads
ram=args.ram
extrabinner=args.extra_binner
min_cpn=args.Min_completeness
max_ctn=args.Max_contamination
continue_mode=new=args.running_mode
functional_module=args.functional_module
autobining_parameters=args.autobining_parameters
refinement_paramter=args.refinement_paramter
# hybrid_reassembly=args.hybrid_reassembly

datasets_list=sr_datasets.split('/')
datasets, n = {}, 0
for item in datasets_list:
    n+=1
    datasets[str(n)]=[]
    pr=str(item).strip().split(',')
    datasets[str(n)].append(pr[0].strip())
    datasets[str(n)].append(pr[1].strip())

assembly_list=assemblies.split(',')

try:
    lr_list2=long_reads_list.split(',')
    lr_list=[]
    for item in lr_list2:
        lr_list.append(item.strip())
except:
    lr_list=[]

try:
    hic_list2=Hi_C_reads_list.split(',')
    hic_list=[]
    for item in hic_list2:
        hic_list.append(item.strip())
except:
    hic_list=[]

try:
    eb_list2=extrabinner.split(',')
    eb_list=[]
    for item in eb_list2:
        eb_list.append(item.strip())
except:
    eb_list=[]

pwd=os.getcwd()
print('Processing assemblies:', str(assembly_list))
print('Processing short-reads:', str(datasets))
print('Processing long-reads:', str(lr_list))
print('Processing Hi-C reads:', str(hic_list))
print('Process with extra binner:', str(extrabinner))
print('Processing with:', str(num_threads), 'threads')
print('Processing with:', str(ram), 'G')
print('Running status:', str(continue_mode))
print('Binning module:', str(functional_module))
print('Min completeness:', str(min_cpn))
print('Max contamination:', str(max_ctn))
print('Autobinning parameter:', str(autobining_parameters))
print('Refinement parameter:', str(refinement_paramter))
# print('Hybrid reassembly:', str(hybrid_reassembly))
if continue_mode == 'continue':
    continue_mode = 'last'
BASALT_main(assembly_list, datasets, num_threads, lr_list, hic_list, eb_list, ram, continue_mode, functional_module, autobining_parameters, refinement_paramter, max_ctn, min_cpn, pwd)
# BASALT_main(assembly_list, datasets, num_threads, lr_list, ram, continue_mode, functional_module, autobining_parameters, refinement_paramter, hybrid_reassembly, max_ctn, min_cpn, pwd)