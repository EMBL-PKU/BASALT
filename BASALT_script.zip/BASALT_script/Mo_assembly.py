from Bio import SeqIO

f_filtrated=open('1_2_S17_high_S001_spades.fna', 'w')
print('Filtration of the contigs/scaffolds. The process keeps Contig/scaffold with larger than 1000 bp.')
n=0
for record in SeqIO.parse('2_S17_high_S001_spades.fna','fasta'):
    if len(record.seq) >= 1000:
        n+=1
        f_filtrated.write('>1-'+str(n)+'\n'+str(record.seq)+'\n')
f_filtrated.close()