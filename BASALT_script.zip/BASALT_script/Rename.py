import os

pwd=os.getcwd()
rename={}
os.chdir(pwd+'/Final_bestbinset')
rename_file=open('Rename.txt', 'w')
for root, dirs, files in os.walk(pwd+'/Final_bestbinset'):
    for file in files:
        hz=file.split('.')[-1]
        if 'fa' in hz or 'fna' in hz or 'fasta' in hz:
            if '_' in file:
                nl=file.split('.')
                nl.remove(nl[-1])
                full_name='.'.join(nl)
                bin_name=file.split('_')[0].split('.')[0]
                os.system('mv '+file+' '+bin_name+'.fa')
                rename[full_name]=bin_name
                rename_file.write(file+' '+bin_name+'.fa'+'\n')
rename_file.close()

x=0
for root, dirs, files in os.walk(pwd+'/Final_bestbinset'):
    for file in files:
        if 'quality_report.tsv' in file:
            x=1
            f=open(file+'2','w')
            xyz=0
            for line in open(file):
                xyz+=1
                if xyz >= 2:
                    n=str(line).strip().split('\t')[0]
                    # c=str(line).strip().split('\t')[1]
                    if n in rename.keys():
                        f.write(line.replace(n, str(rename[n])))
                    else:
                        f.write(line)
                else:
                    f.write(line)
            f.close()
            
            os.system('mv '+file+'2 '+file)
os.chdir(pwd)